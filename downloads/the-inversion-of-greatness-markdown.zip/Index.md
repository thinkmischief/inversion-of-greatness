A-theory of time, [§6.3.2](<6.3.2 Eternity.md>), [§7.2.1](<7.2.1 What is Disputed.md>), [§7.2.2](<7.2.2 What is Required.md>); *see also* B-theory of time; Presentism

Abduction, [§8.4.1](<8.4.1 What is Disputed.md>), [§8.4.3](<8.4.3 What is Predicted.md>), [§8.4.4](<8.4.4 What is Confirmed.md>)

Absence of X, [§2.8](<2.8 The Whole Line.md>)

Abstractism (about possible worlds), [§2.1.5](<2.1.5 The S5 Bottleneck.md>)

Absurdism, [§8.8](<8.8 Meaning.md>), [§8.8.1](<8.8.1 What is Disputed.md>), [§8.8.5](<8.8.5 What is Concluded.md>)

Actor-network theory, [§8.11.1](<8.11.1 What is Disputed.md>)

Actuality, [§1.2](<1.2 Modal Status.md>), Glossary

*Actus essendi*, [§6.2.1](<6.2.1 Simplicity.md>)

*Actus purus*, [§6.3.1](<6.3.1 Necessity.md>), [§6.7.1](<6.7.1 Power.md>), [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.5](<8.9.5 What is Concluded.md>)

Adams, Marilyn McCord, E.1.5 Soul-Making Theodicy; E.1.6 Defeat of Horrendous Evil. Philosopher of religion; horrendous evils, defeat, and God. Distinct from Robert Merrihew Adams.

Adams, Robert Merrihew, [§2.4.7](<2.4.7 Distinction Requires Spatiality.md>), [§4.3.12](<4.3.12 Haecceitism.md>)

Adamson, Peter, §6 Relocating Greatness; [§5.1.3](<5.1.3 Simultaneous Causation.md>); [§6.3.1](<6.3.1 Necessity.md>). Peter Adamson on Avicenna and the Islamic philosophical tradition, including the necessary-existent framework.

Adorno, Theodor, [§8.13.1](<8.13.1 What is Disputed.md>), [§8.13.5](<8.13.5 What is Concluded.md>)

Aesthetic experience, [§8.13.1](<8.13.1 What is Disputed.md>)

*Aeviternus*, [§6.3.2](<6.3.2 Eternity.md>)

*Agape and eros*, [§6.8.2](<6.8.2 Relatability.md>), [§6.9.1](<6.9.1 Benevolence.md>)

Agency, *see* Causality (divine); Will (first-person)

Agency detection, [§8.14](<8.14 Spirituality.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Agent causation, [§8.9.1](<8.9.1 What is Disputed.md>)

Agriculture, [§9.6](<9.6 Agriculture.md>), [§9.6.1](<9.6.1 What is Disputed.md>)–[§9.6.5](<9.6.5 What is Concluded.md>)

Aharonov–Bohm effect, [§7.3.4](<7.3.4 What is Confirmed.md>), [§7.5.2](<7.5.2 Field.md>)

AI-generated art, [§8.13.1](<8.13.1 What is Disputed.md>), [§8.13.5](<8.13.5 What is Concluded.md>)

Al-Ghazali, §5, §6, [§6.7.1](<6.7.1 Power.md>)

Allison, Dale C., [§6.8.4](<6.8.4 Revelation.md>) Revelation; Resurrection Excursus; E.5.4 Final Judgment. Dale Allison on memory- and expectation-shaped resurrection reports and an apocalyptic-Jesus reading.

Allport, Gordon W., [§9.2](<9.2 Belonging.md>) Belonging; [§9.2.2](<9.2.2 What is Required.md>) What is Required; [§9.2.4](<9.2.4 What is Confirmed.md>) What is Confirmed. Social psychologist; contact hypothesis and the conditions under which intergroup contact reduces prejudice.

Alston, William, [§8.14](<8.14 Spirituality.md>), [§8.14.1](<8.14.1 What is Disputed.md>)

Analogy of being, [§6.8.3](<6.8.3 Describability.md>)

Analytic / synthetic distinction, [§1.1](<1.1 Reality.md>), [§2.4.2](<2.4.2 Structural Gap.md>)

*Anatta*, [§8.5](<8.5 Identity.md>), [§8.5.4](<8.5.4 What is Confirmed.md>)

Anderson, Elizabeth, [§9.1](<9.1 Rights.md>), [§9.4](<9.4 Information.md>), [§9.6](<9.6 Agriculture.md>), [§9.7](<9.7 Economy.md>), [§9.10](<9.10 Healthcare.md>), [§9.11](<9.11 Defense.md>), [§9.12](<9.12 Enforcement.md>), [§9.13](<9.13 Justice.md>), [§9.15](<9.15 Installation.md>)

Animal communication, [§8.10](<8.10 Language.md>), [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.4](<8.10.4 What is Confirmed.md>)

Animal tool use, [§8.11](<8.11 Technology.md>), [§8.11.4](<8. Expanding the Field.md>)

Animalism, [§8.5.1](<8.5.1 What is Disputed.md>)

Anselm, [§6.1](<6.1 Greatness.md>), [§6.7.3](<6.7.3 Interaction.md>), [§6.8.3](<6.8.3 Describability.md>), [§6.9.2](<6.9.2 Righteousness.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

anthropopathism, [§6.7.3](<6.7.3 Interaction.md>)

Anti-natalism, [§8.6.1](<8.6.1 What is Disputed.md>), [§8.8.1](<8.8.1 What is Disputed.md>)

Apel, Karl-Otto, [§2.2](<2.2 Cartesian Certainty.md>) Cartesian Certainty. Karl-Otto Apel on discourse ethics and the a priori presuppositions of the communication community.

Appraisal theory, [§8.2.1](<8.2.1 What is Disputed.md>)

Aquinas, Thomas, [§2.8.4](<2.8.4 Necessity Precedes Contingency.md>), §5, [§5.2.1](<5.2.1 Divine Simplicity.md>), [§5.1.3](<5.1.3 Simultaneous Causation.md>), [§4.2.9](<4.2.9 Existential Inertia.md>), [§6.2.1](<6.2.1 Simplicity.md>), [§6.3.1](<6.3.1 Necessity.md>), [§6.4.2](<6.4.2 Knowledge.md>), [§6.7.1](<6.7.1 Power.md>), [§6.7.3](<6.7.3 Interaction.md>), [§6.8.3](<6.8.3 Describability.md>), [§6.8.4](<6.8.4 Revelation.md>), [§6.9.2](<6.9.2 Righteousness.md>), [§6.2.2](<6.2.2 Unity.md>), [§6.6](<6.6 Life.md>), [§8.3.5](<8.3.5 What is Concluded.md>), [§8.6.5](<8.6.5 What is Concluded.md>), [§8.9.1](<8.9.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>), Excursus E.5.1, Excursus E.4.1

Argument from contingency, [§5.1.1](<5.1.1 Rasmussen's Foundation Argument.md>), [§4.1.3](<4.1.3 Principle of Sufficient Reason.md>); *see also* Contingency; PSR (Principle of Sufficient Reason); Rasmussen

Argument from Logical Laws, [§5.1.9](<5.1.9 Transcendental Argument.md>)

Aristotle, [§2.6.11](<2.6.11 No Fourth Condition.md>), [§4.2.2](<4.2.2 Shoemaker's Time Without Change.md>), [§4.2.4](<4.2.4 Platonism.md>), [§6.4.1](<6.4.1 Awareness.md>), [§6.7.2](<6.7.2 Causality.md>), [§6.8.4](<6.8.4 Revelation.md>), [§6.9.2](<6.9.2 Righteousness.md>), [§6.5.2](<6.5.2 Beatitude.md>), [§7.4.2](<7.4.2 What is Required.md>), [§8.2.4](<8.2.4 What is Confirmed.md>), [§8.4](<8.4 Reasoning.md>), [§8.4.1](<8.4.1 What is Disputed.md>), [§8.8.3](<8.8.3 What is Predicted.md>), [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.5](<8.9.5 What is Concluded.md>), [§8.12.1](<8.12.1 What is Disputed.md>)

Arminianism, [§6.7.4](<6.7.4 Sovereignty.md>)

Arminius, Jacobus, [§6.7.4](<6.7.4 Sovereignty.md>)

Armstrong, David M., [§4.4.1](<4.4.1 Modal Realism.md>) Modal Realism; [§4.4.4](<4.4.4 Modal Fictionalism.md>) Modal Fictionalism. David Armstrong's combinatorialism, universals, laws, and states-of-affairs metaphysics.

Arrow of time, [§7.2.3](<7.2.3 What is Predicted.md>), [§7.2.4](<7.2.4 What is Confirmed.md>)

Art, [§8.13](<8.13 Art.md>)

Asad, Talal, [§8.14.1](<8.14.1 What is Disputed.md>)

Aseity, [§6.1](<6.1 Greatness.md>), [§6.10](<6.10 No Exit.md>), Glossary

Aseity Forfeiture, [§6.1](<6.1 Greatness.md>), [§6.10](<6.10 No Exit.md>), Appendix B item 18, Glossary Result

Ash'arism, [§6.7.1](<6.7.1 Power.md>), [§6.9.1](<6.9.1 Benevolence.md>)

Aspatial existence (¬S), [§6.1](<6.1 Greatness.md>), [§6.8.1](<6.8.1 Presence.md>), [§6.10](<6.10 No Exit.md>), Appendix B item 15; *see also* Atemporality (¬T); Immateriality (¬Φ); Supernatural Preclusion; Space

Atemporality (¬T), [§6.1](<6.1 Greatness.md>), [§6.3.2](<6.3.2 Eternity.md>), [§6.4.2](<6.4.2 Knowledge.md>), [§6.10](<6.10 No Exit.md>), Appendix B item 15; *see also* Aspatial existence (¬S); Immateriality (¬Φ); Supernatural Preclusion; Time

Atran, Scott, [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Augustine, [§5.2.1](<5.2.1 Divine Simplicity.md>), [§6.3.2](<6.3.2 Eternity.md>), [§6.7.3](<6.7.3 Interaction.md>), [§6.9.2](<6.9.2 Righteousness.md>), [§8.6.5](<8.6.5 What is Concluded.md>), [§8.8.1](<8.8.1 What is Disputed.md>), [§8.9.1](<8.9.1 What is Disputed.md>), [§9.2.1](<9.2.1 What is Disputed.md>)

Austin, J. L., [§8.10.5](<8.10.5 What is Concluded.md>)

Autonomy, [§8.12](<8.12 Morality.md>), [§8.12.2](<8.12.2 What is Required.md>)

Autonomy of technique, [§8.11.1](<8.11.1 What is Disputed.md>)

Autopoiesis, [§7.8](<7.8 Life.md>), [§8.7.4](<8.7.4 What is Confirmed.md>)

Avicenna, [§5.1.1](<5.1.1 Rasmussen's Foundation Argument.md>), [§5.2.1](<5.2.1 Divine Simplicity.md>)

Awareness (divine), [§6.4.1](<6.4.1 Awareness.md>)

Axial age, [§8.14](<8.14 Spirituality.md>), [§8.14.4](<8.14.4 What is Confirmed.md>)

B-theory of time, [§6.3.2](<6.3.2 Eternity.md>), [§7.2.1](<7.2.1 What is Disputed.md>), [§7.2.2](<7.2.2 What is Required.md>); *see also* A-theory of time; Block universe; Eternalism

Bacterial cognition, [§7.8](<7.8 Life.md>), Appendix D

Badness of death, [§8.7.1](<8.7.1 What is Disputed.md>), [§8.7.3](<8.7.3 What is Predicted.md>), [§8.7.5](<8.7.5 What is Concluded.md>)

Bagdikian, Ben H., [§9.4.2](<9.4.2 What is Required.md>) Information required. Bagdikian on media-ownership concentration and the contraction of narrative diversity under concentrated control.

Bañezian physical premotion, [§6.7.4](<6.7.4 Sovereignty.md>)

Barrett, Justin, [§8.14](<8.14 Spirituality.md>), [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Barth, Karl, [§6.8.3](<6.8.3 Describability.md>), [§6.8.4](<6.8.4 Revelation.md>)

Barthian Christological election, [§6.7.4](<6.7.4 Sovereignty.md>)

Basic emotion theory, [§8.2.1](<8.2.1 What is Disputed.md>)

Bayesian epistemology, [§8.4.1](<8.4.1 What is Disputed.md>)

Beatitude (divine), [§6.5.2](<6.5.2 Beatitude.md>)

Beaudoin, John, [§4.2.9](<4.2.9 Existential Inertia.md>)

Beauty, [§8.13](<8.13 Art.md>), [§8.13.5](<8.13.5 What is Concluded.md>)

Beauvoir, [§8.7.1](<8.7.1 What is Disputed.md>), [§8.8](<8.8 Meaning.md>), [§8.8.1](<8.8.1 What is Disputed.md>)

Becker, Ernest, [§8.7](<8.7 Mortality.md>), [§8.7.1](<8.7.1 What is Disputed.md>), [§8.7.4](<8.7.4 What is Confirmed.md>), [§8.7.5](<8.7.5 What is Concluded.md>)

*Befindlichkeit*, [§8.2.4](<8.2.4 What is Confirmed.md>)

Beitz, Charles R., [§9.11](<9.11 Defense.md>) Defense. Charles Beitz on international political theory and political equality in the cosmopolitan-international-justice tradition.

Bell inequality, [§4.3.8](<4.3.8 Non-Locality, Branching, and the Particle Concept.md>), [§7.4.4](<7.4.4 What is Confirmed.md>), Appendix D

Bell, Clive, [§8.13.1](<8.13.1 What is Disputed.md>)

Belonging, [§9.2](<9.2 Belonging.md>), [§9.2.1](<9.2.1 What is Disputed.md>)–[§9.2.5](<9.2.5 What is Concluded.md>)

Benardete paradoxes, [§5.1.2](<5.1.2 Cosmological Argument.md>) Cosmological Argument; [§7.6](<7.6 Singularity.md>) Singularity. Paradox family involving a beginningless staggered set whose members act only if no earlier member has; the Grim Reaper is its best-known form. See also Grim Reaper.

Benatar, David, [§8.6](<8.6 Sexuality.md>), [§8.6.1](<8.6.1 What is Disputed.md>), [§8.8.1](<8.8.1 What is Disputed.md>), [§9.14](<9.14 Convergence.md>)

Benevolence (divine), [§6.9.1](<6.9.1 Benevolence.md>), Appendix B item 17, Appendix D, Glossary; *see also* Inversion

Benjamin, Walter, [§8.13.1](<8.13.1 What is Disputed.md>)

Benkler, Yochai, [§9.2](<9.2 Belonging.md>), [§9.2.1](<9.2.1 What is Disputed.md>), [§9.2.3](<9.2.3 What is Predicted.md>), [§9.2.4](<9.2.4 What is Confirmed.md>), [§9.2.5](<9.2.5 What is Concluded.md>), [§9.4](<9.4 Information.md>), [§9.4.1](<9.4.1 What is Disputed.md>), [§9.4.3](<9.4.3 What is Predicted.md>), [§9.4.4](<9.4.4 What is Confirmed.md>), [§9.4.5](<9.4.5 What is Concluded.md>)

Bentham, [§8.1.1](<8.1.1 What is Disputed.md>), [§8.12.1](<8.12.1 What is Disputed.md>)

Bergmann, Michael, E.1.2 Skeptical Theism. Michael Bergmann's epistemology of skeptical theism and its attempted quarantine from ordinary moral practice.

Bergson, [§8.1](<8.1 Drive.md>), [§8.1.1](<8.1.1 What is Disputed.md>), [§8.1.5](<8.1.5 What is Concluded.md>)

Berkeley, George, [§4.3.5](<4.3.5 Idealism.md>) Idealism; [§6.1](<6.1 Greatness.md>) Greatness. Early modern philosopher; Berkeleyan idealism and immaterialism (esse est percipi).

Berlin, Isaiah, [§9.1.1](<9.1.1 What is Disputed.md>) What is Disputed. Political theorist; negative liberty and the negative-rights register in the rights debate.

Best possible world, [§4.4.9](<4.4.9 Modal Collapse Objection.md>), [§6.7.2](<6.7.2 Causality.md>); *see also* Buridan's ass; Leibniz

Bird, Alexander, [§8.3](<8.3 Knowledge.md>) Knowledge. Alexander Bird on social knowledge and distributed epistemic holdings; used in the Modal Convergence discussion.

Block, Ned, [§4.1.2](<4.1.2 Two-Dimensional Semantics.md>) Two-Dimensional Semantics. Ned Block on conceptual-role semantics and the access-versus-phenomenal consciousness distinction.

Boltzmann brains, [§2.2.2](<2.2.2 Actuality's Reach.md>) Actuality's Reach; [§7.6.4](<7.6.4 What is Confirmed.md>) Confirmation. Boltzmann-brain fluctuation scenario; even a fleeting observer must instantiate T, S, and Φ.

Bourdieu, Pierre, [§9.9.1](<9.9.1 What is Disputed.md>) Education disputed. Pierre Bourdieu and Passeron on cultural-capital reproduction and credentialing as class-hierarchy reproduction.

Bratman, Michael E., Ch. 8 Expanding the Field. Michael Bratman on intention, plans, and shared agency in the chapter's account of will and collective action.

Brennan, Jason, [§9.3](<9.3 Representation.md>) Representation. Jason Brennan's epistocratic critique of democracy; the framework distinguishes direction-recognition from policy-means competence.

Brentano, Franz, [§6.4.1](<6.4.1 Awareness.md>) Awareness. Franz Brentano's intentionality tradition: self-relating awareness and the mark of the mental.

Buchanan, James M., [§9.7](<9.7 Economy.md>) Economy. James M. Buchanan on public-choice theory and constitutional political economy; distinct from Allen Buchanan.

*Bénard cells*, [§7.8](<7.8 Life.md>), Appendix D

Big Bang, [§7.6](<7.6 Singularity.md>), [§7.7](<7.7 Cosmic History.md>)

Bilateral Self-Sustenance of Modal Structure, [§2.1.3](<2.1.3 Modal Constitution.md>), [§2.1.5](<2.1.5 The S5 Bottleneck.md>), [§2.1.6](<2.1.6 The Transition Closure.md>), Appendix D, Glossary Lemma 1

Bilateral Symmetry, [§6.1](<6.1 Greatness.md>), Appendix B item 16, Glossary Principles

Black, Max, [§4.3.12](<4.3.12 Haecceitism.md>)

Blackburn, Simon, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

Block universe, [§4.2.6](<4.2.6 Block Universe.md>), [§7.2.1](<7.2.1 What is Disputed.md>), [§7.2.2](<7.2.2 What is Required.md>), [§7.5.1](<7.5.1 Spacetime.md>); *see also* Eternalism; B-theory of time

Boethius, [§4.2.1](<4.2.1 The Changeless Ground.md>), [§6.3.2](<6.3.2 Eternity.md>), [§6.4.2](<6.4.2 Knowledge.md>), [§6.7.2](<6.7.2 Causality.md>), [§6.7.3](<6.7.3 Interaction.md>)

Boltzmann, [§7.2.4](<7.2.4 What is Confirmed.md>), [§7.6.4](<7.6.4 What is Confirmed.md>)

Borde–Guth–Vilenkin theorem, [§7.6](<7.6 Singularity.md>), [§7.7](<7.7 Cosmic History.md>)

Borgmann, Albert, [§8.11.1](<8.11.1 What is Disputed.md>)

Bostrom, Nick, [§2.2.2](<2.2.2 Actuality's Reach.md>), [§4.3.5](<4.3.5 Idealism.md>), [§8.11.1](<8.11.1 What is Disputed.md>)

Bouncing cosmology, [§7.7](<7.7 Cosmic History.md>), Appendix D

Bounded rationality, [§8.4.1](<8.4.1 What is Disputed.md>)

Boyd, Richard, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

Boyer, Pascal, [§8.14](<8.14 Spirituality.md>), [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Brandom, Robert, [§4.4.5](<4.4.5 Modal Expressivism.md>), [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Brink, David, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

Bundle Theory, [§4.3.10](<4.3.10 Bundle and Trope Theory.md>), [§7.4.2](<7.4.2 What is Required.md>)

Buridan's ass, [§6.7.2](<6.7.2 Causality.md>); *see also* Best possible world

Burke, Edmund, [§8.13](<8.13 Art.md>)

Butler, Judith, [§8.6.1](<8.6.1 What is Disputed.md>), [§8.6.5](<8.6.5 What is Concluded.md>)

Cajetan, Thomas de Vio, [§6.3.4](<6.3.4 Impassibility.md>), [§6.8.3](<6.8.3 Describability.md>), Glossary

Callender, Craig, [§1.4.1](<1.4.1 Time.md>), [§7.2.3](<7.2.3 What is Predicted.md>)

Calvin, John, [§6.7.4](<6.7.4 Sovereignty.md>), [§6.8.4](<6.8.4 Revelation.md>), Excursus E.2.4

Cambridge change, [§6.3.3](<6.3.3 Immutability.md>)

Camus, [§8.8](<8.8 Meaning.md>), [§8.8.1](<8.8.1 What is Disputed.md>), [§8.8.5](<8.8.5 What is Concluded.md>)

Cantorian argument against omniscience, [§6.4.2](<6.4.2 Knowledge.md>); *see also* Grim, Patrick; Omniscience (divine)

Capabilities approach, [§9.1](<9.1 Rights.md>), [§9.10](<9.10 Healthcare.md>), [§9.15](<9.15 Installation.md>); *see also* Nussbaum; Sen

Caplan, Bryan, [§9.3](<9.3 Representation.md>) Representation. Bryan Caplan's voter-irrationality critique in The Myth of the Rational Voter, engaged in the epistocracy discussion.

Care ethics, [§8.12.1](<8.12.1 What is Disputed.md>)

Carnap, Rudolf, [§2.10.2](<2.10.2 The Stratified Architecture.md>) Stratified Architecture. Rudolf Carnap and logical positivism on metaphysics; the book preserves disciplinary rigor while locating metaphysics at the root layer.

Carroll, Sean, [§7.6.4](<7.6.4 What is Confirmed.md>) Confirmation; [§2.2.2](<2.2.2 Actuality's Reach.md>) Actuality's Reach. Sean Carroll on the arrow of time, Boltzmann brains, naturalism, and cosmological fine-tuning.

Cartesian Certainty, [§2.2](<2.2 Cartesian Certainty.md>); *see also* *Cogito ergo muto*

Cartwright, Nancy, [§2.8.1](<2.8.1 Laws as Constitutive.md>) Laws as Constitutive. Nancy Cartwright's dappled-world account: local capacities in nomological machines still require T, S, and Φ.

Causal finitism, [§5.1.2](<5.1.2 Cosmological Argument.md>) Cosmological Argument; [§7.6](<7.6 Singularity.md>) Singularity. Thesis that infinite causal histories are impossible; the book grants its possible force while denying that it establishes the Kalām's external-cause conclusion.

Causality (divine), [§6.7.2](<6.7.2 Causality.md>)

Causation, [§1.3](<1.3 Change.md>), [§1.5.6](<1.5.6 Causation.md>), §5, [§7.4](<7.4 Substance.md>), Glossary

Cave, allegory of the (Plato), [§2.4.1](<2.4.1 Constituting Modal Structure.md>) Constituting Modal Structure. Plato's cave inverted: correction is fuller grasp of the one T–S–Φ Reality, not ascent to an exterior realm.

Chalmers, David, [§1.2.1](<1.2.1 Possibility.md>), §2, [§3.3.4](<3. Convergence.md>), [§4.1.2](<4.1.2 Two-Dimensional Semantics.md>), [§4.1.8](<4.1.8 Metaontological Deflationism.md>), [§4.3.1](<4.3.1 The Hard Problem of Consciousness.md>), [§4.3.3](<4.3.3 Russellian Monism.md>), [§4.3.2](<4.3.2 Eliminativism and Illusionism.md>), [§4.3.4](<4.3.4 Cosmopsychism.md>), [§6.4.1](<6.4.1 Awareness.md>), [§8.2](<8.2 Feeling.md>), [§8.3](<8.3 Knowledge.md>), [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.5](<8.3.5 What is Concluded.md>), [§8.10.5](<8.10.5 What is Concluded.md>), [§8.11](<8.11 Technology.md>), [§8.11.5](<8.11.5 What is Concluded.md>); *see also* Hard Problem of Consciousness; Russellian Monism

Change, [§1.3](<1.3 Change.md>), [§2.1.3](<2.1.3 Modal Constitution.md>), [§2.3](<2.3 Necessary Possibility of Change.md>), [§2.4.6](<2.4.6 Succession Requires Temporality.md>), [§2.6.6](<2.6.6 Modal Identity.md>), Glossary

Chinese Room argument, [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.5](<8.10.5 What is Concluded.md>); *see also* Searle

Chomsky, Noam, [§8.10](<8.10 Language.md>), [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.4](<8.10.4 What is Confirmed.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Churchland, Paul, [§4.3.2](<4.3.2 Eliminativism and Illusionism.md>), [§8.1.1](<8.1.1 What is Disputed.md>), [§8.4.1](<8.4.1 What is Disputed.md>)

Clark, Andy, [§8.11](<8.11 Technology.md>), [§8.11.5](<8.11.5 What is Concluded.md>); *see also* Extended mind

Classical God, [§6.1](<6.1 Greatness.md>), [§6.10](<6.10 No Exit.md>), Appendix B items 16–20, Glossary; *see also* Maximally Great Being (MGB); God-Precluded

Classical theism, [§8.14.5](<8.14.5 What is Concluded.md>)

Closed Recursive Self-Production, [§7.8](<7.8 Life.md>), Glossary

Co-instantiation Result, *see* Mutual Containment Result

Coase, Ronald H., [§9.5.3](<9.5.3 What is Predicted.md>) Environment predicted. Ronald Coase on social cost, transaction costs, and externalities; engaged alongside free-market environmentalism.

Coates, Ta-Nehisi, [§9.13](<9.13 Justice.md>) Justice. Ta-Nehisi Coates's reparations argument, especially redlining's compounding deprivation in the reparative-justice discussion.

Cobb, John B., Jr., [§4.4.8](<4.4.8 Whiteheadian Process Metaphysics.md>) Whiteheadian Process Metaphysics; §6 Relocating Greatness. John B. Cobb Jr. on process theology and the Whiteheadian inheritance account.

*Cogito ergo muto*, [§2.2.1](<2.2.1 Change Is Actual.md>), [§2.8.2](<2.8.2 Nature Cannot Be Denied.md>)

Cognitive science of religion, [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.4](<8.14.4 What is Confirmed.md>), [§8.14.5](<8.14.5 What is Concluded.md>); *see also* Agency detection

Cohen, Joshua, [§9.3](<9.3 Representation.md>) Representation; [§9.3.2](<9.3.2 What is Required.md>) Required. Joshua Cohen on deliberative democracy and equal recognition in representation.

Collingwood, R. G., [§8.13.1](<8.13.1 What is Disputed.md>)

Combinatorialism, [§4.4.3](<4.4.3 Combinatorialism.md>)

Comparative thanatology, [§8.7](<8.7 Mortality.md>), [§8.7.1](<8.7.1 What is Disputed.md>), [§8.7.4](<8.7.4 What is Confirmed.md>)

Compatibilism, [§6.7.2](<6.7.2 Causality.md>), [§6.7.4](<6.7.4 Sovereignty.md>), [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.5](<8.9.5 What is Concluded.md>)

Compositionality, [§8.10.2](<8.10.2 What is Required.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

*Conatus*, [§7.1](<7.1 Convergence of Method.md>), [§8.1](<8.1 Drive.md>), [§8.1.1](<8.1.1 What is Disputed.md>), [§8.8.3](<8.8.3 What is Predicted.md>), [§8.12.3](<8.12.3 What is Predicted.md>)

Conceivability, [§1.1](<1.1 Reality.md>), [§3.3.4](<3. Convergence.md>), [§4.1.2](<4.1.2 Two-Dimensional Semantics.md>); *see also* Possibility

Concept-Essence Identity, [§2.6.6](<2.6.6 Modal Identity.md>), [§6.2.1](<6.2.1 Simplicity.md>), Glossary Named Results

Concurrence (divine), [§6.7.1](<6.7.1 Power.md>), [§6.7.4](<6.7.4 Sovereignty.md>)

Concurrentism, [§4.2.9](<4.2.9 Existential Inertia.md>)

Condition-Individuation, [§2.6.11](<2.6.11 No Fourth Condition.md>)

Conditioned-Nature, [§2.6.12](<2.6.12 Necessity's Nature.md>), Glossary Named Results; *see also* Nature of Necessity

Consciousness, [§7.8](<7.8 Life.md>), [§4.3](<4.3 Physics and Mind.md>), [§6.4.1](<6.4.1 Awareness.md>), Glossary; *see also* Reflexive awareness

Consequentialism, [§8.12.1](<8.12.1 What is Disputed.md>)

Conservation laws, [§7.4.3](<7.4.3 What is Predicted.md>), [§7.5.3](<7.5.3 Conservation.md>)

Constitution, [§1.5.2](<1.5.2 Constitution.md>), Glossary

Constitutive Grounding Non-Propagation, [§4.4.9](<4.4.9 Modal Collapse Objection.md>)

Constitutive Instantiation, [§2.6.7](<2.6.7 Triconditional Cross-Entailment.md>), [§2.2.2](<2.2.2 Actuality's Reach.md>)

Constructionism (emotion), [§8.2.1](<8.2.1 What is Disputed.md>)

Content externalism, [§4.1.1](<4.1.1 Rigid Designation.md>), [§8.3](<8.3 Knowledge.md>); *see also* Swampman

Contingency, [§1.2](<1.2 Modal Status.md>), Glossary; *see also* Argument from contingency

Contractualism, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

Convergence of the Twelve Domains, [§9.14](<9.14 Convergence.md>)

Convergence Shows, What the, [§3.5](<3.5 What the Convergence Shows.md>)

Convergent Individualism, §9

Convergent Sustenance, §9; *see also* Convergence of the Twelve Domains

Cosmic History, [§7.7](<7.7 Cosmic History.md>), [§7.7.1](<7.7.1 What is Disputed.md>)–[§7.7.5](<7.7.5 What is Concluded.md>)

Cosmic microwave background (CMB), [§7.7](<7.7 Cosmic History.md>), Appendix D

Cosmopsychism, [§4.3.4](<4.3.4 Cosmopsychism.md>), §8

Craig, William Lane, [§5.1.2](<5.1.2 Cosmological Argument.md>), [§6.3.2](<6.3.2 Eternity.md>), [§6.4.2](<6.4.2 Knowledge.md>), [§7.6](<7.6 Singularity.md>), [§7.6.1](<7.6.1 What is Disputed.md>), [§7.6.5](<7.6.5 What is Concluded.md>), [§8.8](<8.8 Meaning.md>), [§8.8.1](<8.8.1 What is Disputed.md>), [§8.8.5](<8.8.5 What is Concluded.md>); *see also* Kalām Cosmological Argument

*Creatio ex nihilo*, [§6.3.3](<6.3.3 Immutability.md>), [§6.7.1](<6.7.1 Power.md>)

Crisp, Oliver D., [§6.7.3](<6.7.3 Interaction.md>) Interaction and related atonement sections. Oliver Crisp on incarnation and atonement in the two-natures discussion.

Critical theory, [§8.13.1](<8.13.1 What is Disputed.md>)

Cumulative culture, [§8.11](<8.11 Technology.md>), [§8.11.2](<8.11.2 What is Required.md>), [§8.11.4](<8. Expanding the Field.md>)

Cycle, [§7.6](<7.6 Singularity.md>), [§7.6.1](<7.6.1 What is Disputed.md>)–[§7.6.5](<7.6.5 What is Concluded.md>), [§2.3](<2.3 Necessary Possibility of Change.md>), [§2.8](<2.8 The Whole Line.md>), Appendix B item 22, Glossary

Cyclic cosmology, *see* Cycle

cyclist, mathematical, see mathematical cyclist

Dainton, Barry, [§4.2.2](<4.2.2 Shoemaker's Time Without Change.md>) Shoemaker's Time Without Change. Barry Dainton on time, consciousness, and the stream of experience in the time-without-change survey.

Damasio, Antonio, [§8.2](<8.2 Feeling.md>), [§8.2.1](<8.2.1 What is Disputed.md>), [§8.2.2](<8.2.2 What is Required.md>), [§8.2.4](<8.2.4 What is Confirmed.md>), [§8.3](<8.3 Knowledge.md>), [§8.5.4](<8.5.4 What is Confirmed.md>), [§8.9.4](<8.9.4 What is Confirmed.md>)

Daniels, Norman, [§9.10](<9.10 Healthcare.md>) Healthcare. Norman Daniels on just healthcare, just health, and the normal-opportunity-range argument.

Danto, Arthur, [§8.13.1](<8.13.1 What is Disputed.md>), [§8.13.5](<8.13.5 What is Concluded.md>)

*Dasein*, [§4.3.5](<4.3.5 Idealism.md>), [§8.7](<8.7 Mortality.md>)

Dasgupta, Shamik, [§2.4.7](<2.4.7 Distinction Requires Spatiality.md>), [§4.3.12](<4.3.12 Haecceitism.md>)

Davidson, Donald, [§8.3](<8.3 Knowledge.md>), [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.5](<8.9.5 What is Concluded.md>), [§8.10](<8.10 Language.md>), [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.2](<8.10.2 What is Required.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Davis, Angela Y., [§9.12](<9.12 Enforcement.md>) Enforcement; [§9.13](<9.13 Justice.md>) Justice. Angela Davis on prison abolition and the carceral state's historical record; distinct from Stephen T. Davis.

Dawkins, Richard, [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>); *see also* New Atheism

de Waal, Frans, [§8.5.5](<8.5.5 What is Concluded.md>), [§8.12.3](<8.12.3 What is Predicted.md>), [§8.12.4](<8.12.4 What is Confirmed.md>)

Decoherence, [§7.2.4](<7.2.4 What is Confirmed.md>), Appendix D

Deduction, [§8.4](<8.4 Reasoning.md>), [§8.4.1](<8.4.1 What is Disputed.md>), [§8.4.3](<8.4.3 What is Predicted.md>), [§8.4.4](<8.4.4 What is Confirmed.md>)

Default mode network, [§8.5](<8.5 Identity.md>), [§8.5.1](<8.5.1 What is Disputed.md>), [§8.5.3](<8.5.3 What is Predicted.md>), [§8.5.4](<8.5.4 What is Confirmed.md>), [§8.14.4](<8.14.4 What is Confirmed.md>)

Defense, [§9.11](<9.11 Defense.md>), [§9.11.1](<9.11.1 What is Disputed.md>)–[§9.11.5](<9.11.5 What is Concluded.md>)

Deixis, [§8.10.3](<8.10.3 What is Predicted.md>)

Della Rocca, Michael, [§2.7.3](<2.7.3 PSR Regress.md>) PSR Regress. Michael Della Rocca's universal PSR/grounding demand is assessed as presupposing the structural conditions it would ground.

Dennett, Daniel, [§4.3.2](<4.3.2 Eliminativism and Illusionism.md>), §8, [§8.3](<8.3 Knowledge.md>), [§8.5.5](<8.5.5 What is Concluded.md>), [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Deontology, [§8.12.1](<8.12.1 What is Disputed.md>)

Descartes, [§1.2.6](<1.2.6 Statuses Together.md>), [§2.2](<2.2 Cartesian Certainty.md>), [§2.2.1](<2.2.1 Change Is Actual.md>), [§2.8.2](<2.8.2 Nature Cannot Be Denied.md>), [§5.1.9](<5.1.9 Transcendental Argument.md>), [§4.3.1](<4.3.1 The Hard Problem of Consciousness.md>), [§6.3.1](<6.3.1 Necessity.md>), [§6.7.1](<6.7.1 Power.md>), [§8.3.1](<8.3.1 What is Disputed.md>), [§8.4](<8.4 Reasoning.md>), [§8.4.1](<8.4.1 What is Disputed.md>)

Describability (divine), *see* Word (divine)

Description (divine), *see* Word (divine)

Determinism, [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.5](<8.9.5 What is Concluded.md>)

*Deus sive natura*, [§6.2.2](<6.2.2 Unity.md>), [§8.14](<8.14 Spirituality.md>)

Deutsch, Eliot, [§4.3.5](<4.3.5 Idealism.md>) Idealism; Ch. 6. Eliot Deutsch on Advaita Vedānta and comparative philosophy, including the acosmic non-dualism challenge.

Deutsch, Karl W., [§9.2](<9.2 Belonging.md>) Belonging. Karl W. Deutsch on security communities and political integration; distinct from Eliot Deutsch and David Deutsch.

Dewey, John, [§8.13.1](<8.13.1 What is Disputed.md>), [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>), [§9.9.1](<9.9.1 What is Disputed.md>)

Dickie, George, [§8.13.1](<8.13.1 What is Disputed.md>), [§8.13.5](<8.13.5 What is Concluded.md>)

Dipolar theism, [§5.3.3](<5.3.3 Process Theology.md>), [§6.3.1](<6.3.1 Necessity.md>), [§6.3.2](<6.3.2 Eternity.md>), [§6.3.4](<6.3.4 Impassibility.md>), [§6.8.2](<6.8.2 Relatability.md>), [§6.2.4](<6.2.4 Perfection.md>)

Dissipative structures, [§7.8](<7.8 Life.md>), [§8.12.3](<8.12.3 What is Predicted.md>)

Distinction, [§1.3](<1.3 Change.md>), [§2.3](<2.3 Necessary Possibility of Change.md>), [§2.4.7](<2.4.7 Distinction Requires Spatiality.md>), [§4.2](<4.2 Time, Change, and the Changeless.md>), Glossary

Distributed Correction, [§9.14](<9.14 Convergence.md>), Glossary Result

Divers, John, [§4.4.1](<4.4.1 Modal Realism.md>) Modal Realism; [§4.4.4](<4.4.4 Modal Fictionalism.md>) Modal Fictionalism. John Divers on possible-worlds metaphysics and Lewisian/fictionalist variants.

Divine attributes, *see* Classical God; specific attributes (Eternity, Knowledge, Power, etc.)

Divine command theory, [§8.12.5](<8.12.5 What is Concluded.md>)

Divine conservation, [§4.2.9](<4.2.9 Existential Inertia.md>)

Divine hiddenness, [§6.8.4](<6.8.4 Revelation.md>); *see also* Schellenberg

Divine simplicity, *see* Simplicity (divine)

Dreyfus, Hubert, [§8.3.4](<8.3.4 What is Confirmed.md>), [§8.11.1](<8.11.1 What is Disputed.md>)

Drive, [§8.1](<8.1 Drive.md>), [§8.1.1](<8.1.1 What is Disputed.md>)–[§8.1.5](<8.1.5 What is Concluded.md>)

Dual-process theory, [§8.4.1](<8.4.1 What is Disputed.md>)

Dunbar, Robin, [§8.10](<8.10 Language.md>)

Duns Scotus, John, [§5.2.1](<5.2.1 Divine Simplicity.md>), [§6.8.3](<6.8.3 Describability.md>); *see also* Univocity of being

Durkheim, Émile, [§8.8.5](<8.8.5 What is Concluded.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Dutton, Denis, [§8.13](<8.13 Art.md>), [§8.13.1](<8.13.1 What is Disputed.md>), [§8.13.4](<8.13.4 What is Confirmed.md>); *see also* Evolutionary aesthetics

Earman, John, [§7.3.1](<7.3.1 What is Disputed.md>) Space disputed and Ch. 7 cosmology. John Earman on spacetime, symmetry, and thermodynamic asymmetry.

Eckhart, Meister, [§5.2.2](<5.2.2 Via Negativa.md>), [§6.8.3](<6.8.3 Describability.md>), [§8.14](<8.14 Spirituality.md>), [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.4](<8.14.4 What is Confirmed.md>), [§8.14.5](<8.14.5 What is Concluded.md>); *see also* Via negativa

Economy, [§9.7](<9.7 Economy.md>), [§9.7.1](<9.7.1 What is Disputed.md>)–[§9.7.5](<9.7.5 What is Concluded.md>)

Education, [§9.9](<9.9 Education.md>), [§9.9.1](<9.9.1 What is Disputed.md>)–[§9.9.5](<9.9.5 What is Concluded.md>)

Edwards, Jonathan, [§6.7.4](<6.7.4 Sovereignty.md>)

Ego death, [§8.5](<8.5 Identity.md>), [§8.5.3](<8.5.3 What is Predicted.md>), [§8.5.4](<8.5.4 What is Confirmed.md>)

Ehrman, Bart D., [§6.8.4](<6.8.4 Revelation.md>) Revelation; E.5.4 Final Judgment. Bart D. Ehrman on transmission, redaction, canonization, and the apocalyptic-Jesus reading.

Einstein, [§7.3](<7.3 Space.md>), [§7.5.1](<7.5.1 Spacetime.md>)

Eklund, Matti, [§4.1.8](<4.1.8 Metaontological Deflationism.md>)

*Élan vital*, [§8.1](<8.1 Drive.md>), [§8.1.1](<8.1.1 What is Disputed.md>)

Election (divine), [§6.7.4](<6.7.4 Sovereignty.md>)

Eliade, Mircea, [§8.14.5](<8.14.5 What is Concluded.md>)

Eliminativism, [§4.3.2](<4.3.2 Eliminativism and Illusionism.md>), [§8.1.1](<8.1.1 What is Disputed.md>), [§8.5.5](<8.5.5 What is Concluded.md>)

Ellul, Jacques, [§8.11.1](<8.11.1 What is Disputed.md>); *see also* Autonomy of technique

Embedded deity, [§6.1](<6.1 Greatness.md>), [§6.10](<6.10 No Exit.md>), Glossary

Embodied cognition, [§8.3](<8.3 Knowledge.md>), [§8.3.4](<8.3.4 What is Confirmed.md>)

Emergent Time, [§4.2.3](<4.2.3 Emergent Time.md>)

Empathy, [§8.12](<8.12 Morality.md>), [§8.12.3](<8.12.3 What is Predicted.md>)

Empirical predictions, Appendix D, [§7.2](<7.2 Time.md>)–[§7.8](<7.8 Life.md>)

Enforcement, [§9.12](<9.12 Enforcement.md>), [§9.12.1](<9.12.1 What is Disputed.md>)–[§9.12.5](<9.12.5 What is Concluded.md>)

Enframing (Gestell), [§8.11.1](<8.11.1 What is Disputed.md>)

Enoch, David, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

*Ens necessarium*, [§6.3.1](<6.3.1 Necessity.md>)

Entailment, [§1.5.3](<1.5.3 Inference.md>), Glossary

Entropy, [§7.2.3](<7.2.3 What is Predicted.md>), [§7.2.4](<7.2.4 What is Confirmed.md>)

Environment, [§9.5](<9.5 Environment.md>), [§9.5.1](<9.5.1 What is Disputed.md>)–[§9.5.5](<9.5.5 What is Concluded.md>)

Epicurus, [§8.7](<8.7 Mortality.md>), [§8.7.1](<8.7.1 What is Disputed.md>), [§8.7.3](<8.7.3 What is Predicted.md>), [§8.7.5](<8.7.5 What is Concluded.md>)

Epistemic possibility, [§8.4](<8.4 Reasoning.md>)

Epistemic Floor, §9, Glossary Result

Equality before the law, [§9.13](<9.13 Justice.md>) Justice. Equality before the law is substantive rather than formal: comparable wrongs must receive comparable responses regardless of wealth, with adequately resourced defense as a condition of equal standing.

Error theory, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

ET-simultaneity, [§6.3.2](<6.3.2 Eternity.md>), [§6.4.2](<6.4.2 Knowledge.md>), [§6.7.2](<6.7.2 Causality.md>)

Eternal recurrence, [§8.7.5](<8.7.5 What is Concluded.md>)

Eternalism, [§7.2.1](<7.2.1 What is Disputed.md>), [§7.2.2](<7.2.2 What is Required.md>); *see also* Block universe; B-theory of time

Eternity, *see* Tensity (divine)

Ethics (Spinoza), Textual citations to Spinoza's Ethics (1677/1996): [§2.9](<2.9 Precedent Convergence.md>) (Precedent Convergence), [§5.3.1](<5.3.1 Spinozist Pantheism.md>) (Spinozist Pantheism), [§4.4.9](<4.4.9 Modal Collapse Objection.md>) (Modal Collapse Objection), [§6.2.2](<6.2.2 Unity.md>) (Unity), [§8.1](<8.1 Drive.md>) (Drive), [§8.1.1](<8.1.1 What is Disputed.md>). Theology: Coda (What God Could the Evidence Allow?). Distinct entry from the person Spinoza, which indexes his broader philosophical role across the book.

Euclidean Axiom, [§2.1.4](<2.1.4 Modal Stability.md>), [§2.1.6](<2.1.6 The Transition Closure.md>), Glossary Principles

Eudaimonia, [§8.8.3](<8.8.3 What is Predicted.md>)

Euthyphro dilemma, [§6.9.1](<6.9.1 Benevolence.md>), [§6.2.4](<6.2.4 Perfection.md>)

Everett, Hugh, [§4.3.8](<4.3.8 Non-Locality, Branching, and the Particle Concept.md>), [§7.7.4](<7.7.4 What is Confirmed.md>)

Evil-God challenge, Excursus E.1.8

Evolutionary aesthetics, [§8.13.1](<8.13.1 What is Disputed.md>), [§8.13.4](<8.13.4 What is Confirmed.md>)

Evolutionary debunking argument, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

Exchange, [§1.3](<1.3 Change.md>), [§2.3](<2.3 Necessary Possibility of Change.md>), [§2.4.8](<2.4.8 Exchange Requires Physicality.md>), §5, Glossary

Exclusivity of Nature, [§2.8.6](<2.8.6 Exclusivity of Nature.md>), [§2.7](<2.7 Nothing to Consider.md>), [§3.2.6](<3. Convergence.md>), Appendix B item 13, Glossary Theorem 7

Existence, [§1.5](<1.5 Existence.md>), [§1.5.1](<1.5.1 Existence and Instantiation.md>)

Existential inertia, [§4.2.9](<4.2.9 Existential Inertia.md>)

Existential risk, [§8.11.1](<8.11.1 What is Disputed.md>)

Existentialism, [§8.8](<8.8 Meaning.md>), [§8.8.1](<8.8.1 What is Disputed.md>)

Expression theory of art, [§8.13.1](<8.13.1 What is Disputed.md>)

Expressivism, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

Extended mind, [§8.11](<8.11 Technology.md>), [§8.11.5](<8.11.5 What is Concluded.md>)

Exterior Modal Map, [§8.11](<8.11 Technology.md>), [§5.1.5](<5.1.5 Fine-Tuning Argument.md>), Glossary; *see also* Modal Map

Exterior modal maps, [§8.11](<8.11 Technology.md>), [§8.11.2](<8.11.2 What is Required.md>)

Fact of Nature, *see* Triconditional Identity

Fatalism, [§7.7](<7.7 Cosmic History.md>), Appendix D

Feeling, [§8.2](<8.2 Feeling.md>), [§8.2.1](<8.2.1 What is Disputed.md>)–[§8.2.5](<8.2.5 What is Concluded.md>)

Feinberg, Joel, [§9.4](<9.4 Information.md>) Information. Joel Feinberg's child's right to an open future and information rights that bind against intermediate authorities.

Feser, Edward, [§4.2.9](<4.2.9 Existential Inertia.md>)

Field, [§7.5.2](<7.5.2 Field.md>), [§7.3](<7.3 Space.md>), Glossary

Final cause, [§6.7.2](<6.7.2 Causality.md>)

Fine, Kit, [§4.4.9](<4.4.9 Modal Collapse Objection.md>)

Fine-tuning, [§5.1.5](<5.1.5 Fine-Tuning Argument.md>), [§7.7](<7.7 Cosmic History.md>), Appendix D

First-person / Third-person, [§7.1](<7.1 Convergence of Method.md>), [§8.4.4](<8.4.4 What is Confirmed.md>), [§8.7.2](<8.7.2 What is Required.md>), Glossary; *see also* Reflexive awareness

Fischer, John Martin, [§9.13](<9.13 Justice.md>) Justice and its free-will discussion. John Martin Fischer on moral responsibility and semicompatibilism, with Mark Ravizza.

Fishkin, James S., [§9.2.4](<9.2.4 What is Confirmed.md>) Belonging confirmed. James S. Fishkin on deliberative polling and face-to-face venues that inform recognized public direction.

Flint, Thomas P., [§6.4.2](<6.4.2 Knowledge.md>) Divine Knowledge; [§6.7.4](<6.7.4 Sovereignty.md>) Sovereignty; [§6.5](<6.5 Intrinsic Value.md>). Molinism, divine providence, and maximal power, with Alfred Freddoso.

Fodor, Jerry A., [§2.10.2](<2.10.2 The Stratified Architecture.md>) Stratified Architecture. Jerry Fodor on special sciences and levels of organization in the anti-reductive scientific architecture.

Foot, Philippa, [§8.12.1](<8.12.1 What is Disputed.md>)

Foreclosed positions, Appendix D, [§3.1](<3.1 Necessary Possibility of Change.md>)–[§3.5](<3.5 What the Convergence Shows.md>), [§7.6](<7.6 Singularity.md>)–[§7.8](<7.8 Life.md>)

Foreign terms, *see* Glossary, Foreign and Technical Terms

Foreknowledge, [§6.4.2](<6.4.2 Knowledge.md>)

Formalism (aesthetics), [§8.13.1](<8.13.1 What is Disputed.md>)

*Fostering (and corroding)*, [§8.12](<8.12 Morality.md>), [§8.12.2](<8.12.2 What is Required.md>)

Foucault, [§8.6.1](<8.6.1 What is Disputed.md>), [§8.6.5](<8.6.5 What is Concluded.md>)

Four-mode framing, [§7.1](<7.1 Convergence of Method.md>)

Frankfurt cases, [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.5](<8.9.5 What is Concluded.md>)

Frankfurt, Harry, [§7.7.1](<7.7.1 What is Disputed.md>), [§7.7.2](<7.7.2 What is Required.md>), §8, [§8.4.4](<8.4.4 What is Confirmed.md>), [§8.8](<8.8 Meaning.md>), [§8.8.1](<8.8.1 What is Disputed.md>), [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.5](<8.9.5 What is Concluded.md>), [§8.12](<8.12 Morality.md>), [§9.13.1](<9.13.1 What is Disputed.md>)

Frankish, Keith, [§4.3.2](<4.3.2 Eliminativism and Illusionism.md>), §8, [§8.3](<8.3 Knowledge.md>), [§8.5.5](<8.5.5 What is Concluded.md>)

Frankl, Viktor, [§8.8.4](<8.8.4 What is Confirmed.md>)

Freddoso, Alfred J., [§4.2.9](<4.2.9 Existential Inertia.md>)

Free will, [§8.9](<8.9 Will.md>), [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.2](<8.9.2 What is Required.md>), [§8.9.5](<8.9.5 What is Concluded.md>)

Frege, Gottlob, [§2.6.2](<2.6.2 Succession's Two Conditions.md>), [§2.10.3](<2.10.3 The Metalogical Position.md>), [§4.2.4](<4.2.4 Platonism.md>), [§4.4.10](<4.4.10 Gasking's Parody of the Ontological Argument.md>), [§8.4](<8.4 Reasoning.md>), [§8.4.1](<8.4.1 What is Disputed.md>), [§8.10](<8.10 Language.md>), [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.2](<8.10.2 What is Required.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Freire, Paulo, [§9.9](<9.9 Education.md>) Education. Paulo Freire's dialogical critical pedagogy as capacity cultivation rather than content transfer.

French, Steven, [§2.6.8](<2.6.8 Ontological Identity.md>) Ontological Identity. Steven French on ontic structural realism and the metaphysics of physics, allied with but distinct from the book's structural account.

Freud, [§8.1](<8.1 Drive.md>), [§8.1.1](<8.1.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Friedman, Milton, [§9.7](<9.7 Economy.md>) Economy and [§9.9](<9.9 Education.md>) Education. Milton Friedman on free-market liberalism, vouchers, and the land-value-tax convergence.

Frozen-world test, [§2.4.11](<2.4.11 The Frozen-World Test.md>), Appendix B item 7

Garland-Thomson, Rosemarie, [§9.10](<9.10 Healthcare.md>) Healthcare. Rosemarie Garland-Thomson on disability, selection, and the disability-rights critique of selectionist regimes.

Gasking, Douglas, [§4.4.10](<4.4.10 Gasking's Parody of the Ontological Argument.md>)

Gauge symmetry, [§7.3.4](<7.3.4 What is Confirmed.md>), [§7.5.4](<7.5.4 Symmetry.md>), Appendix D

General relativity, [§7.3](<7.3 Space.md>), [§7.5.1](<7.5.1 Spacetime.md>)

Gettier problem, [§8.3](<8.3 Knowledge.md>), [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.4](<8.3.4 What is Confirmed.md>)

Gettier, Edmund, [§8.3](<8.3 Knowledge.md>), [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.3](<8.3.3 What is Predicted.md>), [§8.3.4](<8.3.4 What is Confirmed.md>)

Gibbard, Allan, [§4.1.6](<4.1.6 Quinean Modal Skepticism.md>), [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

Gigerenzer, Gerd, [§8.4.1](<8.4.1 What is Disputed.md>)

Gilens, Martin, [§9.3.3](<9.3.3 What is Predicted.md>) Representation predicted. Martin Gilens, with Benjamin Page, on wealth-filtered political influence and policy tracking.

Gilligan, Carol, [§8.12.1](<8.12.1 What is Disputed.md>)

Gilmore, Ruth Wilson, [§9.13](<9.13 Justice.md>) Justice and related carceral analysis. Ruth Wilson Gilmore on prison expansion, abolitionist theory, and the carceral state.

God, *see* Classical God; Embedded deity; Maximally Great Being (MGB); Three Conceptions of God

God-Precluded, [§6.10](<6.10 No Exit.md>), Appendix B item 20, Glossary; *see also* Classical God; No Exit

Goff, Philip, [§4.3.3](<4.3.3 Russellian Monism.md>), [§4.3.4](<4.3.4 Cosmopsychism.md>), §8, [§8.2](<8.2 Feeling.md>); *see also* Russellian Monism

Golden Rule, [§8.12.3](<8.12.3 What is Predicted.md>), [§8.12.4](<8.12.4 What is Confirmed.md>)

Goldman, Alvin, [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.3](<8.3.3 What is Predicted.md>), [§8.11](<8.11 Technology.md>)

Goodman, Nelson, [§4.3.11](<4.3.11 Mereological Nihilism.md>) Mereological Nihilism. Nelson Goodman on the new riddle of induction and the classical mereological tradition.

Gossip, [§8.10](<8.10 Language.md>)

Great-making properties, [§6.1](<6.1 Greatness.md>), [§6.2.4](<6.2.4 Perfection.md>); *see also* Maximally Great Being (MGB); Perfection (divine)

Grice, Paul, [§8.10.5](<8.10.5 What is Concluded.md>)

Grim, Patrick, [§6.4.2](<6.4.2 Knowledge.md>); *see also* Cantorian argument against omniscience; Omniscience (divine)

Grim Reaper paradox, [§5.1.2](<5.1.2 Cosmological Argument.md>) Cosmological Argument; [§7.6](<7.6 Singularity.md>) Singularity. Benardete-style paradox deployed for causal finitism; the book addresses its categorial limits, its S/Φ assumptions, and its future-symmetry implications.

Grounding, [§1.5.5](<1.5.5 Ground and Dependence.md>), [§4.1.10](<4.1.10 The Source of Possibility.md>), [§5.1.1](<5.1.1 Rasmussen's Foundation Argument.md>), Glossary

Growing block, [§7.2.1](<7.2.1 What is Disputed.md>); *see also* Presentism; Eternalism

Grünbaum, Adolf, [§7.6.5](<7.6.5 What is Concluded.md>) Singularity concluded. Adolf Grünbaum on physical cosmology, creation questions, and critiques of theological interpretations of the Big Bang.

Habermas, Gary R., [§6.8.4](<6.8.4 Revelation.md>) Revelation and The Resurrection excursus. Gary R. Habermas on the minimal-facts resurrection argument, presented and assessed as part of the evidential case.

Habermas, Jürgen, [§2.2](<2.2 Cartesian Certainty.md>), [§2.4.3](<2.4.3 Demand Instantiation.md>), [§9.1](<9.1 Rights.md>), [§9.1.4](<9.1.4 What is Confirmed.md>), [§9.2](<9.2 Belonging.md>), [§9.2.4](<9.2.4 What is Confirmed.md>), [§9.3](<9.3 Representation.md>), [§9.3.1](<9.3.1 What is Disputed.md>), [§9.3.2](<9.3.2 What is Required.md>), [§9.3.4](<9.3.4 What is Confirmed.md>), [§9.4](<9.4 Information.md>), [§9.4.1](<9.4.1 What is Disputed.md>), [§9.4.4](<9.4.4 What is Confirmed.md>), [§9.12](<9.12 Enforcement.md>), [§9.13](<9.13 Justice.md>), [§9.15](<9.15 Installation.md>)

Hacking, Ian, [§5.1.5](<5.1.5 Fine-Tuning Argument.md>) Fine-Tuning Argument. Ian Hacking on observer selection and the inverse gambler's fallacy in multiverse-to-design inference.

Haecceity, [§4.3.12](<4.3.12 Haecceitism.md>), [§6.2.2](<6.2.2 Unity.md>)

Haidt, Jonathan, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.4](<8.12.4 What is Confirmed.md>)

Hale, Bob, [§4.1.7](<4.1.7 Modal Conventionalism.md>) Modal Conventionalism. Bob Hale's critique of conventionalist accounts of necessity and necessary beings.

Hamilton (principle of stationary action), [§7.5.4](<7.5.4 Symmetry.md>), Appendix D

Haraway, Donna, [§8.11.1](<8.11.1 What is Disputed.md>); *see also* Posthumanism

Hardin, Garrett, [§9.5.3](<9.5.3 What is Predicted.md>) Environment predicted. Garrett Hardin's tragedy of the commons, qualified by Ostrom's collective-management cases.

Hard incompatibilism, [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.5](<8.9.5 What is Concluded.md>)

Hard Problem of Consciousness, [§4.3.1](<4.3.1 The Hard Problem of Consciousness.md>)

Hare, John E., [§5.1.10](<5.1.10 Moral Argument.md>) Moral Argument; E.3.4 Moral Gap. Moral philosopher; the moral-gap argument for divine assistance and its structural reconstruction.

Harman, Gilbert, [§4.1.2](<4.1.2 Two-Dimensional Semantics.md>) Two-Dimensional Semantics. Philosopher; moral relativism, inference to the best explanation, and conceptual-role semantics in the semantic debate.

Harm principle, [§8.12](<8.12 Morality.md>), [§8.12.1](<8.12.1 What is Disputed.md>)

Hart, H. L. A., [§8.9.4](<8.9.4 What is Confirmed.md>), [§8.9.5](<8.9.5 What is Concluded.md>)

Hartshorne, Charles, [§5.3.3](<5.3.3 Process Theology.md>), [§6.3.2](<6.3.2 Eternity.md>), [§6.3.3](<6.3.3 Immutability.md>), [§6.3.4](<6.3.4 Impassibility.md>), [§6.8.2](<6.8.2 Relatability.md>), [§6.9.1](<6.9.1 Benevolence.md>), [§6.2.4](<6.2.4 Perfection.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Hasker, William, [§6.2.1](<6.2.1 Simplicity.md>) Simplicity; [§6.4.2](<6.4.2 Knowledge.md>) Knowledge. Philosopher of religion; open theism and emergent dualism in the divine-knowledge and simplicity debates.

Haslanger, Sally, [§9.2.1](<9.2.1 What is Disputed.md>) What is Disputed. Philosopher; social construction and ameliorative analysis, invoked against treating membership boundaries as natural or brute.

Hauerwas, Stanley, Hauerwas's Christian nonviolence is part of the pacifist challenge to the recognition-based account of defense at §[§9.11](<9.11 Defense.md>)–9.11.1.

Hawking, [§7.6](<7.6 Singularity.md>)

Hawking points, [§7.6](<7.6 Singularity.md>), Appendix D

Hayek, Friedrich A., Classical-liberal political economy and the knowledge problem in [§9.7](<9.7 Economy.md>) and [§9.7.1](<9.7.1 What is Disputed.md>); the duty-bearer objection to positive rights in [§9.1](<9.1 Rights.md>) and [§9.1.1](<9.1.1 What is Disputed.md>).

Healey, Richard, Healey's effective-theory reading of the quantum-gravity interface frames the type/token seam at §[§7.7.1](<7.7.1 What is Disputed.md>)–7.7.2 and the unresolved coupling question at [§7.7.5](<7.7.5 What is Concluded.md>).

Healthcare, [§9.10](<9.10 Healthcare.md>), [§9.10.1](<9.10.1 What is Disputed.md>)–[§9.10.5](<9.10.5 What is Concluded.md>)

Hedonism, [§8.1.1](<8.1.1 What is Disputed.md>)

Hegel, [§7.1](<7.1 Convergence of Method.md>), [§9.2](<9.2 Belonging.md>), [§9.2.1](<9.2.1 What is Disputed.md>)

Heidegger, [§2.2.3](<2.2.3 Witness's Reach.md>), [§4.3.5](<4.3.5 Idealism.md>), [§8.2.4](<8.2.4 What is Confirmed.md>), [§8.7](<8.7 Mortality.md>), [§8.7.1](<8.7.1 What is Disputed.md>), [§8.7.4](<8.7.4 What is Confirmed.md>), [§8.8.3](<8.8.3 What is Predicted.md>), [§8.11.1](<8.11.1 What is Disputed.md>), [§8.13.1](<8.13.1 What is Disputed.md>)

Held, David, Held's cosmopolitan and transnational-institutionalist challenge is staged in the defense discussion at §[§9.11](<9.11 Defense.md>)–9.11.1.

Heller, Mark, [§4.2.7](<4.2.7 The Problem of Temporary Intrinsics.md>) The Problem of Temporary Intrinsics; [§4.2.8](<4.2.8 Stage Theory.md>) Stage Theory. Metaphysician; four-dimensionalism, stage theory, and material objects.

Helm, Paul, Helm's Reformed defense of divine eternity is engaged at [§6.3.2](<6.3.2 Eternity.md>); his effect-only defense of impassible mercy is engaged in the divine-righteousness analysis at [§6.9.2](<6.9.2 Righteousness.md>).

Hempel, Carl G., Hempel's unity-of-science work is engaged in the stratified-architecture account at [§2.10.2](<2.10.2 The Stratified Architecture.md>), which relocates the scientific root below physics to the three logical Conditions.

Heraclitus, [§1.5.8](<1.5.8 Persistence.md>), [§7.1](<7.1 Convergence of Method.md>)

Herman, Edward S., Herman and Chomsky's propaganda model informs the ownership-concentration condition at [§9.4.2](<9.4.2 What is Required.md>), the empirical confirmation of narrative distortion at [§9.4.4](<9.4.4 What is Confirmed.md>), and the critical political-economy position in [§9.4.1](<9.4.1 What is Disputed.md>).

Hick, John, [§6.2.2](<6.2.2 Unity.md>), [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>), Excursus E.1.5

Hilbert's Hotel, [§5.1.2](<5.1.2 Cosmological Argument.md>) Cosmological Argument; [§7.6](<7.6 Singularity.md>) Singularity. Hilbert's Grand Hotel paradox, used in the completed-infinity and Kalām discussions.

Hintikka, Jaakko, Hintikka's performative reading of the Cogito clarifies the change witness in §[§2.2](<2.2 Cartesian Certainty.md>)–2.2.1.

Hirsch, Eli, [§4.1.8](<4.1.8 Metaontological Deflationism.md>)

Hirschman, Albert O., [§9.1](<9.1 Rights.md>) Rights. Economist; exit, voice, and loyalty as the dynamics of reciprocity, reform, and institutional failure.

Hobbes, [§8.9.1](<8.9.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>), [§9.12](<9.12 Enforcement.md>)

Hoffman, Joshua, Hoffmann and Rosenkrantz's work on divine attributes informs the omnipresence analysis at [§6.8.1](<6.8.1 Presence.md>) and the perfect-being discussion at [§6.2.4](<6.2.4 Perfection.md>).

Holiness (divine), [§6.5.1](<6.5.1 Holiness.md>)

Holographic principle, [§7.4.4](<7.4.4 What is Confirmed.md>), [§7.5.2](<7.5.2 Field.md>)

Housing, Principal [§9.8](<9.8 Housing.md>); the political conditions of secure, non-displacing dwelling and the social infrastructure that makes belonging materially available.

Hudson, Hud, Hudson's four-dimensionalist metaphysics is engaged in the persistence debates at §[§4.2.7](<4.2.7 The Problem of Temporary Intrinsics.md>)–4.2.8 and in the omnipresence analysis at [§6.8.1](<6.8.1 Presence.md>).

Huemer, Michael, Huemer's aesthetic-epistemic simplicity principle is engaged in the Swinburne simplicity argument at [§5.1.4](<5.1.4 Argument from Simplicity.md>), where the book locates aesthetic simplicity within structurally embedded evaluation.

Hume, [§1.5.6](<1.5.6 Causation.md>), [§2.6.11](<2.6.11 No Fourth Condition.md>), [§4.1.3](<4.1.3 Principle of Sufficient Reason.md>), [§4.1.4](<4.1.4 Humean Contingency.md>), [§5.1.2](<5.1.2 Cosmological Argument.md>), [§6.8.4](<6.8.4 Revelation.md>), [§8.2](<8.2 Feeling.md>), [§8.2.1](<8.2.1 What is Disputed.md>), [§8.2.4](<8.2.4 What is Confirmed.md>), [§8.2.5](<8.2.5 What is Concluded.md>), [§8.4](<8.4 Reasoning.md>), [§8.4.1](<8.4.1 What is Disputed.md>), [§8.8.1](<8.8.1 What is Disputed.md>), [§8.9.1](<8.9.1 What is Disputed.md>), [§8.12](<8.12 Morality.md>), [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.3](<8.12.3 What is Predicted.md>), [§8.12.5](<8.12.5 What is Concluded.md>), Intro., Excursus E.4.3

Husserl, [§2.2.3](<2.2.3 Witness's Reach.md>), [§6.4.1](<6.4.1 Awareness.md>), [§8.2.4](<8.2.4 What is Confirmed.md>)

Idealism, [§4.3.5](<4.3.5 Idealism.md>), [§6.1](<6.1 Greatness.md>)

Identity, [§8.5](<8.5 Identity.md>)

Identity (divine), *see* Simplicity (divine)

Identity (first-person), [§8.5](<8.5 Identity.md>), [§8.5.1](<8.5.1 What is Disputed.md>)–[§8.5.5](<8.5.5 What is Concluded.md>), Glossary; *see also* Reflexive awareness

Identity of indiscernibles, [§4.3.12](<4.3.12 Haecceitism.md>), [§6.2.1](<6.2.1 Simplicity.md>), [§6.2.2](<6.2.2 Unity.md>)

Identity of Reality and Nature, [§7.9](<7.9 Synthesis.md>), [§1.4.4](<1.4.4 Triconditional Structure.md>), [§2.8.5](<2.8.5 Necessity of Nature.md>)

Illusionism, [§4.3.2](<4.3.2 Eliminativism and Illusionism.md>), [§8.5.5](<8.5.5 What is Concluded.md>)

Immateriality (¬Φ), [§6.1](<6.1 Greatness.md>), [§6.7.1](<6.7.1 Power.md>), [§6.10](<6.10 No Exit.md>), Appendix B item 15; *see also* Atemporality (¬T); Aspatial existence (¬S); Supernatural Preclusion; Substance

Immutability (divine), [§6.3.3](<6.3.3 Immutability.md>); *see also* Tensity (divine); Impassibility (divine)

Impassibility (divine), [§6.3.4](<6.3.4 Impassibility.md>); *see also* Immutability (divine)

Impeccability, [§6.9.1](<6.9.1 Benevolence.md>)

Impermanence, [§8.7](<8.7 Mortality.md>), [§8.7.1](<8.7.1 What is Disputed.md>)

Impossibility, [§1.1](<1.1 Reality.md>), [§2.1](<2.1 The S5 Pipeline.md>), [§2.2](<2.2 Cartesian Certainty.md>); *see also* Possibility; Necessity

Incarnation, [§6.3.3](<6.3.3 Immutability.md>), [§6.3.4](<6.3.4 Impassibility.md>)

Incompossibility of divine attributes, [§6.2.4](<6.2.4 Perfection.md>)

Indeterminacy of translation, [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Individual existence, *see* Occupancy Condition

Induction, [§8.4.1](<8.4.1 What is Disputed.md>), [§8.4.3](<8.4.3 What is Predicted.md>), [§8.4.4](<8.4.4 What is Confirmed.md>)

Infinity (divine), [§6.2.3](<6.2.3 Infinity.md>)

Information, [§9.4](<9.4 Information.md>), [§9.4.1](<9.4.1 What is Disputed.md>)–[§9.4.5](<9.4.5 What is Concluded.md>)

Information paradox, [§7.4.4](<7.4.4 What is Confirmed.md>), Appendix D

Information-Theoretic Foundationalism, [§4.1.5](<4.1.5 Information-Theoretic Foundationalism.md>)

Informed consent, [§8.9.4](<8.9.4 What is Confirmed.md>), [§8.9.5](<8.9.5 What is Concluded.md>)

Installing the Framework, [§9.15](<9.15 Installation.md>)

Instantiation, [§1.5](<1.5 Existence.md>), [§1.5.1](<1.5.1 Existence and Instantiation.md>); see also Existence

Institutional theory of art, [§8.13.1](<8.13.1 What is Disputed.md>), [§8.13.5](<8.13.5 What is Concluded.md>)

Instrumentalism (technology), [§8.11](<8.11 Technology.md>), [§8.11.1](<8.11.1 What is Disputed.md>), [§8.11.2](<8.11.2 What is Required.md>)

Intelligent Design, [§5.1.6](<5.1.6 Intelligent Design.md>), [§7.8](<7.8 Life.md>)

Intelligibility, [§8.4.3](<8.4.3 What is Predicted.md>)

Interaction (divine), [§6.7.3](<6.7.3 Interaction.md>)

Inversion, §6, Appendix B item 17, Glossary

Inverted spectrum, The inverted-spectrum and fading-qualia challenges to the recursion account of affect are addressed at [§8.2](<8.2 Feeling.md>), with the detailed structural-residue defense routed to [§8.3](<8.3 Knowledge.md>) §A2.

*Ipsum esse subsistens*, [§6.2.1](<6.2.1 Simplicity.md>)

Is/ought gap, [§8.12](<8.12 Morality.md>), [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.3](<8.12.3 What is Predicted.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

Jackson, Frank, [§4.3.1](<4.3.1 The Hard Problem of Consciousness.md>), [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.4](<8.3.4 What is Confirmed.md>), [§8.3.5](<8.3.5 What is Concluded.md>); *see also* Knowledge argument

James, William, [§5.1.11](<5.1.11 Pascal's Wager.md>), [§8.2.1](<8.2.1 What is Disputed.md>), [§8.2.4](<8.2.4 What is Confirmed.md>), [§8.3.4](<8.3.4 What is Confirmed.md>), [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.4](<8.14.4 What is Confirmed.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

James-Lange theory, [§8.2.1](<8.2.1 What is Disputed.md>), [§8.2.4](<8.2.4 What is Confirmed.md>)

Jonas, Hans, [§8.12.3](<8.12.3 What is Predicted.md>)

Joyce, Richard, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>); *see also* Evolutionary debunking argument; Moral nihilism

Jurisdictional Dilemma, [§3.5](<3.5 What the Convergence Shows.md>)

Justice, [§9.13](<9.13 Justice.md>), [§9.13.1](<9.13.1 What is Disputed.md>)–[§9.13.5](<9.13.5 What is Concluded.md>)

Kaba, Mariame, Kaba's prison-abolitionist organizing is engaged in the enforcement debate at §[§9.12](<9.12 Enforcement.md>)–9.12.1 and in the justice debate at §[§9.13](<9.13 Justice.md>)–9.13.1.

Kafer, Alison, Kafer's disability-rights critique of selectionist regimes is engaged as ongoing policy-design pressure in the healthcare and reproductive-autonomy discussions at §[§9.10](<9.10 Healthcare.md>)–9.10.1.

Kahneman, Daniel, [§8.4.1](<8.4.1 What is Disputed.md>), [§8.12](<8.12 Morality.md>)

Kalām Cosmological Argument, [§5.1.2](<5.1.2 Cosmological Argument.md>), [§7.6](<7.6 Singularity.md>); *see also* Craig, William Lane

Kane, Robert, [§7.7.1](<7.7.1 What is Disputed.md>), [§7.7.2](<7.7.2 What is Required.md>), [§8.9.1](<8.9.1 What is Disputed.md>)

Kant, [§2.2.3](<2.2.3 Witness's Reach.md>), [§2.10.3](<2.10.3 The Metalogical Position.md>), [§4.3.5](<4.3.5 Idealism.md>), [§5.1.3](<5.1.3 Simultaneous Causation.md>), [§6.2.1](<6.2.1 Simplicity.md>), [§6.3.1](<6.3.1 Necessity.md>), [§8.4](<8.4 Reasoning.md>), [§8.4.1](<8.4.1 What is Disputed.md>), [§8.12.1](<8.12.1 What is Disputed.md>), [§8.13](<8.13 Art.md>), [§9.11.1](<9.11.1 What is Disputed.md>), [§9.13.1](<9.13.1 What is Disputed.md>), Intro., Excursus E.2.3

Kim, Jaegwon, [§2.10.2](<2.10.2 The Stratified Architecture.md>), The Stratified Architecture: Kim's levels-of-reality work and Mind in a Physical World (1998) are used as a non-reductive stratification precedent that still places physics at the foundational level.

Kimmerer, Robin Wall, Kimmerer's Indigenous environmental philosophy and kinship-with-land framing are engaged in the intergenerational-stewardship account at §[§9.5](<9.5 Environment.md>)–9.5.1 and in the agricultural stewardship account at [§9.6](<9.6 Agriculture.md>).

Klein, Naomi, Klein's analysis of disaster capitalism and defense-industry capture informs the political-economy critique of defense at [§9.11](<9.11 Defense.md>).

Klinenberg, Eric, Klinenberg's social-infrastructure work supports the civic-infrastructure and resilience arguments in Belonging at §[§9.2.1](<9.2.1 What is Disputed.md>)–9.2.4.

Knowledge, [§8.3](<8.3 Knowledge.md>)

Knowledge (divine), *see* Omniscience (divine)

Knowledge (first-person), [§8.3](<8.3 Knowledge.md>), [§8.3.1](<8.3.1 What is Disputed.md>)–[§8.3.5](<8.3.5 What is Concluded.md>); *see also* Modal Field; Modal Convergence Theorem; Will (first-person)

Knowledge argument, [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.4](<8.3.4 What is Confirmed.md>), [§8.3.5](<8.3.5 What is Concluded.md>)

Knowledge by acquaintance, [§8.3](<8.3 Knowledge.md>), [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.3](<8.3.3 What is Predicted.md>), [§8.3.4](<8.3.4 What is Confirmed.md>), [§8.3.5](<8.3.5 What is Concluded.md>)

Koons, Robert C., Koons's cosmological and formal-metaphysical arguments are engaged in the PSR analysis ([§4.1.3](<4.1.3 Principle of Sufficient Reason.md>)), the cosmological argument ([§5.1.2](<5.1.2 Cosmological Argument.md>)), and Rasmussen's foundation argument ([§5.1.1](<5.1.1 Rasmussen's Foundation Argument.md>)).

Korsgaard, Christine, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>), [§9.6](<9.6 Agriculture.md>), [§9.6.5](<9.6.5 What is Concluded.md>); *see also* Moral constructivism

Kraay, Klaas, Kraay's work on theistic multiverse and no-best-world problems is engaged in the divine-causality analysis at [§6.7.2](<6.7.2 Causality.md>) and in the modal-structure-unity discussion at [§6.2.2](<6.2.2 Unity.md>).

Kripke, [§1.1](<1.1 Reality.md>), [§1.2.1](<1.2.1 Possibility.md>), §2, [§2.1.4](<2.1.4 Modal Stability.md>), [§2.4](<2.4 Structural Requirement.md>), [§2.6.6](<2.6.6 Modal Identity.md>), [§2.8.5](<2.8.5 Necessity of Nature.md>), [§3.4.2](<3. Convergence.md>), [§4.1.1](<4.1.1 Rigid Designation.md>), [§4.3.1](<4.3.1 The Hard Problem of Consciousness.md>), [§4.4](<4.4 Modal Variants and Extensions.md>), [§5.1.5](<5.1.5 Fine-Tuning Argument.md>), [§8.3](<8.3 Knowledge.md>), [§8.4](<8.4 Reasoning.md>), [§8.10](<8.10 Language.md>), [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.5](<8.10.5 What is Concluded.md>), Intro.

Kvanvig, Jonathan L., [§4.2.9](<4.2.9 Existential Inertia.md>)

Laclau, Ernesto, Post-Marxist political theory; hegemony and radical democracy, with Mouffe (Hegemony and Socialist Strategy 1985). [§9.15](<9.15 Installation.md>).

Ladyman, James, [§2.4](<2.4 Structural Requirement.md>), [§2.6.8](<2.6.8 Ontological Identity.md>), [§2.10.2](<2.10.2 The Stratified Architecture.md>), [§2.10.3](<2.10.3 The Metalogical Position.md>), [§4.1.5](<4.1.5 Information-Theoretic Foundationalism.md>), [§4.3.3](<4.3.3 Russellian Monism.md>), [§4.3.6](<4.3.6 The Unreasonable Effectiveness of Mathematics.md>), [§4.3.9](<4.3.9 Structural Realism.md>), [§4.4.7](<4.4.7 Sider's Structuralism.md>), [§6.1](<6.1 Greatness.md>), [§8.3](<8.3 Knowledge.md>)

Lagrange, [§7.5.4](<7.5.4 Symmetry.md>), Appendix D

Landemore, Hélène, Landemore's epistemic and open-democracy work is engaged across the representation framework: dispute ([§9.3.1](<9.3.1 What is Disputed.md>)), design requirements ([§9.3.2](<9.3.2 What is Required.md>)), empirical confirmation ([§9.3.4](<9.3.4 What is Confirmed.md>)), and continuous-recognition architecture ([§9.3](<9.3 Representation.md>)).

Langton, Rae, Langton's Kantian Humility is engaged in the witness-reach analysis at [§2.2.3](<2.2.3 Witness's Reach.md>) and in the idealism discussion at [§4.3.5](<4.3.5 Idealism.md>).

Language, [§8.10](<8.10 Language.md>), [§8.10.1](<8.10.1 What is Disputed.md>)–[§8.10.5](<8.10.5 What is Concluded.md>)

Laplacean determinism, [§7.7](<7.7 Cosmic History.md>), Appendix D

Large language models, [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.5](<8.10.5 What is Concluded.md>), [§8.11](<8.11 Technology.md>), [§8.11.5](<8.11.5 What is Concluded.md>)

Latour, Bruno, [§8.11.1](<8.11.1 What is Disputed.md>)

Law of Excluded Middle (LEM), [§2.6.11](<2.6.11 No Fourth Condition.md>), [§2.10.1](<2.10.1 Three Distinct Logics.md>)

Law of Modal Persistence, [§2.1.7](<2.1.7 Two Readings.md>), Glossary Principles

Leftow, Brian, [§4.1.10](<4.1.10 The Source of Possibility.md>), [§4.2.1](<4.2.1 The Changeless Ground.md>), §5, [§5.2.1](<5.2.1 Divine Simplicity.md>), [§5.1.3](<5.1.3 Simultaneous Causation.md>), [§5.1.9](<5.1.9 Transcendental Argument.md>), [§5.2.2](<5.2.2 Via Negativa.md>), [§5.1.8](<5.1.8 Modal-Grounding Argument.md>), [§6.2.1](<6.2.1 Simplicity.md>), [§6.3.1](<6.3.1 Necessity.md>), [§6.3.2](<6.3.2 Eternity.md>), [§6.4.2](<6.4.2 Knowledge.md>), [§6.7.1](<6.7.1 Power.md>), [§6.7.2](<6.7.2 Causality.md>), [§6.7.4](<6.7.4 Sovereignty.md>), [§6.8.3](<6.8.3 Describability.md>), [§6.2.2](<6.2.2 Unity.md>)

Leibniz, [§4.1.3](<4.1.3 Principle of Sufficient Reason.md>), [§4.4.9](<4.4.9 Modal Collapse Objection.md>), [§5.1.1](<5.1.1 Rasmussen's Foundation Argument.md>), [§6.7.2](<6.7.2 Causality.md>), [§8.15](<8.15 Synthesis.md>)

Leśniewski, Stanisław, [§2.10.1](<2.10.1 Three Distinct Logics.md>) Three Distinct Logics; [§4.3.11](<4.3.11 Mereological Nihilism.md>) Mereological Nihilism. Logician; mereology and the formal foundations of the substantial-logic axis.

Levinas, Emmanuel, [§6.5.1](<6.5.1 Holiness.md>) Holiness. Phenomenologist; ethics as first philosophy and the face-to-face encounter with the Other, cited in the analysis of divine otherness.

Levine, Joseph, [§4.3.1](<4.3.1 The Hard Problem of Consciousness.md>) The Hard Problem of Consciousness. Philosopher of mind who named the explanatory gap between physical description and phenomenal experience.

Lewis, C. S., Excursus E.1.5

Lewis, David, [§2.1.4](<2.1.4 Modal Stability.md>), [§2.4.1](<2.4.1 Constituting Modal Structure.md>), [§4.2.7](<4.2.7 The Problem of Temporary Intrinsics.md>), [§4.3.12](<4.3.12 Haecceitism.md>), [§4.4](<4.4 Modal Variants and Extensions.md>), [§4.4.1](<4.4.1 Modal Realism.md>), [§4.4.7](<4.4.7 Sider's Structuralism.md>), [§8.3.1](<8.3.1 What is Disputed.md>), [§8.7.1](<8.7.1 What is Disputed.md>), [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Libertarian free will, [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.5](<8.9.5 What is Concluded.md>)

Libertarianism (free will), [§6.7.4](<6.7.4 Sovereignty.md>)

Libido, [§8.1](<8.1 Drive.md>), [§8.1.1](<8.1.1 What is Disputed.md>)

Licona, Michael R., Licona's resurrection case is engaged in the revelation discussion at [§6.8.4](<6.8.4 Revelation.md>) and steelmanned, then assessed, in E.5.3 The Resurrection.

Life, [§7.8](<7.8 Life.md>), [§7.8.1](<7.8.1 What is Disputed.md>)–[§7.8.5](<7.8.5 What is Concluded.md>); *see also* Consciousness

Life (divine), [§6.6](<6.6 Life.md>)

Lijphart, Arend, Lijphart's comparative consensus-democracy work is engaged in the representation dispute ([§9.3.1](<9.3.1 What is Disputed.md>)) and confirmation record ([§9.3.4](<9.3.4 What is Confirmed.md>)).

Linford, Daniel J., [§4.2.9](<4.2.9 Existential Inertia.md>)

Linguistic Ersatzism, [§4.4.2](<4.4.2 Linguistic Ersatzism.md>)

Linguistic relativity, [§8.10](<8.10 Language.md>), [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Locke, [§2.6.12](<2.6.12 Necessity's Nature.md>), [§8.5](<8.5 Identity.md>), [§8.5.1](<8.5.1 What is Disputed.md>), [§8.5.5](<8.5.5 What is Concluded.md>), [§8.7.1](<8.7.1 What is Disputed.md>), [§9.1](<9.1 Rights.md>), [§9.1.1](<9.1.1 What is Disputed.md>), [§9.13](<9.13 Justice.md>), [§9.13.1](<9.13.1 What is Disputed.md>), [§9.13.2](<9.13.2 What is Required.md>), [§9.13.5](<9.13.5 What is Concluded.md>)

Loewer, Barry, Loewer's Humean account of laws and the Mentaculus is engaged in the Physicality argument at [§2.4.8](<2.4.8 Exchange Requires Physicality.md>) and in the Humean-contingency discussion at [§4.1.4](<4.1.4 Humean Contingency.md>).

Logic, [§8.4](<8.4 Reasoning.md>), [§8.4.4](<8.4.4 What is Confirmed.md>)

Logical possibility, [§8.4](<8.4 Reasoning.md>)

*Logos*, [§7.1](<7.1 Convergence of Method.md>)

Lomborg, Bjørn, Lomborg's cost-benefit critique of environmental policy is engaged in the environmental-policy dispute at §[§9.5.1](<9.5.1 What is Disputed.md>) and 9.5.3.

Loop quantum gravity (LQG), [§7.6](<7.6 Singularity.md>), Appendix D

Lorentz invariance, [§7.5.4](<7.5.4 Symmetry.md>)

Lowe, E. J., [§2.10.1](<2.10.1 Three Distinct Logics.md>) Three Distinct Logics; §[§4.2.7](<4.2.7 The Problem of Temporary Intrinsics.md>)–4.2.8. Philosopher of four-category ontology, substance, identity, and persistence.

Lucretius, [§7.1](<7.1 Convergence of Method.md>), [§8.7](<8.7 Mortality.md>), [§8.7.1](<8.7.1 What is Disputed.md>)

Lüdemann, Gerd, Lüdemann's primary-vision and chain-reaction account of resurrection appearances is substantively engaged in E.5.3 The Resurrection.

MacIntyre, Alasdair, [§8.5](<8.5 Identity.md>), [§8.5.1](<8.5.1 What is Disputed.md>), [§8.8.1](<8.8.1 What is Disputed.md>), [§8.12.1](<8.12.1 What is Disputed.md>)

Mackie, J. L., [§5.1.10](<5.1.10 Moral Argument.md>), [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>); *see also* Error theory

Maddy, Penelope, §[§4.2.4](<4.2.4 Platonism.md>) and 4.2.8. Philosopher of mathematics; naturalism and set theory in the structural-metaphysics discussions.

Madhyamaka, [§5.3.4](<5.3.4 Madhyamaka Emptiness.md>)

Maimonides, [§5.2.1](<5.2.1 Divine Simplicity.md>), [§5.2.2](<5.2.2 Via Negativa.md>), [§6.8.3](<6.8.3 Describability.md>), [§8.14](<8.14 Spirituality.md>)

Maitzen, Stephen, Maitzen's arguments on divine hiddenness, intervention, and PSR are substantively engaged in E.3.1, E.1.2, and [§2.7.3](<2.7.3 PSR Regress.md>).

Manne, Kate, [§8.6.5](<8.6.5 What is Concluded.md>)

*Maranasati*, [§8.7](<8.7 Mortality.md>), [§8.7.1](<8.7.1 What is Disputed.md>), [§8.7.4](<8.7.4 What is Confirmed.md>)

Marcus, Ruth Barcan, Barcan Marcus's quantified-modal-logic work and the Barcan formula are engaged in the modal-variants overview ([§4.4](<4.4 Modal Variants and Extensions.md>)) and the necessitism analysis ([§4.4.6](<4.4.6 Necessitism.md>)).

Marion, Jean-Luc, Marion's post-Heideggerian and apophatic theology is engaged in the divine-simplicity discussion ([§6.2.1](<6.2.1 Simplicity.md>)) and Via Negativa ([§5.2.2](<5.2.2 Via Negativa.md>)).

Marshall, T. H., Marshall's citizenship and social-rights tradition is engaged in Rights (§[§9.1](<9.1 Rights.md>)–9.1.4) and in the Economy's social-rights architecture ([§9.7](<9.7 Economy.md>)).

Marx, [§8.11.1](<8.11.1 What is Disputed.md>), [§8.13.1](<8.13.1 What is Disputed.md>), [§9.7.1](<9.7.1 What is Disputed.md>), [§9.7.5](<9.7.5 What is Concluded.md>), [§9.15](<9.15 Installation.md>)

Mass–energy equivalence, [§7.4.1](<7.4.1 What is Disputed.md>), [§7.4.4](<7.4.4 What is Confirmed.md>)

mathematical cyclist, [§2.8.5](<2.8.5 Necessity of Nature.md>)

Mathematical Universe Hypothesis, [§4.3.7](<4.3.7 Mathematical Universe Hypothesis.md>)

Mathematics, [§7.1](<7.1 Convergence of Method.md>)

Maturana, Humberto R., [§7.8](<7.8 Life.md>) Life; §[§7.8.1](<7.8.1 What is Disputed.md>)–7.8.3. Biologist and theorist of autopoiesis; self-producing closure and the biology of cognition.

Maudlin, Tim, [§4.2](<4.2 Time, Change, and the Changeless.md>) Emergent Time; [§4.3.8](<4.3.8 Non-Locality, Branching, and the Particle Concept.md>) Non-Locality; Chapter 7 Time. Philosopher of physics on relativity, quantum non-locality, and the metaphysics of time.

Mavrodes, George I., [§5.1.10](<5.1.10 Moral Argument.md>) Moral Argument. Philosopher of religion on omnipotence, moral grounding, and religious epistemology.

Maximal greatness, R21, the "Maximal Greatness" result (Result of T6 and T7): the Anselmian superlative inverted. Developed as Plantinga's modal maximand at [§5.1.7](<5.1.7 Modal Ontological Argument.md>) and inverted at [§6.1](<6.1 Greatness.md>) (Greatness); stated as R21 at the Chapter 9 root (§9 Maximum Possibility), where it names maximum possibility as a maintained standing.

Maximally Great Being (MGB), [§6.1](<6.1 Greatness.md>), [§6.10](<6.10 No Exit.md>), Appendix B item 16, Glossary; *see also* Classical God; Perfect-being theology; Great-making properties

Maxwell, [§7.3.4](<7.3.4 What is Confirmed.md>), Appendix D

McCann, Hugh J., [§4.2.9](<4.2.9 Existential Inertia.md>)

McDowell, John, McDowell's therapeutic quietism in epistemology and philosophy of mind is directly engaged in [§4.1.9](<4.1.9 Wittgensteinian Quietism.md>).

McGinnis, Jon, McGinnis's work on Avicenna's continuous-creation account is substantively engaged in [§5.1.3](<5.1.3 Simultaneous Causation.md>).

McLuhan, Marshall, [§8.11.1](<8.11.1 What is Disputed.md>)

McMahan, Jeff, McMahan's revisionist ethics of killing and combatant liability is engaged in the defense and just-war discussions at §[§9.11](<9.11 Defense.md>)–9.11.1.

McTaggart, J. M. E., [§2.6](<2.6 Triconditionality of Nature.md>), [§3.5.3](<3. Convergence.md>), [§4.2.5](<4.2.5 The Unreality of Time.md>), [§4.2.2](<4.2.2 Shoemaker's Time Without Change.md>), [§7.2.1](<7.2.1 What is Disputed.md>)

Meaning, [§8.8](<8.8 Meaning.md>), [§8.8.1](<8.8.1 What is Disputed.md>)–[§8.8.5](<8.8.5 What is Concluded.md>)

*Meditatio mortis*, [§8.7](<8.7 Mortality.md>), [§8.7.1](<8.7.1 What is Disputed.md>), [§8.7.4](<8.7.4 What is Confirmed.md>)

Medium, [§1.5.7](<1.5.7 Medium of Transmission.md>), [§2.4](<2.4 Structural Requirement.md>), Glossary; *see also* Nature; Necessity of Nature

Mellor, D. H., [§4.2](<4.2 Time, Change, and the Changeless.md>) Time; [§7.2.1](<7.2.1 What is Disputed.md>) What is Disputed. Philosopher of the tenseless B-theory of time and metaphysics of persistence.

*Memento mori*, [§8.7](<8.7 Mortality.md>), [§8.7.1](<8.7.1 What is Disputed.md>), [§8.7.4](<8.7.4 What is Confirmed.md>), [§8.7.5](<8.7.5 What is Concluded.md>)

*Mens rea*, [§8.9.4](<8.9.4 What is Confirmed.md>)

Mereological nihilism, [§4.3.11](<4.3.11 Mereological Nihilism.md>)

Merleau-Ponty, [§8.2.4](<8.2.4 What is Confirmed.md>), [§8.8.3](<8.8.3 What is Predicted.md>), [§8.13.1](<8.13.1 What is Disputed.md>)

Merricks, Trenton, Merricks's compositional arguments, including persons and overdetermination, are substantively engaged in [§4.3.11](<4.3.11 Mereological Nihilism.md>).

Meta-problem of consciousness, §8

Metalogical Position, [§2.10.3](<2.10.3 The Metalogical Position.md>); *see also* Three Logical Strata

Metaontological Deflationism, [§4.1.8](<4.1.8 Metaontological Deflationism.md>)

Metaphysical possibility, [§8.4](<8.4 Reasoning.md>)

Methodological Convergence, [§7.1](<7.1 Convergence of Method.md>), Appendix B item 21

Metz, Thaddeus, [§8.8.1](<8.8.1 What is Disputed.md>), [§8.8.4](<8.8.4 What is Confirmed.md>)

Metzger, Bruce M., Metzger's account of New Testament canon formation is cited in the testimonial-transmission analysis in E.5.3 The Resurrection.

Metzinger, Thomas, [§8.5.1](<8.5.1 What is Disputed.md>)

Meyer, Stephen C., Meyer's information-based intelligent-design argument is engaged in [§5.1.6](<5.1.6 Intelligent Design.md>) and in the Life dispute at [§7.8.1](<7.8.1 What is Disputed.md>).

Mill, John Stuart, [§8.12](<8.12 Morality.md>), [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.2](<8.12.2 What is Required.md>), [§9.4.1](<9.4.1 What is Disputed.md>); *see also* Harm principle; Consequentialism

Millikan, Ruth, [§8.1.1](<8.1.1 What is Disputed.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Mills, Charles, [§9.14](<9.14 Convergence.md>)

Minkowski, [§4.2.6](<4.2.6 Block Universe.md>), [§7.5.1](<7.5.1 Spacetime.md>), Appendix D

Miracle, [§6.7.1](<6.7.1 Power.md>), [§6.7.2](<6.7.2 Causality.md>)

Mirror self-recognition, [§8.5.1](<8.5.1 What is Disputed.md>), [§8.5.3](<8.5.3 What is Predicted.md>)

Mixed relation, [§6.8.2](<6.8.2 Relatability.md>)

Modal Access, §8, Glossary; *see also* Modal Field; Modal Memory

Modal alignment, [§8.3](<8.3 Knowledge.md>); See also Modal convergence; Modal field; Modal network.

Modal Aspect, *see* Modal Identity

Modal Bivalence, [§2.1.1](<2.1.1 Modal Bivalence.md>), [§2.1](<2.1 The S5 Pipeline.md>)

Modal Certainty, [§2.1.3](<2.1.3 Modal Constitution.md>), [§2.1.4](<2.1.4 Modal Stability.md>)

Modal Collapse Objection, [§4.4.9](<4.4.9 Modal Collapse Objection.md>), [§4.2.9](<4.2.9 Existential Inertia.md>)

Modal Closure, [§2.8.4](<2.8.4 Necessity Precedes Contingency.md>)

Modal commons, [§8.3](<8.3 Knowledge.md>)

Modal Conditions (P5 of the proof), [§2.6](<2.6 Triconditionality of Nature.md>), [§2.4](<2.4 Structural Requirement.md>), [§2.6.6](<2.6.6 Modal Identity.md>)

Modal Constitution, [§2.1.3](<2.1.3 Modal Constitution.md>)

Modal Constraint, [§2.1.3](<2.1.3 Modal Constitution.md>), [§2.3](<2.3 Necessary Possibility of Change.md>); *see also* Modal Conditions (P5 of the proof)

Modal contamination, [§8.3](<8.3 Knowledge.md>); See also Modal convergence; Modal fidelity; Modal weight; Modal network.

Modal Conventionalism, [§4.1.7](<4.1.7 Modal Conventionalism.md>)

Modal depth, [§8.9](<8.9 Will.md>), [§8.9.2](<8.9.2 What is Required.md>), [§8.9.3](<8.9.3 What is Predicted.md>), [§8.9.5](<8.9.5 What is Concluded.md>)

Modal Exclusivity, [§4.1.10](<4.1.10 The Source of Possibility.md>)

Modal expression, [§8.3](<8.3 Knowledge.md>); See also Modal representation; Modal network; Modal contamination.

Modal Expressivism, [§4.4.5](<4.4.5 Modal Expressivism.md>)

Modal fictionalism, [§4.4.4](<4.4.4 Modal Fictionalism.md>), [§3.3.3](<3. Convergence.md>)

Modal fidelity, [§8.3](<8.3 Knowledge.md>); See also Modal depth; Modal field; Modal contamination.

Modal Field, [§8.3](<8.3 Knowledge.md>), [§7.9](<7.9 Synthesis.md>), §8, [§8.2](<8.2 Feeling.md>), [§8.4](<8.4 Reasoning.md>), [§8.5](<8.5 Identity.md>), [§8.6](<8.6 Sexuality.md>), [§8.7](<8.7 Mortality.md>), [§8.8](<8.8 Meaning.md>), [§8.9](<8.9 Will.md>), [§8.10](<8.10 Language.md>), [§8.11](<8.11 Technology.md>), [§8.12](<8.12 Morality.md>), [§8.13](<8.13 Art.md>), [§8.14](<8.14 Spirituality.md>), Glossary; *see also* Modal Map; Modal Memory; Modal Convergence

Modal freedom, [§8.9](<8.9 Will.md>)

Modal Identity, [§2.6.6](<2.6.6 Modal Identity.md>), Appendix B item 7, Glossary Theorem 2

Modal Invariance, Principle of, [§2.1.7](<2.1.7 Two Readings.md>), Glossary Principles

Modal logic, [§1.1](<1.1 Reality.md>), [§2.1](<2.1 The S5 Pipeline.md>), [§2.1.4](<2.1.4 Modal Stability.md>), [§2.1.5](<2.1.5 The S5 Bottleneck.md>)

Modal Map, [§8.11](<8.11 Technology.md>), [§5.1.5](<5.1.5 Fine-Tuning Argument.md>), Glossary; *see also* Exterior Modal Map

Modal Memory, §8, [§8.2](<8.2 Feeling.md>), Glossary; *see also* Modal Access; Modal Field; Modal Map

Modal network, [§8.11](<8.11 Technology.md>) Technology. The collective, externally supported network of modal representations assembled, corrected, and inherited across bodies.

Modal Pressure, [§2.6.10](<2.6.10 Triconditional Identity.md>), §8, [§8.1](<8.1 Drive.md>), [§8.2](<8.2 Feeling.md>), Glossary

Modal Realism (Lewisian), [§4.4.1](<4.4.1 Modal Realism.md>); *see also* Lewis, David

Modal representation, [§8.3](<8.3 Knowledge.md>); See also Modal weight; Modal expression; Modal field; Modal structure.

Modal Status, [§1.2](<1.2 Modal Status.md>), [§1.1](<1.1 Reality.md>), [§2.1](<2.1 The S5 Pipeline.md>), [§2.1.3](<2.1.3 Modal Constitution.md>), Glossary

Modal structure, [§8.3](<8.3 Knowledge.md>)

Modal Convergence, [§8.3](<8.3 Knowledge.md>), [§8.10](<8.10 Language.md>), §9; *see also* Modal Convergence Theorem

Modal Convergence Theorem, [§8.3](<8.3 Knowledge.md>)

Modal weight, [§8.3](<8.3 Knowledge.md>); See also Modal representation; Modal fidelity; Modal contamination.

Molina, Luis de, [§6.4.2](<6.4.2 Knowledge.md>), [§6.7.4](<6.7.4 Sovereignty.md>)

Molinism, [§6.9.2](<6.9.2 Righteousness.md>)

Moltmann, Jürgen, [§6.3.4](<6.3.4 Impassibility.md>)

Moore, G. E., [§8.12.5](<8.12.5 What is Concluded.md>); *see also* Open question argument

Moral argument, [§5.1.10](<5.1.10 Moral Argument.md>)

Moral constructivism, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

Moral nihilism, [§8.12.5](<8.12.5 What is Concluded.md>)

Moral realism, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

Moral relativism, [§8.12.1](<8.12.1 What is Disputed.md>)

Moral status, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.2](<8.12.2 What is Required.md>)

Morality, [§8.12](<8.12 Morality.md>), [§8.12.1](<8.12.1 What is Disputed.md>)–[§8.12.5](<8.12.5 What is Concluded.md>)

Moreland, J. P., [§8.3](<8.3 Knowledge.md>) Knowledge; E.4.2 Scripture and Prophecy. Philosopher of religion on consciousness and natural theology.

Morris, Thomas V., [§5.1.8](<5.1.8 Modal-Grounding Argument.md>), [§5.1.9](<5.1.9 Transcendental Argument.md>), §6, [§6.1](<6.1 Greatness.md>), [§6.2.1](<6.2.1 Simplicity.md>), [§6.2.4](<6.2.4 Perfection.md>), [§6.3.1](<6.3.1 Necessity.md>), [§6.7.3](<6.7.3 Interaction.md>), [§6.8.3](<6.8.3 Describability.md>), [§6.9.2](<6.9.2 Righteousness.md>), Excursus E.5.2

Morriston, Wes, [§5.1.2](<5.1.2 Cosmological Argument.md>), [§5.1.3](<5.1.3 Simultaneous Causation.md>)

Moss, Candida, E.5.3 The Resurrection. Historian of early Christianity; cited on the late development of martyrdom accounts.

Mortality, [§8.7](<8.7 Mortality.md>), [§8.7.1](<8.7.1 What is Disputed.md>)–[§8.7.5](<8.7.5 What is Concluded.md>); *see also* *Sein-zum-Tode*

Mouffe, Chantal, [§9.3](<9.3 Representation.md>), [§9.14](<9.14 Convergence.md>), [§9.15](<9.15 Installation.md>)

Mu'tazilism, [§6.9.1](<6.9.1 Benevolence.md>)

Mullins, R. T., [§5.2.1](<5.2.1 Divine Simplicity.md>), [§6.3.1](<6.3.1 Necessity.md>), [§6.3.3](<6.3.3 Immutability.md>), [§6.7.1](<6.7.1 Power.md>), [§6.7.2](<6.7.2 Causality.md>), [§6.7.3](<6.7.3 Interaction.md>), [§6.9.2](<6.9.2 Righteousness.md>)

Mumford, Stephen, [§2.5](<2.5 Triconditional Necessity.md>) Causal Power; [§2.4.2](<2.4.2 Structural Gap.md>) Laws. Metaphysician of dispositions and laws of nature.

Murphy, Mark C., §[§6.1](<6.1 Greatness.md>)–6.2 Greatness, Simplicity, and Perfection. Philosopher of religion on divine authority, divine agency, and moral theology.

Murray, John, [§6.9](<6.9 Moral Act.md>) Providence; E.2.2 Original Sin. Reformed theologian on redemption, imputation, and original sin.

Mutual Containment Result, [§2.6.5](<2.6.5 Mutual Containment.md>), [§2.6.7](<2.6.7 Triconditional Cross-Entailment.md>), Appendix B item 9, Glossary Result

Mutual Maintenance, [§9.15](<9.15 Installation.md>)

Mutual Sustenance, Theorem 10 (T10), stated at §9 root and developed through [§9.14](<9.14 Convergence.md>) Convergence.

Mystical experience, [§8.14](<8.14 Spirituality.md>), [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.4](<8.14.4 What is Confirmed.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Nagarjuna, [§4.2.8](<4.2.8 Stage Theory.md>), [§5.3.4](<5.3.4 Madhyamaka Emptiness.md>), [§8.14.5](<8.14.5 What is Concluded.md>); *see also* Non-dualism (śūnyatā / Advaita)

Nagel, Thomas, [§4.3.1](<4.3.1 The Hard Problem of Consciousness.md>), [§4.3.2](<4.3.2 Eliminativism and Illusionism.md>), [§6.4.1](<6.4.1 Awareness.md>), §8, [§8.3](<8.3 Knowledge.md>), [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.3](<8.3.3 What is Predicted.md>), [§8.3.4](<8.3.4 What is Confirmed.md>), [§8.7.1](<8.7.1 What is Disputed.md>), [§8.8](<8.8 Meaning.md>), [§8.8.1](<8.8.1 What is Disputed.md>), [§8.8.5](<8.8.5 What is Concluded.md>)

Named Results, *see* Glossary, Named Results

Narrative identity, [§8.5](<8.5 Identity.md>), [§8.5.1](<8.5.1 What is Disputed.md>), [§8.8.1](<8.8.1 What is Disputed.md>)

Natural Identity, *see* Triconditional Identity

Natural law, [§8.6.1](<8.6.1 What is Disputed.md>), [§8.6.5](<8.6.5 What is Concluded.md>)

Nature, [§1.4.4](<1.4.4 Triconditional Structure.md>), [§2.6](<2.6 Triconditionality of Nature.md>), [§2.8](<2.8 The Whole Line.md>), [§2.8.5](<2.8.5 Necessity of Nature.md>), Glossary

Nature of Necessity, [§2.6.12](<2.6.12 Necessity's Nature.md>), Glossary Named Results; *see also* Necessity of Nature; Conditioned-Nature

Near-death experience, [§8.7.4](<8.7.4 What is Confirmed.md>), Appendix D

Necessary Occupancy, [§2.8.6](<2.8.6 Exclusivity of Nature.md>), Appendix B item 14, Glossary Result

Necessary Possibility, [§2.1.10](<2.1.10 Necessary Possibility.md>); *see also* Euclidean Axiom

Necessitism, [§4.4.6](<4.4.6 Necessitism.md>); *see also* Williamson, Timothy

Necessity, [§1.2](<1.2 Modal Status.md>), [§2.1.4](<2.1.4 Modal Stability.md>), [§2.3](<2.3 Necessary Possibility of Change.md>), [§2.6](<2.6 Triconditionality of Nature.md>), Glossary; *see also* Modal logic; Possibility

Necessity (divine), [§6.3.1](<6.3.1 Necessity.md>)

Necessity entails Possibility, [§2.1.4](<2.1.4 Modal Stability.md>), Glossary Result

Necessity of Nature, [§2.8](<2.8 The Whole Line.md>), [§2.4](<2.4 Structural Requirement.md>), [§2.8.5](<2.8.5 Necessity of Nature.md>), Appendix B item 12, Glossary Theorem 6

Negation Seal, [§2.1.5](<2.1.5 The S5 Bottleneck.md>)

Neoplatonism, [§5.3.2](<5.3.2 Neoplatonism.md>); *see also* Plotinus

New Atheism, [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Newton, [§7.3.1](<7.3.1 What is Disputed.md>)

Nietzsche, [§8.1](<8.1 Drive.md>), [§8.1.1](<8.1.1 What is Disputed.md>), [§8.1.5](<8.1.5 What is Concluded.md>), [§8.7.5](<8.7.5 What is Concluded.md>), [§8.8.1](<8.8.1 What is Disputed.md>), [§8.13](<8.13 Art.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Nihilism, [§8.8](<8.8 Meaning.md>), [§8.8.1](<8.8.1 What is Disputed.md>), [§8.8.5](<8.8.5 What is Concluded.md>)

No Bare Plurality, [§2.4.7](<2.4.7 Distinction Requires Spatiality.md>)

No Exit, [§6.10](<6.10 No Exit.md>); *see also* God-Precluded; Three-Horn Dilemma

*Noesis noeseos noesis*, [§6.4.1](<6.4.1 Awareness.md>)

Noether, [§7.1](<7.1 Convergence of Method.md>), [§7.4](<7.4 Substance.md>), [§7.4.4](<7.4.4 What is Confirmed.md>), [§7.5.3](<7.5.3 Conservation.md>), [§7.5.4](<7.5.4 Symmetry.md>)

Nomological Aspect, *see* Triconditional Cross-Entailment

Nomological Identity, *see* Triconditional Cross-Entailment

Nomological possibility, [§8.4](<8.4 Reasoning.md>)

Non-dualism (śūnyatā / Advaita), [§8.14.5](<8.14.5 What is Concluded.md>)

Nordhaus, William, Nordhaus's cost-benefit and prioritization approach to environmental policy is substantively engaged in [§9.5.1](<9.5.1 What is Disputed.md>) and carried into the prediction framework at [§9.5.3](<9.5.3 What is Predicted.md>).

Norton, John D., Norton's work on spacetime and the hole argument is engaged in the substantivalism-relationalism synthesis at [§7.3.2](<7.3.2 What is Required.md>).

Nozick, Robert, [§8.1.1](<8.1.1 What is Disputed.md>), §9, [§9.1.1](<9.1.1 What is Disputed.md>), [§9.7.1](<9.7.1 What is Disputed.md>), [§9.7.3](<9.7.3 What is Predicted.md>), [§9.7.4](<9.7.4 What is Confirmed.md>), [§9.13.1](<9.13.1 What is Disputed.md>), [§9.13.3](<9.13.3 What is Predicted.md>), [§9.13.4](<9.13.4 What is Confirmed.md>), [§9.13.5](<9.13.5 What is Concluded.md>)

Numinous, [§8.14.5](<8.14.5 What is Concluded.md>)

Nussbaum, Martha, [§8.2.1](<8.2.1 What is Disputed.md>), [§8.2.4](<8.2.4 What is Confirmed.md>), [§8.2.5](<8.2.5 What is Concluded.md>), [§9.1.1](<9.1.1 What is Disputed.md>), [§9.1.5](<9.1.5 What is Concluded.md>), [§9.3.1](<9.3.1 What is Disputed.md>), [§9.5.1](<9.5.1 What is Disputed.md>), [§9.6.1](<9.6.1 What is Disputed.md>), [§9.7.1](<9.7.1 What is Disputed.md>), [§9.10](<9.10 Healthcare.md>), [§9.10.1](<9.10.1 What is Disputed.md>), [§9.11.1](<9.11.1 What is Disputed.md>)

Occasionalism, [§4.2.9](<4.2.9 Existential Inertia.md>), [§6.7.1](<6.7.1 Power.md>), [§6.7.2](<6.7.2 Causality.md>)

Occupancy Condition, *see* Necessary Occupancy

O'Connor, Timothy, [§8.9](<8.9 Will.md>) Will. Philosopher of agent-causal libertarianism; the framework treats agent-causation as either structure-grounded selection or luck.

Olson, Eric, [§8.5](<8.5 Identity.md>), [§8.5.1](<8.5.1 What is Disputed.md>), [§8.7.1](<8.7.1 What is Disputed.md>)

Olson, Mancur, Olson's public-choice rollback analysis is substantively engaged in the installation debate at [§9.15](<9.15 Installation.md>).

Omnipotence, *see* Power (divine)

Omnipresence, [§6.8.1](<6.8.1 Presence.md>)

Omniscience (divine), [§6.4.2](<6.4.2 Knowledge.md>)

Ontological argument, [§6.3.1](<6.3.1 Necessity.md>), [§6.2.4](<6.2.4 Perfection.md>)

Ontological Identity, [§2.6.8](<2.6.8 Ontological Identity.md>), Appendix B item 10, Glossary Theorem 4

Oord, Thomas Jay, [§5.3](<5.3 Non-Classical Ultimates.md>) Process Theism. Theologian of open and relational theology, emphasizing uncontrolling love and divine receptivity.

Open question argument, [§8.12.5](<8.12.5 What is Concluded.md>)

Open theism, [§6.1](<6.1 Greatness.md>), [§6.7.3](<6.7.3 Interaction.md>), [§6.10](<6.10 No Exit.md>)

Operators (metaphysical), [§1.5](<1.5 Existence.md>), [§1.5.9](<1.5.9 What the Operators Require.md>); see also Causation; Grounding; Entailment; Constitution; Medium

Oppy, Graham, §2, [§2.7.3](<2.7.3 PSR Regress.md>), [§2.9](<2.9 Precedent Convergence.md>), [§2.9.3](<2.9.3 Total-Theory Comparison.md>), [§3.3.4](<3. Convergence.md>), [§4.1](<4.1 Modal and Semantic Foundations.md>), [§4.4.7](<4.4.7 Sider's Structuralism.md>), [§5.1.2](<5.1.2 Cosmological Argument.md>), [§5.1.4](<5.1.4 Argument from Simplicity.md>), [§5.1.7](<5.1.7 Modal Ontological Argument.md>), [§6.2.4](<6.2.4 Perfection.md>), [§6.10](<6.10 No Exit.md>), §7, Intro.

Original position / veil of ignorance (Rawls), [§9.1](<9.1 Rights.md>) Rights; [§9.14](<9.14 Convergence.md>) Convergence. Rawls's original-position method and veil of ignorance; the framework derives universalizability from mutual registration instead.

Original sin, [§6.9.2](<6.9.2 Righteousness.md>)

Ostrom, Elinor, [§9.5](<9.5 Environment.md>) Environment; [§9.7](<9.7 Economy.md>) Economy. Political economist of common-pool resource governance and collective action.

Otto, Rudolf, [§6.5.1](<6.5.1 Holiness.md>), [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>); *see also* Numinous

Paine, Thomas, [§6.8.4](<6.8.4 Revelation.md>)

Paley, William, [§6.8.4](<6.8.4 Revelation.md>)

Panentheism, [§6.1](<6.1 Greatness.md>), [§6.10](<6.10 No Exit.md>)

Panksepp, Jaak, [§8.1](<8.1 Drive.md>), [§8.1.4](<8.1.4 What is Confirmed.md>), [§8.2](<8.2 Feeling.md>), [§8.2.1](<8.2.1 What is Disputed.md>)

Panpsychism, [§6.1](<6.1 Greatness.md>), §8, [§8.2](<8.2 Feeling.md>), Appendix D

Pantheism, [§6.8.1](<6.8.1 Presence.md>), [§6.2.2](<6.2.2 Unity.md>)

Parasitic mind control, [§8.5](<8.5 Identity.md>), [§8.5.1](<8.5.1 What is Disputed.md>), [§8.5.2](<8.5.2 What is Required.md>), [§8.5.3](<8.5.3 What is Predicted.md>), [§8.5.4](<8.5.4 What is Confirmed.md>)

Parasitic Negation, [§2.1.5](<2.1.5 The S5 Bottleneck.md>)

Parfit, Derek, [§8.5](<8.5 Identity.md>), [§8.5.1](<8.5.1 What is Disputed.md>), [§8.5.5](<8.5.5 What is Concluded.md>), [§8.7.1](<8.7.1 What is Disputed.md>), [§8.8.3](<8.8.3 What is Predicted.md>), [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

Pascal, Blaise, Pascal and the Pensées wager are directly engaged in [§5.1.11](<5.1.11 Pascal's Wager.md>).

Pascal's Wager, [§5.1.11](<5.1.11 Pascal's Wager.md>)

Passibilism, [§6.3.4](<6.3.4 Impassibility.md>)

Past Hypothesis, [§7.2.3](<7.2.3 What is Predicted.md>), [§7.2.4](<7.2.4 What is Confirmed.md>)

Past-eternity, [§7.9](<7.9 Synthesis.md>), [§7.6](<7.6 Singularity.md>), Appendix D

Pawl, Timothy, Pawl's work on weak immutability and conciliar Christology is directly engaged in §[§6.3.3](<6.3.3 Immutability.md>) and 6.7.3.

Peirce, Charles Sanders, [§8.4](<8.4 Reasoning.md>), [§8.4.1](<8.4.1 What is Disputed.md>), [§8.10.3](<8.10.3 What is Predicted.md>)

Penal substitution, [§6.9.2](<6.9.2 Righteousness.md>)

Penrose, [§7.6](<7.6 Singularity.md>), [§7.6.1](<7.6.1 What is Disputed.md>), [§7.6.5](<7.6.5 What is Concluded.md>)

Penrose-Diósi collapse, [§7.7](<7.7 Cosmic History.md>), Appendix D

Pereboom, Derk, [§4.3.3](<4.3.3 Russellian Monism.md>), [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.5](<8.9.5 What is Concluded.md>), Excursus E.3.2

Perennial philosophy, [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Perfect-being theology, [§6.1](<6.1 Greatness.md>), [§6.8.3](<6.8.3 Describability.md>), [§6.10](<6.10 No Exit.md>); *see also* Maximally Great Being (MGB); Anselm; Great-making properties

Perfection (divine), [§6.2.4](<6.2.4 Perfection.md>); *see also* Maximally Great Being (MGB)

Performative Self-Refutation, [§2.1.3](<2.1.3 Modal Constitution.md>), [§2.2](<2.2 Cartesian Certainty.md>), [§3.3.1](<3. Convergence.md>), Glossary Named Results

*Perichoresis*, [§6.2.1](<6.2.1 Simplicity.md>)

Persistence, [§1.3](<1.3 Change.md>), [§1.4](<1.4 Three Conditions.md>), [§1.5.8](<1.5.8 Persistence.md>), §5, Glossary

Personal identity, [§8.5](<8.5 Identity.md>), [§8.5.1](<8.5.1 What is Disputed.md>), [§8.5.5](<8.5.5 What is Concluded.md>)

Pettit, Philip, [§9.1](<9.1 Rights.md>), [§9.3.1](<9.3.1 What is Disputed.md>), [§9.15](<9.15 Installation.md>); *see also* Republicanism

Phenomenological Convergence, [§8.14.2](<8.14.2 What is Required.md>), [§8.14.3](<8.14.3 What is Predicted.md>); *see also* Spirituality

Philosophical zombie, [§8.3](<8.3 Knowledge.md>), [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.5](<8.3.5 What is Concluded.md>)

Physical, Glossary

Physical Identity, *see* Ontological Identity

Physical Triconditional, *see* Ontological Identity

Physicality, *see* Substance, Glossary

Physics, [§7.1](<7.1 Convergence of Method.md>)–[§7.5](<7.5 Binding of the Conditions.md>)

Pinker, Steven, [§8.12.4](<8.12.4 What is Confirmed.md>)

Pizzi, Claudio, [§5.1.1](<5.1.1 Rasmussen's Foundation Argument.md>), [§4.1.11](<4.1.11 Pizzi's Impossibility of Nothingness.md>)

Plantinga, [§1.5.5](<1.5.5 Ground and Dependence.md>), [§2.1.7](<2.1.7 Two Readings.md>), [§2.1.9](<2.1.9 What Necessity Transfer Needs.md>), [§2.8.3](<2.8.3 Not Physicalism.md>), [§4.3.6](<4.3.6 The Unreasonable Effectiveness of Mathematics.md>), [§4.4](<4.4 Modal Variants and Extensions.md>), [§4.4.10](<4.4.10 Gasking's Parody of the Ontological Argument.md>), [§4.4.2](<4.4.2 Linguistic Ersatzism.md>), [§5.2.1](<5.2.1 Divine Simplicity.md>), [§5.1.7](<5.1.7 Modal Ontological Argument.md>), [§5.1.11](<5.1.11 Pascal's Wager.md>), [§6.2.1](<6.2.1 Simplicity.md>), [§6.7.3](<6.7.3 Interaction.md>), [§6.8.4](<6.8.4 Revelation.md>), [§6.9.2](<6.9.2 Righteousness.md>), [§6.2.4](<6.2.4 Perfection.md>), [§6.10](<6.10 No Exit.md>), [§8.14.1](<8.14.1 What is Disputed.md>), Excursus E.1.4

Plantinga, Cornelius, Jr., [§6.2.2](<6.2.2 Unity.md>), [§6.8.2](<6.8.2 Relatability.md>)

Plato, [§4.2.4](<4.2.4 Platonism.md>), [§8.3.1](<8.3.1 What is Disputed.md>), [§8.4](<8.4 Reasoning.md>), [§8.4.1](<8.4.1 What is Disputed.md>)

Platonism, [§4.2.4](<4.2.4 Platonism.md>)

Plotinus, [§5.3.2](<5.3.2 Neoplatonism.md>), [§6.8.3](<6.8.3 Describability.md>)

Pogge, Thomas, [§9.11](<9.11 Defense.md>)

Polytheism, [§6.2.2](<6.2.2 Unity.md>)

Possibility, [§1.1](<1.1 Reality.md>), [§2.1](<2.1 The S5 Pipeline.md>), [§2.1.3](<2.1.3 Modal Constitution.md>), [§8.4](<8.4 Reasoning.md>), Glossary; *see also* Necessity; Impossibility; Modal logic

Possible World, [§2.1.5](<2.1.5 The S5 Bottleneck.md>), Glossary

Posthumanism, [§8.11.1](<8.11.1 What is Disputed.md>)

Power (divine), [§6.7.1](<6.7.1 Power.md>)

Pre-established harmony, [§8.15](<8.15 Synthesis.md>)

Pre-reflective self-awareness, [§8.1](<8.1 Drive.md>), Glossary; *see also* Reflexive awareness

Precedents Converge, [§2.9](<2.9 Precedent Convergence.md>)

Predestination, [§6.7.4](<6.7.4 Sovereignty.md>)

Predication, [§8.10.2](<8.10.2 What is Required.md>), [§8.10.3](<8.10.3 What is Predicted.md>)

Predictive processing, [§8.2](<8.2 Feeling.md>), [§8.2.4](<8.2.4 What is Confirmed.md>), [§8.3](<8.3 Knowledge.md>), [§8.4.1](<8.4.1 What is Disputed.md>), [§8.5.4](<8.5.4 What is Confirmed.md>), [§8.9.4](<8.9.4 What is Confirmed.md>)

Presence (divine), [§6.8.1](<6.8.1 Presence.md>)

Presentism, [§7.2.1](<7.2.1 What is Disputed.md>), [§7.2.2](<7.2.2 What is Required.md>); *see also* A-theory of time; Growing block; Eternalism

Prigogine, [§7.8](<7.8 Life.md>), [§7.8.1](<7.8.1 What is Disputed.md>), [§7.8.2](<7.8.2 What is Required.md>), [§7.8.4](<7.8.4 What is Confirmed.md>), [§8.7.4](<8.7.4 What is Confirmed.md>), [§8.12.3](<8.12.3 What is Predicted.md>)

Principle of alternate possibilities, [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.5](<8.9.5 What is Concluded.md>)

Principle of least action, [§7.5.4](<7.5.4 Symmetry.md>)

Prior, A. N., Prior's tense logic and temporal-metaphysics work are substantively engaged in the three-logics discussion ([§2.10.1](<2.10.1 Three Distinct Logics.md>)) and divine-immutability analysis ([§6.3.3](<6.3.3 Immutability.md>)).

Private language argument, [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Privation theory of evil, [§6.9.1](<6.9.1 Benevolence.md>)

Probability, [§5.1.5](<5.1.5 Fine-Tuning Argument.md>), Glossary

Problem of evil, [§6.9.1](<6.9.1 Benevolence.md>), [§6.2.4](<6.2.4 Perfection.md>)

Procedural knowledge, [§8.3](<8.3 Knowledge.md>), [§8.3.2](<8.3.2 What is Required.md>), [§8.3.3](<8.3.3 What is Predicted.md>), [§8.3.4](<8.3.4 What is Confirmed.md>)

Process metaphysics, [§4.4.8](<4.4.8 Whiteheadian Process Metaphysics.md>), [§5.3.3](<5.3.3 Process Theology.md>), [§6.1](<6.1 Greatness.md>), [§6.10](<6.10 No Exit.md>), [§7.1](<7.1 Convergence of Method.md>)

Process theology, [§5.3.3](<5.3.3 Process Theology.md>), [§8.14.5](<8.14.5 What is Concluded.md>); *see also* Process metaphysics; Whitehead

Propaganda, [§8.13.5](<8.13.5 What is Concluded.md>)

Providence, [§6.7.4](<6.7.4 Sovereignty.md>)

Pruss, Alexander, [§2.7.3](<2.7.3 PSR Regress.md>), [§2.9.3](<2.9.3 Total-Theory Comparison.md>), [§4.1.3](<4.1.3 Principle of Sufficient Reason.md>), [§4.4.9](<4.4.9 Modal Collapse Objection.md>), [§5.1.1](<5.1.1 Rasmussen's Foundation Argument.md>), [§5.2.1](<5.2.1 Divine Simplicity.md>), [§5.1.2](<5.1.2 Cosmological Argument.md>), [§5.1.4](<5.1.4 Argument from Simplicity.md>), [§4.1.11](<4.1.11 Pizzi's Impossibility of Nothingness.md>), [§6.1](<6.1 Greatness.md>), [§6.3.1](<6.3.1 Necessity.md>), [§6.7.1](<6.7.1 Power.md>), [§6.7.2](<6.7.2 Causality.md>), [§6.7.4](<6.7.4 Sovereignty.md>), [§6.9.2](<6.9.2 Righteousness.md>)

Pseudo-Dionysius, [§5.2.2](<5.2.2 Via Negativa.md>), [§6.8.2](<6.8.2 Relatability.md>), [§6.8.3](<6.8.3 Describability.md>), [§6.9.1](<6.9.1 Benevolence.md>), [§8.14](<8.14 Spirituality.md>), [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

PSR (Principle of Sufficient Reason), [§2.7](<2.7 Nothing to Consider.md>), [§2.7.3](<2.7.3 PSR Regress.md>), [§4.1.3](<4.1.3 Principle of Sufficient Reason.md>), Glossary Principles

Psychological continuity, [§8.5.1](<8.5.1 What is Disputed.md>), [§8.5.5](<8.5.5 What is Concluded.md>)

Putnam, Hilary, [§4.2.4](<4.2.4 Platonism.md>), [§4.2.6](<4.2.6 Block Universe.md>), [§4.3.6](<4.3.6 The Unreasonable Effectiveness of Mathematics.md>), [§8.3.5](<8.3.5 What is Concluded.md>)

Putnam, Robert D., [§9.2](<9.2 Belonging.md>), [§9.2.1](<9.2.1 What is Disputed.md>), [§9.2.4](<9.2.4 What is Confirmed.md>), [§9.4.1](<9.4.1 What is Disputed.md>), [§9.4.4](<9.4.4 What is Confirmed.md>), [§9.13.1](<9.13.1 What is Disputed.md>), [§9.13.4](<9.13.4 What is Confirmed.md>)

Quantum field theory (QFT), [§4.3.8](<4.3.8 Non-Locality, Branching, and the Particle Concept.md>), [§7.4](<7.4 Substance.md>), [§7.4.4](<7.4.4 What is Confirmed.md>), [§7.5](<7.5 Binding of the Conditions.md>), [§7.5.2](<7.5.2 Field.md>), Appendix D

Quantum mechanics (QM), [§7.4.4](<7.4.4 What is Confirmed.md>), [§7.6](<7.6 Singularity.md>), [§7.7](<7.7 Cosmic History.md>), Appendix D

Quine, [§2.6.11](<2.6.11 No Fourth Condition.md>), [§2.10.1](<2.10.1 Three Distinct Logics.md>), [§2.10.3](<2.10.3 The Metalogical Position.md>), [§4.1.6](<4.1.6 Quinean Modal Skepticism.md>), [§4.1.7](<4.1.7 Modal Conventionalism.md>), [§4.1.8](<4.1.8 Metaontological Deflationism.md>), [§4.2.8](<4.2.8 Stage Theory.md>), [§4.2.4](<4.2.4 Platonism.md>), [§4.3.6](<4.3.6 The Unreasonable Effectiveness of Mathematics.md>), [§4.4.7](<4.4.7 Sider's Structuralism.md>), [§8.4](<8.4 Reasoning.md>), [§8.10](<8.10 Language.md>), [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Quinean modal skepticism, [§4.1.6](<4.1.6 Quinean Modal Skepticism.md>)

Railton, Peter, [§8.12.5](<8.12.5 What is Concluded.md>)

Rasmussen, [§1.5.5](<1.5.5 Ground and Dependence.md>), [§2.7.3](<2.7.3 PSR Regress.md>), [§2.8.4](<2.8.4 Necessity Precedes Contingency.md>), [§2.8.5](<2.8.5 Necessity of Nature.md>), [§2.9](<2.9 Precedent Convergence.md>), [§2.9.3](<2.9.3 Total-Theory Comparison.md>), [§4.1.3](<4.1.3 Principle of Sufficient Reason.md>), [§4.4.9](<4.4.9 Modal Collapse Objection.md>), §5, [§5.1.1](<5.1.1 Rasmussen's Foundation Argument.md>), [§5.2.1](<5.2.1 Divine Simplicity.md>), [§5.1.2](<5.1.2 Cosmological Argument.md>), [§5.1.4](<5.1.4 Argument from Simplicity.md>), [§4.1.11](<4.1.11 Pizzi's Impossibility of Nothingness.md>), [§6.3.1](<6.3.1 Necessity.md>), [§6.7.1](<6.7.1 Power.md>), [§6.7.2](<6.7.2 Causality.md>), [§6.7.4](<6.7.4 Sovereignty.md>); *see also* Argument from contingency

Rawls, John, [§9.4](<9.4 Information.md>), [§9.13](<9.13 Justice.md>), [§9.14](<9.14 Convergence.md>)

Raworth, Kate, Raworth's Doughnut Economics is substantively engaged as an installation example in [§9.15](<9.15 Installation.md>).

Rea, Michael, [§6.2.2](<6.2.2 Unity.md>) Unity: Rea 2009 on analytic models of Trinitarian unity. [§6.9.2](<6.9.2 Righteousness.md>) Righteousness: Rea 2007 on original sin and inherited guilt.

Reactive attitudes, [§8.9.5](<8.9.5 What is Concluded.md>)

Real / Reality, [§1.1](<1.1 Reality.md>), [§2.1](<2.1 The S5 Pipeline.md>), Glossary

Reasoning, [§8.4](<8.4 Reasoning.md>)

Reasons-responsiveness, [§8.9.1](<8.9.1 What is Disputed.md>)

Reciprocal altruism, [§8.12.4](<8.12.4 What is Confirmed.md>)

Recurrence, *see* Cycle; Eternal recurrence

Recursive Depth → Phenomenal Interiority, §8, Glossary; *see also* Consciousness; Reflexive awareness

Reference (linguistics), [§8.10.2](<8.10.2 What is Required.md>), [§8.10.3](<8.10.3 What is Predicted.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Reflective self-awareness, [§8.1](<8.1 Drive.md>), Glossary; *see also* Reflexive awareness

Reflexive awareness, [§8.1](<8.1 Drive.md>), Glossary; *see also* Pre-reflective self-awareness; Reflective self-awareness

Regan, Tom, Regan's rights-based animal ethics is substantively engaged in the agriculture framework ([§9.6](<9.6 Agriculture.md>)) and dispute section ([§9.6.1](<9.6.1 What is Disputed.md>)).

Relatability (divine), [§6.8.2](<6.8.2 Relatability.md>)

Relation (divine), *see* Relatability (divine)

Relationalism, [§7.3.1](<7.3.1 What is Disputed.md>)

Reliabilism, [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.3](<8.3.3 What is Predicted.md>)

Religious naturalism, [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Religious pluralism, [§6.2.2](<6.2.2 Unity.md>), [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Representation, [§9.3](<9.3 Representation.md>), [§9.3.1](<9.3.1 What is Disputed.md>)–[§9.3.5](<9.3.5 What is Concluded.md>)

Republicanism, [§9.1](<9.1 Rights.md>), [§9.15](<9.15 Installation.md>); *see also* Pettit, Philip

Revelation (divine), [§6.8.4](<6.8.4 Revelation.md>)

Revised conception of God, *see* Embedded deity; Three Conceptions of God

Ricoeur, Paul, [§8.5](<8.5 Identity.md>), [§8.5.1](<8.5.1 What is Disputed.md>), [§8.8.1](<8.8.1 What is Disputed.md>)

Righteousness (divine), [§6.9.2](<6.9.2 Righteousness.md>)

Rights, [§9.1](<9.1 Rights.md>), [§9.1.1](<9.1.1 What is Disputed.md>)–[§9.1.5](<9.1.5 What is Concluded.md>)

Rorty, Richard, [§8.3.5](<8.3.5 What is Concluded.md>)

Rosen, Gideon, [§4.4.9](<4.4.9 Modal Collapse Objection.md>)

Russell, Bertrand, [§4.3.10](<4.3.10 Bundle and Trope Theory.md>), [§7.4.2](<7.4.2 What is Required.md>), [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.3](<8.3.3 What is Predicted.md>), [§8.4](<8.4 Reasoning.md>), [§8.4.1](<8.4.1 What is Disputed.md>), [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Russellian Monism, [§4.3.3](<4.3.3 Russellian Monism.md>), [§6.1](<6.1 Greatness.md>), §8, [§8.2](<8.2 Feeling.md>)

Ryle, Gilbert, [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.3](<8.3.3 What is Predicted.md>)

S5, [§2.1.4](<2.1.4 Modal Stability.md>), [§2.1.5](<2.1.5 The S5 Bottleneck.md>), Appendix B item 16, Glossary Principles

S5 Bottleneck, [§2.1.5](<2.1.5 The S5 Bottleneck.md>)

Salience, [§8.2.3](<8.2.3 What is Predicted.md>)

Samuelson, Paul A., Samuelson's public-goods framework is substantively engaged in the economy account ([§9.7](<9.7 Economy.md>)) and its dispute section ([§9.7.1](<9.7.1 What is Disputed.md>)).

Sandel, Michael, [§9.15](<9.15 Installation.md>)

Sartre, [§8.2.4](<8.2.4 What is Confirmed.md>), [§8.7.1](<8.7.1 What is Disputed.md>), [§8.8](<8.8 Meaning.md>), [§8.8.1](<8.8.1 What is Disputed.md>), [§8.8.5](<8.8.5 What is Concluded.md>)

Saussure, Ferdinand de, [§8.10](<8.10 Language.md>), [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Scanlon, T. M., [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>), [§9.15](<9.15 Installation.md>)

Schaffer, Jonathan, [§1.5.5](<1.5.5 Ground and Dependence.md>), [§1.5.9](<1.5.9 What the Operators Require.md>), [§2.2.2](<2.2.2 Actuality's Reach.md>), [§2.4.1](<2.4.1 Constituting Modal Structure.md>), [§2.4.3](<2.4.3 Demand Instantiation.md>), [§2.6.6](<2.6.6 Modal Identity.md>), [§4.1.7](<4.1.7 Modal Conventionalism.md>), [§4.1.10](<4.1.10 The Source of Possibility.md>), [§4.3.4](<4.3.4 Cosmopsychism.md>), [§4.3.11](<4.3.11 Mereological Nihilism.md>), [§4.4.7](<4.4.7 Sider's Structuralism.md>), [§4.4.9](<4.4.9 Modal Collapse Objection.md>)

Schellenberg, J. L., [§6.8.4](<6.8.4 Revelation.md>), Excursus E.3.1

Schleiermacher, Friedrich, [§8.14.5](<8.14.5 What is Concluded.md>)

Schmid, Joseph C., [§4.2.9](<4.2.9 Existential Inertia.md>)

Schopenhauer, [§4.3.5](<4.3.5 Idealism.md>), [§8.1](<8.1 Drive.md>), [§8.1.1](<8.1.1 What is Disputed.md>), [§8.6](<8.6 Sexuality.md>), [§8.6.1](<8.6.1 What is Disputed.md>), [§8.13](<8.13 Art.md>)

Schumpeter, Joseph A., Schumpeter's competitive-elite theory is substantively engaged in the economy dispute ([§9.7.1](<9.7.1 What is Disputed.md>)) and representation framework ([§9.3](<9.3 Representation.md>)).

Scriptural conception of God, [§6.9.2](<6.9.2 Righteousness.md>), Glossary

Searle, John, [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Second law of thermodynamics, [§7.2.3](<7.2.3 What is Predicted.md>), [§7.2.4](<7.2.4 What is Confirmed.md>)

Second-personal knowledge, [§6.4.1](<6.4.1 Awareness.md>), [§6.4.2](<6.4.2 Knowledge.md>), [§6.9.1](<6.9.1 Benevolence.md>)

SEEKING system, [§8.1](<8.1 Drive.md>), [§8.1.4](<8.1.4 What is Confirmed.md>)

Seeskin, Kenneth, Seeskin's work on Maimonides and negative theology is substantively engaged in Via Negativa ([§5.2.2](<5.2.2 Via Negativa.md>)) and the Chapter 6 framing.

*Sein-zum-Tode*, [§8.7](<8.7 Mortality.md>), [§8.7.1](<8.7.1 What is Disputed.md>), [§8.7.4](<8.7.4 What is Confirmed.md>)

Self-determination theory, [§8.8.4](<8.8.4 What is Confirmed.md>)

Self-model theory, [§8.5](<8.5 Identity.md>), [§8.5.1](<8.5.1 What is Disputed.md>)

Self-modeling, [§7.8](<7.8 Life.md>), §8

Sellars, Wilfrid, Sellars's myth of the given and space-of-reasons position is substantively engaged in the Triunity of Nature discussion ([§2.6.9](<2.6.9 Triunity of Nature.md>)).

Sempiternity, [§6.3.2](<6.3.2 Eternity.md>)

Sen, Amartya, [§9.1](<9.1 Rights.md>), [§9.7.1](<9.7.1 What is Disputed.md>), [§9.10](<9.10 Healthcare.md>), [§9.15](<9.15 Installation.md>); *see also* Capabilities approach; Nussbaum

Sexuality, [§8.6](<8.6 Sexuality.md>)

Shackel, Nicholas, Originator of the unsatisfiable-pair diagnosis of Benardete paradoxes, deployed in the causal-finitism discussion at [§5.1.2](<5.1.2 Cosmological Argument.md>).

Shafer-Landau, Russ, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

Shankara, §6, [§8.14.5](<8.14.5 What is Concluded.md>)

Shapiro, Stewart, Shapiro's mathematical structuralism is substantively engaged in the Platonism discussion ([§4.2.4](<4.2.4 Platonism.md>)) and Structural Realism ([§4.3.9](<4.3.9 Structural Realism.md>)).

Shared interiority, [§8.10](<8.10 Language.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Ship of Theseus, The Ship of Theseus is substantively used to develop continuity-based identity in [§8.5](<8.5 Identity.md>).

Shirky, Clay, [§9.2](<9.2 Belonging.md>), [§9.2.1](<9.2.1 What is Disputed.md>), [§9.2.3](<9.2.3 What is Predicted.md>), [§9.2.4](<9.2.4 What is Confirmed.md>), [§9.2.5](<9.2.5 What is Concluded.md>), [§9.4](<9.4 Information.md>), [§9.4.1](<9.4.1 What is Disputed.md>), [§9.4.3](<9.4.3 What is Predicted.md>), [§9.4.4](<9.4.4 What is Confirmed.md>), [§9.4.5](<9.4.5 What is Concluded.md>)

Shoemaker, Sydney, [§4.2.2](<4.2.2 Shoemaker's Time Without Change.md>)

Shue, Henry, Shue's basic-rights argument is substantively engaged in the Rights pillar ([§9.1](<9.1 Rights.md>)) and its dispute section ([§9.1.1](<9.1.1 What is Disputed.md>)).

Sidelle, Alan, Sidelle's modal conventionalism is substantively engaged in [§4.1.7](<4.1.7 Modal Conventionalism.md>).

Sider, Theodore, [§2.6.4](<2.6.4 Persistence's Two Conditions.md>), [§4.2.2](<4.2.2 Shoemaker's Time Without Change.md>), [§4.2.8](<4.2.8 Stage Theory.md>), [§4.2.6](<4.2.6 Block Universe.md>), [§4.3.11](<4.3.11 Mereological Nihilism.md>), [§4.4.7](<4.4.7 Sider's Structuralism.md>); *see also* Structural Realism

Simon, Herbert, [§8.4.1](<8.4.1 What is Disputed.md>)

Simons, Peter, Simons's mereology is substantively engaged in the three-logics discussion ([§2.10.1](<2.10.1 Three Distinct Logics.md>)) and mereological-nihilism treatment ([§4.3.11](<4.3.11 Mereological Nihilism.md>)).

Simplicity (divine), [§5.2.1](<5.2.1 Divine Simplicity.md>), [§6.2.1](<6.2.1 Simplicity.md>), [§6.10](<6.10 No Exit.md>)

Simulation argument (Bostrom), [§2.2.2](<2.2.2 Actuality's Reach.md>) Actuality's Reach; [§4.1](<4.1 Modal and Semantic Foundations.md>); [§5.1.5](<5.1.5 Fine-Tuning Argument.md>) Fine-Tuning. Simulation hypothesis; any host that realizes simulated persistence still instantiates T, S, and Φ.

Simultaneous Causation, [§5.1.3](<5.1.3 Simultaneous Causation.md>)

Singer, Peter, [§8.12.1](<8.12.1 What is Disputed.md>), [§9.6](<9.6 Agriculture.md>), [§9.6.5](<9.6.5 What is Concluded.md>)

Singularity (cosmological), [§7.6](<7.6 Singularity.md>)

Skeptical theism, [§6.9.2](<6.9.2 Righteousness.md>)

Skepticism, [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.5](<8.3.5 What is Concluded.md>)

Skow, Bradford, [§4.3.12](<4.3.12 Haecceitism.md>)

Smart, J. J. C., Smart's B-theory and block-universe work is substantively engaged in the Block Universe analysis ([§4.2.6](<4.2.6 Block Universe.md>)).

Smith, Adam, Smith's political economy and moral-sentiments work are substantively engaged in the economy framework ([§9.7](<9.7 Economy.md>)) and dispute section ([§9.7.1](<9.7.1 What is Disputed.md>)).

Smolin, Lee, Smolin's temporal naturalism and defense of time's fundamentality are substantively engaged in [§2.8.4](<2.8.4 Necessity Precedes Contingency.md>) and [§4.2.3](<4.2.3 Emergent Time.md>).

Sobel, Jordan Howard, Sobel's symmetry objection to the modal ontological argument is substantively distinguished and engaged in [§5.1.7](<5.1.7 Modal Ontological Argument.md>).

Sober, Elliott, Sober's work on simplicity and the design inference is substantively engaged in [§5.1.4](<5.1.4 Argument from Simplicity.md>) and [§7.8.1](<7.8.1 What is Disputed.md>).

Social construction of technology, [§8.11.1](<8.11.1 What is Disputed.md>); *see also* Actor-network theory

Social constructionism, [§8.6.1](<8.6.1 What is Disputed.md>), [§8.6.5](<8.6.5 What is Concluded.md>), [§8.14.1](<8.14.1 What is Disputed.md>)

Social identity, [§8.5](<8.5 Identity.md>), [§8.5.1](<8.5.1 What is Disputed.md>)

Sociobiology, [§8.6.1](<8.6.1 What is Disputed.md>), [§8.6.5](<8.6.5 What is Concluded.md>)

Somatic-marker hypothesis, [§8.2.1](<8.2.1 What is Disputed.md>), [§8.2.4](<8.2.4 What is Confirmed.md>)

Sorites paradox, [§2.1.1](<2.1.1 Modal Bivalence.md>)

Sosa, Ernest, [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.3](<8.3.3 What is Predicted.md>)

Soul-Making Theodicy, Excursus E.1.5; *see also* Hick, John

Sovereignty, [§6.7.4](<6.7.4 Sovereignty.md>)

*Soziale Marktwirtschaft*, [§9.7](<9.7 Economy.md>)

Space, [§1.3](<1.3 Change.md>), [§1.4](<1.4 Three Conditions.md>), [§2.5](<2.5 Triconditional Necessity.md>), [§7.3](<7.3 Space.md>), [§7.3.1](<7.3.1 What is Disputed.md>)–[§7.3.5](<7.3.5 What is Concluded.md>), Glossary Spatiality

Spacetime, [§7.3](<7.3 Space.md>), [§7.5.1](<7.5.1 Spacetime.md>), Appendix D, Glossary

Spatial logic, [§2.10.1](<2.10.1 Three Distinct Logics.md>)

Spatiality, *see* Space, Glossary

Special relativity, [§7.3.1](<7.3.1 What is Disputed.md>), [§7.5.1](<7.5.1 Spacetime.md>)

Speech act theory, [§8.10.5](<8.10.5 What is Concluded.md>)

Spinoza, [§2.9](<2.9 Precedent Convergence.md>), [§4.3.4](<4.3.4 Cosmopsychism.md>), [§4.4.9](<4.4.9 Modal Collapse Objection.md>), [§5.3.1](<5.3.1 Spinozist Pantheism.md>), [§4.2.9](<4.2.9 Existential Inertia.md>), [§6.2.2](<6.2.2 Unity.md>), [§7.1](<7.1 Convergence of Method.md>), [§8.1](<8.1 Drive.md>), [§8.1.1](<8.1.1 What is Disputed.md>), [§8.1.3](<8.1.3 What is Predicted.md>), [§8.1.5](<8.1.5 What is Concluded.md>), [§8.2](<8.2 Feeling.md>), [§8.2.4](<8.2.4 What is Confirmed.md>), [§8.8.3](<8.8.3 What is Predicted.md>), [§8.12.3](<8.12.3 What is Predicted.md>), [§8.14](<8.14 Spirituality.md>), [§8.14.1](<8.14.1 What is Disputed.md>)

Spirituality, [§8.14](<8.14 Spirituality.md>), [§8.14.1](<8.14.1 What is Disputed.md>)–[§8.14.5](<8.14.5 What is Concluded.md>)

*Spiritus*, [§7.8](<7.8 Life.md>), [§8.14.3](<8.14.3 What is Predicted.md>)

Spontaneous language genesis, [§8.10.4](<8.10.4 What is Confirmed.md>)

Stace, W. T., [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.4](<8.14.4 What is Confirmed.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Stalnaker, Robert, Stalnaker's abstract possible-worlds account is substantively engaged in the Modal Realism discussion ([§4.4.1](<4.4.1 Modal Realism.md>)).

Standard Model, [§7.4](<7.4 Substance.md>), [§7.4.4](<7.4.4 What is Confirmed.md>), Appendix D

Stanley, Jason, [§8.3](<8.3 Knowledge.md>) Knowledge: Stanley and Williamson on knowing-how, and Stanley on practical interests in knowledge; the section uses these positions in its account of the forms and stakes of held grasp.

Stern, Josef, [§5.2.2](<5.2.2 Via Negativa.md>) Via Negativa: Stern 2013 on Maimonidean predicate-denial and the Guide's apophatic semantics. §6 chapter root: Maimonides's negative theology is named as a cross-traditional instance of the chapter's structural pressure.

Stone paradox, [§6.7.1](<6.7.1 Power.md>)

Stratified Architecture, [§2.10.2](<2.10.2 The Stratified Architecture.md>); *see also* Three Logical Strata

Strawson, Galen, [§4.3.3](<4.3.3 Russellian Monism.md>), §8, [§8.5.1](<8.5.1 What is Disputed.md>), [§8.5.5](<8.5.5 What is Concluded.md>), [§8.9.1](<8.9.1 What is Disputed.md>)

Strawson, P. F., [§6.1](<6.1 Greatness.md>), [§8.9.5](<8.9.5 What is Concluded.md>)

Street, Sharon, [§8.12.1](<8.12.1 What is Disputed.md>), [§8.12.5](<8.12.5 What is Concluded.md>)

Structural Realism, [§4.3.9](<4.3.9 Structural Realism.md>), [§4.4.7](<4.4.7 Sider's Structuralism.md>), [§6.1](<6.1 Greatness.md>), [§7.4.2](<7.4.2 What is Required.md>), [§8.3](<8.3 Knowledge.md>)

Structural Requirement, [§2.4](<2.4 Structural Requirement.md>)

Structural Role, Glossary

Stump, Eleonore, [§6.4.1](<6.4.1 Awareness.md>), [§6.7.3](<6.7.3 Interaction.md>), [§6.7.4](<6.7.4 Sovereignty.md>), [§6.8.2](<6.8.2 Relatability.md>), [§6.9.2](<6.9.2 Righteousness.md>), [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.5](<8.9.5 What is Concluded.md>), Excursus E.1.6

Sublime, [§8.13](<8.13 Art.md>); *see also* Tragedy (aesthetics); Beauty

Subsistence, §9

Substance, [§1.3](<1.3 Change.md>), [§1.4](<1.4 Three Conditions.md>), [§2.5](<2.5 Triconditional Necessity.md>), [§7.4](<7.4 Substance.md>), [§7.4.1](<7.4.1 What is Disputed.md>)–[§7.4.5](<7.4.5 What is Concluded.md>), Glossary Physicality

Substantial logic, [§2.10.1](<2.10.1 Three Distinct Logics.md>)

Substance dualism, [§7.8](<7.8 Life.md>), Appendix D

Substantivalism, [§7.3.1](<7.3.1 What is Disputed.md>)

Subtraction argument, [§3.2.6](<3. Convergence.md>)

Succession, *see* Time

Suchocki, Marjorie, Suchocki's process-theology development is substantively engaged in the Process Theology analysis ([§5.3.3](<5.3.3 Process Theology.md>)).

*Summum bonum*, [§6.9.1](<6.9.1 Benevolence.md>)

Sunstein, Cass R., [§9.4.4](<9.4.4 What is Confirmed.md>) What is Confirmed: Sunstein's [Republic.com](http://republic.com/) (2001) anticipates filter-bubble, cascade, and group-polarization dynamics in engagement-optimized information environments.

Superdeterminism, [§7.4.4](<7.4.4 What is Confirmed.md>), Appendix D

Supernatural Preclusion, [§6.1](<6.1 Greatness.md>), [§6.10](<6.10 No Exit.md>), Appendix B item 15, Glossary Theorem 8

Supervenience, [§1.5.4](<1.5.4 Supervenience.md>), Glossary

Sustained Energy Throughput, [§7.8](<7.8 Life.md>), Glossary

Swampman, [§8.3](<8.3 Knowledge.md>); *see also* Content externalism; Davidson, Donald

Swinburne, Richard, [§5.1.4](<5.1.4 Argument from Simplicity.md>), [§5.1.5](<5.1.5 Fine-Tuning Argument.md>), [§6.1](<6.1 Greatness.md>), [§6.2.1](<6.2.1 Simplicity.md>), [§6.8.3](<6.8.3 Describability.md>), [§6.9.1](<6.9.1 Benevolence.md>), [§6.9.2](<6.9.2 Righteousness.md>), [§6.2.4](<6.2.4 Perfection.md>), [§6.10](<6.10 No Exit.md>), [§8.3.5](<8.3.5 What is Concluded.md>), [§8.8](<8.8 Meaning.md>), [§8.8.1](<8.8.1 What is Disputed.md>), [§8.8.5](<8.8.5 What is Concluded.md>), [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.4](<8.14.4 What is Confirmed.md>), Excursus E.1.5, Excursus E.1.7, Excursus E.4.1

Synthesis, [§7.9](<7.9 Synthesis.md>), [§8.15](<8.15 Synthesis.md>)

Tao (Taoism), [§8.14.5](<8.14.5 What is Concluded.md>) (named once in the impersonae list within the discussion of Hick's pluralism: Brahman, Tao, Nirvāṇa, śūnyatā). Valid as a single-locus index entry; a dedicated Taoist engagement remains a separate editorial decision.

Tarski, Alfred, [§2.10.1](<2.10.1 Three Distinct Logics.md>) Three Distinct Logics: Tarski 1959 as a foundation of spatial/topological logic. [§4.3.11](<4.3.11 Mereological Nihilism.md>) Mereological Nihilism: Tarski 1929 in the classical-mereology lineage.

Taylor, Charles, [§8.8.1](<8.8.1 What is Disputed.md>)

Technology, [§8.11](<8.11 Technology.md>), [§8.11.1](<8.11.1 What is Disputed.md>)–[§8.11.5](<8.11.5 What is Concluded.md>)

Tegmark, Max, [§4.3.6](<4.3.6 The Unreasonable Effectiveness of Mathematics.md>) Unreasonable Effectiveness of Mathematics; [§4.3.7](<4.3.7 Mathematical Universe Hypothesis.md>) Mathematical Universe Hypothesis; [§4.3.9](<4.3.9 Structural Realism.md>) Structural Realism. Tegmark's mathematical-universe proposal is distinguished from the book's shared-structure account.

Teleosemantics, [§8.1.1](<8.1.1 What is Disputed.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Temporality, *see* Time, Glossary

Temporality (divine), *see* Tensity (divine)

Tensity (divine), [§6.3.2](<6.3.2 Eternity.md>)

Terror management theory, [§8.7.1](<8.7.1 What is Disputed.md>), [§8.7.4](<8.7.4 What is Confirmed.md>), [§8.7.5](<8.7.5 What is Concluded.md>)

Theistic activism, [§6.3.1](<6.3.1 Necessity.md>), [§6.7.1](<6.7.1 Power.md>)

Theistic realism, [§8.14.1](<8.14.1 What is Disputed.md>)

Theodicy, [§6.9.1](<6.9.1 Benevolence.md>)

Theorems, *see* Glossary, Theorems

Theory of mind, [§8.5](<8.5 Identity.md>), [§8.5.1](<8.5.1 What is Disputed.md>), [§8.5.2](<8.5.2 What is Required.md>), [§8.5.3](<8.5.3 What is Predicted.md>)

Third-person, *see* First-person / Third-person

Thomasson, Amie, [§4.1.8](<4.1.8 Metaontological Deflationism.md>)

Three Conceptions of God, [§6.2.4](<6.2.4 Perfection.md>), [§6.10](<6.10 No Exit.md>); *see also* Classical God; Embedded deity; Scriptural conception of God

Three Logical Strata, [§2.10](<2.10 Three Logical Strata.md>), [§2.10.1](<2.10.1 Three Distinct Logics.md>)–[§2.10.3](<2.10.3 The Metalogical Position.md>); *see also* Metalogical Position; Stratified Architecture

Three-Horn Dilemma, [§6.10](<6.10 No Exit.md>), Appendix B item 19, Glossary; *see also* God-Precluded; No Exit

Through w* Argument, [§6.1](<6.1 Greatness.md>), Appendix B item 16, Glossary; *see also* Bilateral Symmetry; w* (world-star)

Time, [§1.3](<1.3 Change.md>), [§1.4](<1.4 Three Conditions.md>), [§2.5](<2.5 Triconditional Necessity.md>), [§4.2](<4.2 Time, Change, and the Changeless.md>), [§7.2](<7.2 Time.md>), [§7.2.1](<7.2.1 What is Disputed.md>)–[§7.2.5](<7.2.5 What is Concluded.md>), Glossary Temporality

Token, [§7.7](<7.7 Cosmic History.md>), Appendix D, Glossary

Tomasello, Michael, [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.4](<8.10.4 What is Confirmed.md>), [§8.10.5](<8.10.5 What is Concluded.md>), [§8.11.4](<8. Expanding the Field.md>)

Tooley, Michael, [§4.2.5](<4.2.5 The Unreality of Time.md>)

*Tota simul*, [§6.3.2](<6.3.2 Eternity.md>), [§6.7.3](<6.7.3 Interaction.md>)

Tragedy (aesthetics), [§8.13](<8.13 Art.md>); *see also* Sublime

Transcendental argument for God, [§5.1.9](<5.1.9 Transcendental Argument.md>)

Transcript of denial, *see* Performative Self-Refutation

Transhumanism, [§8.11.1](<8.11.1 What is Disputed.md>); *see also* Posthumanism

Transition Closure, [§2.1.6](<2.1.6 The Transition Closure.md>)

Triconditional Cross-Entailment, [§2.6.7](<2.6.7 Triconditional Cross-Entailment.md>), Appendix B item 8, Glossary Theorem 3

Triconditional Identity, [§2.6](<2.6 Triconditionality of Nature.md>), [§2.6.10](<2.6.10 Triconditional Identity.md>), [§2.8.5](<2.8.5 Necessity of Nature.md>), Appendix B item 11, Glossary Theorem 5

Trinity, [§6.2.1](<6.2.1 Simplicity.md>), [§6.8.2](<6.8.2 Relatability.md>), [§6.2.2](<6.2.2 Unity.md>)

Triunity of Nature, [§2.6.9](<2.6.9 Triunity of Nature.md>), Glossary Named Results

Trolley problem, The trolley problem receives a sustained upstream-justice inversion in [§9.13](<9.13 Justice.md>).

Trope Theory, [§4.3.10](<4.3.10 Bundle and Trope Theory.md>), [§7.4.2](<7.4.2 What is Required.md>)

Tushnet, Mark, [§9.1.4](<9.1.4 What is Confirmed.md>) What is Confirmed: Tushnet 2008, Weak Courts, Strong Rights, in the social-rights constitutionalization and enforcement literature. [§9.13](<9.13 Justice.md>) Justice: Tushnet's rights-enforcement work bears on the legal architecture connecting substantive rights to institutional remedies.

Tversky, Amos, [§8.4.1](<8.4.1 What is Disputed.md>), [§8.12](<8.12 Morality.md>)

Twin Earth, [§2.4.2](<2.4.2 Structural Gap.md>) Structural Gap; [§4.1.1](<4.1.1 Rigid Designation.md>) Rigid Designation. Putnam's Twin Earth distinguishes descriptive role from natural-kind essence; used to test — and reject — a hidden-filler gap for structural roles.

Two-Dimensional Semantics, [§4.1.2](<4.1.2 Two-Dimensional Semantics.md>)

Tye, Michael, Tye's representational account of awareness is substantively engaged in the divine-awareness analysis ([§6.4.1](<6.4.1 Awareness.md>)) and Feeling discussion ([§8.2.1](<8.2.1 What is Disputed.md>)).

Type, [§7.7](<7.7 Cosmic History.md>), Appendix D, Glossary

Unity (divine), [§6.2.2](<6.2.2 Unity.md>); *see also* Simplicity (divine)

Universal grammar, [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.4](<8.10.4 What is Confirmed.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Univocity of being, [§6.8.3](<6.8.3 Describability.md>)

Unmoved mover, [§6.3.3](<6.3.3 Immutability.md>), [§6.7.2](<6.7.2 Causality.md>)

Unreasonable effectiveness of mathematics, [§4.3.6](<4.3.6 The Unreasonable Effectiveness of Mathematics.md>), [§8.4.3](<8.4.3 What is Predicted.md>)

Unsatisfiable pair diagnosis (UPD), Shackel's diagnosis that Benardete paradoxes encode jointly unsatisfiable conditions, so no causal-finitist metaphysical thesis follows; deployed at [§5.1.2](<5.1.2 Cosmological Argument.md>) with Schmid and Malpass's non-causal variant.

Urgency, [§8.2.3](<8.2.3 What is Predicted.md>)

Vacuity Argument, [§3.2.5](<3. Convergence.md>)

Vacuum, [§2.7](<2.7 Nothing to Consider.md>), [§7.4.4](<7.4.4 What is Confirmed.md>), [§7.5.2](<7.5.2 Field.md>), Glossary

Valence, [§8.2](<8.2 Feeling.md>), [§8.2.3](<8.2.3 What is Predicted.md>)

van Hamme, Carlos, Van Hamme's modal objection to a necessary personal God is substantively engaged in the Modal Ontological Argument analysis ([§5.1.7](<5.1.7 Modal Ontological Argument.md>)).

van Inwagen, Peter, [§3.2.4](<3. Convergence.md>), [§4.3.11](<4.3.11 Mereological Nihilism.md>), [§4.4.9](<4.4.9 Modal Collapse Objection.md>), [§8.9.1](<8.9.1 What is Disputed.md>), Excursus E.1.5

Van Til, Cornelius, Van Til's presuppositionalist transcendental argument is substantively engaged in [§5.1.9](<5.1.9 Transcendental Argument.md>).

Varela, Francisco J., Varela's autopoiesis is substantively engaged in the Life account ([§7.8](<7.8 Life.md>)).

*Via negativa*, [§5.2.2](<5.2.2 Via Negativa.md>), [§6.8.3](<6.8.3 Describability.md>), [§8.14](<8.14 Spirituality.md>), [§8.14.1](<8.14.1 What is Disputed.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Virtue epistemology, [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.3](<8.3.3 What is Predicted.md>)

Virtue ethics, [§8.12.1](<8.12.1 What is Disputed.md>)

Vitalism, [§7.8](<7.8 Life.md>), [§7.8.1](<7.8.1 What is Disputed.md>), [§8.1](<8.1 Drive.md>), [§8.1.1](<8.1.1 What is Disputed.md>), [§8.1.5](<8.1.5 What is Concluded.md>)

Volitional necessity, [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.5](<8.9.5 What is Concluded.md>)

Vygotsky, Lev S., Vygotsky's developmental account is substantively engaged in the Education discussion ([§9.9](<9.9 Education.md>)).

w* (world-star), [§6.1](<6.1 Greatness.md>), Appendix B item 16, Glossary Key Concepts

*Wajib al-wujud*, [§6.3.1](<6.3.1 Necessity.md>)

Walzer, Michael, Walzer's just-war theory and spheres-of-justice framework are substantively engaged in §[§9.11](<9.11 Defense.md>) and 9.2.1.

Way Argument, [§3.2.5](<3. Convergence.md>)

Way–Possibility Convertibility, [§3.2.5](<3. Convergence.md>), [§4.1.10](<4.1.10 The Source of Possibility.md>), [§5.2.1](<5.2.1 Divine Simplicity.md>), Glossary

Weakness of will (akrasia), [§8.9.1](<8.9.1 What is Disputed.md>), [§8.9.5](<8.9.5 What is Concluded.md>)

Weinandy, Thomas G., Weinandy's defense of divine impassibility is substantively engaged in the Impassibility analysis ([§6.3.4](<6.3.4 Impassibility.md>)).

Whitehead, [§4.2.4](<4.2.4 Platonism.md>), [§4.4.8](<4.4.8 Whiteheadian Process Metaphysics.md>), [§5.3.3](<5.3.3 Process Theology.md>), [§7.1](<7.1 Convergence of Method.md>), [§7.4.2](<7.4.2 What is Required.md>), [§8.14.5](<8.14.5 What is Concluded.md>)

Whyte, Kyle Powys, Whyte's Indigenous environmental philosophy is substantively engaged in the Environment dispute discussion ([§9.5.1](<9.5.1 What is Disputed.md>)).

Wielenberg, Erik, [§8.12.5](<8.12.5 What is Concluded.md>)

Will (first-person), [§8.9](<8.9 Will.md>), [§8.9.1](<8.9.1 What is Disputed.md>)–[§8.9.5](<8.9.5 What is Concluded.md>); *see also* Knowledge (first-person)

Will (Schopenhauer), [§3.4](<3.4 Reality and Nature Are One.md>)

Will register, [§8.9](<8.9 Will.md>)

Will to power, [§8.1](<8.1 Drive.md>), [§8.1.1](<8.1.1 What is Disputed.md>)

Williams, Bernard, [§8.5.1](<8.5.1 What is Disputed.md>), [§8.7.1](<8.7.1 What is Disputed.md>), Excursus E.2.3, Excursus E.3.4, Excursus E.5.1

Williamson, Timothy, [§2.1.3](<2.1.3 Modal Constitution.md>), [§2.1.4](<2.1.4 Modal Stability.md>), [§2.3](<2.3 Necessary Possibility of Change.md>), [§2.9](<2.9 Precedent Convergence.md>), [§4.1.6](<4.1.6 Quinean Modal Skepticism.md>), [§4.1.10](<4.1.10 The Source of Possibility.md>), [§4.4](<4.4 Modal Variants and Extensions.md>), [§4.4.6](<4.4.6 Necessitism.md>), [§4.4.7](<4.4.7 Sider's Structuralism.md>), [§8.3](<8.3 Knowledge.md>), [§8.3.1](<8.3.1 What is Disputed.md>), [§8.3.3](<8.3.3 What is Predicted.md>), Appendix A

Wittgenstein, Ludwig, [§2.10.3](<2.10.3 The Metalogical Position.md>), [§4.1.9](<4.1.9 Wittgensteinian Quietism.md>), [§4.2.4](<4.2.4 Platonism.md>), [§8.10](<8.10 Language.md>), [§8.10.1](<8.10.1 What is Disputed.md>), [§8.10.2](<8.10.2 What is Required.md>), [§8.10.5](<8.10.5 What is Concluded.md>)

Wittgensteinian Quietism, [§4.1.9](<4.1.9 Wittgensteinian Quietism.md>)

Wolf, Susan, [§8.8.1](<8.8.1 What is Disputed.md>), [§8.8.3](<8.8.3 What is Predicted.md>), [§8.8.4](<8.8.4 What is Confirmed.md>), [§8.8.5](<8.8.5 What is Concluded.md>), [§8.9.1](<8.9.1 What is Disputed.md>)

Wolterstorff, Nicholas, [§5.2.1](<5.2.1 Divine Simplicity.md>), [§6.3.2](<6.3.2 Eternity.md>), [§6.7.2](<6.7.2 Causality.md>), [§6.7.3](<6.7.3 Interaction.md>), [§6.8.2](<6.8.2 Relatability.md>)

Woodward, James, [§4.1.4](<4.1.4 Humean Contingency.md>) Humean Contingency. James Woodward's interventionist theory is used to press agent-side access to causal efficacy and regularity-establishing interventions.

Woodward, Richard, [§4.4.4](<4.4.4 Modal Fictionalism.md>) Modal Fictionalism. Richard Woodward's defense of modal fictionalism addresses the charge that the fiction is artificially constructed.

Word (divine), [§6.8.3](<6.8.3 Describability.md>); *see also* *Via negativa*

Worrall, John, [§4.3.9](<4.3.9 Structural Realism.md>) Structural Realism. Worrall's epistemic structural realism: what survives theory change is relational/mathematical structure rather than a specific ontology of objects.

Wright, Erik Olin, [§9.7.1](<9.7.1 What is Disputed.md>) Economy disputed. Erik Olin Wright's structural-conflict tradition frames capital's extraction as structural rather than a merely correctable policy flaw.

Wright, N. T., Wright's resurrection argument is substantively engaged and answered in E.5.3 The Resurrection.

Wykstra, Stephen J., Wykstra's skeptical-theist approach is substantively engaged in E.1.2 Skeptical Theism and [§6.9.2](<6.9.2 Righteousness.md>).

Young, Iris Marion, Young's structural-injustice account is substantively engaged in the Rights analysis ([§9.1](<9.1 Rights.md>)).

Zagzebski, Linda, [§8.3](<8.3 Knowledge.md>) Knowledge. Linda Zagzebski's virtue epistemology; intellectual virtues and foreknowledge issues used in the knowledge debate.

Zahavi, Dan, [§8.5.1](<8.5.1 What is Disputed.md>)

Zehr, Howard, Zehr's restorative-justice framework is substantively engaged in the Justice analysis ([§9.13](<9.13 Justice.md>)).

Zeno of Elea, [§2.2.1](<2.2.1 Change Is Actual.md>) Change Is Actual. Zeno's Dichotomy, Achilles, and Arrow paradoxes deny motion; answered by the performative actuality of succession.

Zeno's paradoxes, [§2.2.1](<2.2.1 Change Is Actual.md>)

Zombie (philosophical), [§7.8](<7.8 Life.md>)

Φ (Physicality), *see* Physicality; *see also* Substance

↔ / → (conditionals), Appendix A; *see also* Modal logic

∅ (absolute nothingness), [§2.7](<2.7 Nothing to Consider.md>), [§2.7.1](<2.7.1 Null State (∅).md>), [§2.7.2](<2.7.2 Incoherence of ∅.md>), [§3.2.6](<3. Convergence.md>), Glossary: Null State (∅)

∧ / ∨ / ¬ (logical connectives), Appendix A

◇ / □ (modal operators), [§2.1](<2.1 The S5 Pipeline.md>), [§2.2](<2.2 Cartesian Certainty.md>), [§2.4](<2.4 Structural Requirement.md>), Appendix A, Glossary


---

← [Bibliography](Bibliography.md)
