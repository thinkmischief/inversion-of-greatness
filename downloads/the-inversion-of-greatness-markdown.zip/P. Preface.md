One question runs beneath the rest: what is necessary for anything at all to be? 

The argument this book runs starts with the nature of necessity, and works outward: from a small set of conditions anything real must meet, to what those conditions permit and foreclose, to what, in the end, they require. Possibility is not a space Reality is set inside. It is what Reality constitutes: what can be is fixed by what Reality is.

This book is an analytic monograph, and it holds itself to what that requires. It argues by derivation and nothing else: every claim is the working-out of what earlier results already entail, never a stance carried to the subject from outside. It does not take the step the tradition's strongest arguments depend on: the step from what we can imagine without contradiction to what could genuinely have been. It supports its conclusion the slower way: by defending each load-bearing premise without slack, and by meeting rival views in their strongest available form.

From there the work reaches its central move: an inversion. Taken attribute by attribute, the greatness the tradition located in a being beyond the world is returned to Reality's own structure. Where that structure becomes aware enough of itself and of its effect on the lives it can help or harm, that greatness is shown to be not a finished gift but a possibility: what subjects, together, can take up and make actual. That this is where the argument leads is set down here only as a direction, not a creed: it is earned, if at all, in the late chapters, and assumed in none.

The book's strict core is its modal structure, properly derived. The later chapters, which carry that result outward, argue in a lighter register: a difference that is also a difference in finish. They are where the work most needs other hands: readers at home in fields the argument only threads through, whose better-informed corrections are something to take, not to fend off. My wager is that such correction will sharpen these chapters rather than unseat them, and will more often carry the argument further than turn it around, but it is a wager, and I name it as one. Disagreement there is not a refutation of the central argument, and nothing in those later reaches is offered as finished; every such shift of register is marked, because an unmarked one reads as overreach.

The argument stands or falls as a deduction: its premises must be true, and its steps must follow. A serious objection therefore has to locate the point at which a premise fails, an inference breaks, a term shifts, or the argument claims more than it has earned. Where an objection meets that standard, it and its reply belong printed beside the argument.

A word on spirit. This work engages a tradition that holds many of the readers I hope for, and it argues with many thinkers from whom I finally part. I have tried throughout to take each at full strength: to write as someone for whom that tradition and those thinkers are part of how my own answers were found. Whatever it overturns, it was not written to diminish what they reached for.


---

← [Copyright](Copyright.md) | [I. Introduction](<I. Introduction.md>) →
