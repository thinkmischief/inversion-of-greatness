Adamala, K., and J. W. Szostak. 2013. “Nonenzymatic Template-Directed RNA Synthesis Inside Model Protocells.” *Science* 342 (6162): 1098–1100.

Robert Merrihew Adams. 1971. “The Logical Structure of Anselm's Arguments.” *The Philosophical Review* 80 (1): 28–54.

Robert Merrihew Adams. 1972. “Must God Create the Best?” *The Philosophical Review* 81, no. 3: 317–332.

Robert Merrihew Adams. 1974. “Theories of Actuality.” *Noûs* 8(3): 211–231.

Adams, Robert Merrihew. 1977. “Middle Knowledge and the Problem of Evil.” *American Philosophical Quarterly* 14, no. 2: 109–117.

Adams, R. M. 1979. “Primitive Thisness and Primitive Identity.” *Journal of Philosophy*.

Adams, R. M. 1983. “Divine Necessity.” *Journal of Philosophy* 80 (11): 741–752.

Robert Merrihew Adams. 1999. *Finite and Infinite Goods: A Framework for Ethics*. New York: Oxford University Press.

Peter Adamson. 2013. “From the Necessary Existent to God.” In Interpreting Avicenna: Critical Essays, ed. Peter Adamson, 170–189. Cambridge University Press.

Ralph Adolphs. 2013. “The Biology of Fear.” *Current Biology* 23(2): R79–R93.

Ralph Adolphs. 2017. “How Should Neuroscience Study Emotions? By Distinguishing Emotion States, Concepts, and Experiences.” *Social Cognitive and Affective Neuroscience* 12(1): 24–31.

Agamben, Giorgio. 1998. *Homo Sacer: Sovereign Power and Bare Life*. Translated by Daniel Heller-Roazen. Stanford, CA: Stanford University Press.

Anthony Aguirre and Steven Gratton. 2002. “Steady-State Eternal Inflation.” *Physical Review D* 65: 083507.

Yakir Aharonov and David Bohm. 1959. “Significance of Electromagnetic Potentials in the Quantum Theory.” *Physical Review* 115(3):485–491.

Aiello, M., I. Pratt-Hartmann, and J. van Benthem (eds.). 2007. *Handbook of Spatial Logics*. Dordrecht: Springer.

al-Ghazālī. c. 1095. *The Incoherence of the Philosophers (Tahāfut al-Falāsifa)*. Trans. Michael E. Marmura. 2nd ed. Brigham Young University Press, 2000.

al-Kindī. c. 850. *On First Philosophy (Fī al-Falsafa al-Ūlā)*. Trans. Alfred L. Ivry. Al-Kindī's Metaphysics. SUNY Press, 1974.

Adam G. Riess et al. 1998. “Observational Evidence from Supernovae for an Accelerating Universe and a Cosmological Constant.” *The Astronomical Journal* 116(3):1009–1038.

Saul Perlmutter et al. 1999. “Measurements of Ω and Λ from 42 High-Redshift Supernovae.” *The Astrophysical Journal* 517(2):565–586.

Lynden K. Shalm et al. 2015. “Strong Loophole-Free Test of Local Realism.” *Physical Review Letters* 115(25):250402.

Caroline B. Albertin et al. 2015. “The Octopus Genome and the Evolution of Cephalopod Neural and Morphological Novelties.” *Nature* 524(7564):220–224.

Hsiang-Wen Hsu et al. 2015. “Ongoing Hydrothermal Activities within Enceladus.” *Nature* 519(7542):207–210.

Noa Liscovitch-Brauer et al. 2017. “Trade-off between Transcriptome Plasticity and Genome Evolution in Cephalopods.” *Cell* 169(2):191–202.

Albert, David Z. 2000. *Time and Chance*. Harvard University Press.

David Z Albert. 2015. *After Physics*. Harvard University Press.

Allison, Dale C., Jr. 2010. *Constructing Jesus: Memory, Imagination, and History*. Grand Rapids: Baker Academic.

Michael J. Almeida. 2008. *The Metaphysics of Perfect Beings*. Routledge (Routledge Studies in the Philosophy of Religion).

Almheiri, A., T. Hartman, J. Maldacena, E. Shaghoulian, and A. Tajdini. 2020. “The Entropy of Hawking Radiation.” *Reviews of Modern Physics* 93 (3): 035002.

William P. Alston. 1991. “The Inductive Argument from Evil and the Human Cognitive Condition.” *Philosophical Perspectives* 5 (1991): 29–67.

Anderson, Edward. 2017. *The Problem of Time: Quantum Mechanics Versus General Relativity*. Springer (Fundamental Theories of Physics).

Anderson, Elizabeth. 2017. *Private Government: How Employers Rule Our Lives (and Why We Don't Talk about It)*. Princeton University Press.

Andreas Albrecht, Lorenzo Sorbo. 2004. “Can the Universe Afford Inflation?” *Physical Review D* 70(6):063528.

Anscombe, G. E. M. 1971. *Causality and Determination*. Cambridge: Cambridge University Press.

Apel, Karl-Otto. 1976. “The Apriori of the Communication Community.” in Towards a Transformation of Philosophy.

Apel, Karl-Otto. 1980. *Towards a Transformation of Philosophy*. Routledge & Kegan Paul.

Aquinas, Thomas. (1265–1266) 1932. *De Potentia*. In On the Power of God, translated by E. English. Westminster, MD: Newman Press.

Aquinas, Thomas. (1265–1274) 1947. *Summa Theologiae*. New York: Benziger Brothers.

Aristotle. (4th c. BCE) 1984. *The Complete Works of Aristotle*. Edited by J. Barnes. Princeton, NJ: Princeton University Press.

Armstrong, D. M. 1983. *What Is a Law of Nature?* Cambridge: Cambridge University Press.

Arvind Borde, Alan H. Guth and Alexander Vilenkin. 2003. “Inflationary Spacetimes Are Incomplete in Past Directions.” *Physical Review Letters* 90 (15): 151301.

Ashtekar, A., and P. Singh. 2011. “Loop Quantum Cosmology: A Status Report.” *Classical and Quantum Gravity* 28 (21): 213001.

Aspect, A., J. Dalibard, and G. Roger. 1982. “Experimental Test of Bell's Inequalities Using Time-Varying Analyzers.” *Physical Review Letters* 49 (25): 1804–1807.

Audrey Mithani, Alexander Vilenkin. 2012. “Did the Universe Have a Beginning?” arXiv:1204.4658 [hep-th].

Gustaf Aulén. 1931. *Christus Victor: An Historical Study of the Three Main Types of the Idea of the Atonement*. trans. A. G. Hebert; London: SPCK, 1931 (orig. Swedish Den kristna försoningstanken, 1930).

Avicenna. (c. 1020) 1959. *Avicenna's De Anima (Kitāb al-Nafs), Being the Psychological Part of Kitāb al-Shifāʾ*. Oxford University Press.

Avicenna. (c. 1020) 2005. *The Metaphysics of The Healing*. Translated by Michael E. Marmura. Provo, UT: Brigham Young University Press.

Ayer, A. J. 1936. *Language, Truth and Logic*. Victor Gollancz (London).

David Baggett and Jerry L. Walls. 2011. *Good God: The Theistic Foundations of Morality*. Oxford University Press.

David Baggett and Jerry L. Walls. 2016. *God and Cosmos: Moral Truth and Human Meaning*. Oxford University Press.

Greg L. Bahnsen. 1998. *Van Til's Apologetic: Readings and Analysis*. Presbyterian and Reformed (P&R Publishing), Phillipsburg, NJ.

Baker, G. P., and P. M. S. Hacker. 1980. *Wittgenstein: Understanding and Meaning (Analytical Commentary on the Philosophical Investigations, Vol. 1)*. Blackwell.

Baker, G. P., and P. M. S. Hacker. 1985. *Wittgenstein: Rules, Grammar and Necessity (Analytical Commentary on the Philosophical Investigations, Vol. 2)*. Basil Blackwell.

Balaban, N. Q., J. Merrin, R. Chait, L. Kowalik, and S. Leibler. 2004. “Bacterial Persistence as a Phenotypic Switch.” *Science* 305 (5690): 1622–1625.

Balaguer, Mark. 1998. *Platonism and Anti-Platonism in Mathematics*. Oxford University Press.

Balashov, Yuri, and Michel Janssen. 2003. “Presentism and Relativity.” *The British Journal for the Philosophy of Science* 54 (2): 327–346.

Baldwin, Thomas. 1996. “There Might Be Nothing.” *Analysis*.

Barbour, Julian. 1999. *The End of Time: The Next Revolution in Physics*. Weidenfeld & Nicolson (London).

Bardon, Adrian. 2013. *A Brief History of the Philosophy of Time*. Oxford University Press.

Luke A. Barnes. 2012. “The Fine-Tuning of the Universe for Intelligent Life.” *Publications of the Astronomical Society of Australia* 29 (4): 529–564.

Barrett, J. L. 2004. *Why Would Anyone Believe in God?* Walnut Creek, CA: AltaMira Press.

Lisa Feldman Barrett. 2017. *How Emotions Are Made: The Secret Life of the Brain*. Houghton Mifflin Harcourt (Boston).

Barsalou, Lawrence W. 1999. “Perceptual symbol systems.” *Behavioral and Brain Sciences* 22 (4): 577–609.

Barth, Karl. (1932) 1975. *Church Dogmatics I/1, The Doctrine of the Word of God, Part I*. 2d ed. Edited by Thomas F. Torrance and G. W. Bromiley. Translated by G. W. Bromiley. Edinburgh: T&T Clark.

Bateson, G. 1972. *Steps to an Ecology of Mind*. New York: Ballantine Books.

Bauckham, Richard. 1984. “'Only the Suffering God Can Help': Divine Passibility in Modern Theology.” *Themelios* 9, no. 3: 6–12.

Baum, L., and P. H. Frampton. 2007. “Turnaround in Cyclic Cosmology.” *Physical Review Letters* 98 (7): 071301.

Beall, JC, and Greg Restall. 2006. *Logical Pluralism*. Oxford: Clarendon Press.

Beauchamp, Tom L.; Childress, James F. 1979. *Principles of Biomedical Ethics*. Oxford University Press.

Beaudoin, John. 2007. “The World's Continuance: Divine Conservation or Existential Inertia?” *International Journal for Philosophy of Religion* 61 (2): 83–98.

Becker, E. 1973. *The Denial of Death*. New York: Free Press.

Becker, S., J. Feldmann, S. Wiedemann, H. Okamura, C. Schneider, K. Iwan, A. Crisp, M. Rossa, T. Amatov, and T. Carell. 2019. “Unified Prebiotically Plausible Synthesis of Pyrimidine and Purine RNA Ribonucleotides.” *Science* 366 (6461): 76–82.

Beebee, Helen. 2006. *Hume on Causation*. London: Routledge.

Beebee, Helen; Hitchcock, Christopher; Menzies, Peter (eds.). 2009. *The Oxford Handbook of Causation*. Oxford University Press.

Michael J. Behe. 1996. *Darwin's Black Box: The Biochemical Challenge to Evolution*. Free Press (New York).

Michael J. Behe. 2007. *The Edge of Evolution: The Search for the Limits of Darwinism*. Free Press (New York).

Bekoff, M., and J. A. Byers, eds. 1998. *Animal Play: Evolutionary, Comparative, and Ecological Perspectives*. Cambridge: Cambridge University Press.

Marc Bekoff. 2007. *The Emotional Lives of Animals: A Leading Scientist Explores Animal Joy, Sorrow, and Empathy—and Why They Matter*. New World Library (Novato, CA).

Bell, J. S. 1964. “On the Einstein Podolsky Rosen Paradox.” *Physics* 1 (3): 195–200.

Bell, John S. 1976. “How to Teach Special Relativity.” Speakable and Unspeakable in Quantum Mechanics (Cambridge University Press, 1987); orig. Progress in Scientific Culture 1 (1976).

Bell, E. A., P. Boehnke, T. M. Harrison, and W. L. Mao. 2015. “Potentially Biogenic Carbon Preserved in a 4.1 Billion-Year-Old Zircon.” *Proceedings of the National Academy of Sciences* 112 (47): 14518–14521.

Benacerraf, Paul. 1965. “What Numbers Could Not Be.” *The Philosophical Review*.

Benacerraf, Paul. 1973. “Mathematical Truth.” *The Journal of Philosophy*.

Shane W. Bench; Heather C. Lench. 2013. “On the Function of Boredom.” *Behavioral Sciences* 3 (3): 459–472.

Jeremy Bentham. 1789. *An Introduction to the Principles of Morals and Legislation*. London: T. Payne and Son.

Émile Benveniste. 1969. *Le vocabulaire des institutions indo-européennes*. Éditions de Minuit.

Michael Bergmann. 2001. “Skeptical Theism and Rowe's New Evidential Argument from Evil.” *Noûs* 35, no. 2 (2001): 278–296.

Michael Bergmann and Jeffrey E. Brower. 2006. “A Theistic Argument against Platonism (and in Support of Truthmakers and Divine Simplicity).” In D. Zimmerman (ed.), Oxford Studies in Metaphysics, vol. 2: 357–386. Oxford University Press.

Michael Bergmann. 2012. “Commonsense Skeptical Theism.” in Reason, Metaphysics, and Mind: New Essays on the Philosophy of Alvin Plantinga, eds. Clark and Rea (Oxford University Press): 9–30.

Bergson, Henri. 1907. *Creative Evolution (L'Évolution créatrice)*. Félix Alcan (Paris).

George Berkeley. 1710. *A Treatise Concerning the Principles of Human Knowledge*. Dublin: Aaron Rhames, for Jeremy Pepyat (1710).

George Berkeley. 1713. *Three Dialogues between Hylas and Philonous*. London: Printed by G. James for Henry Clements (1713).

Berlin, Isaiah. 1958. *Two Concepts of Liberty*. Oxford: Clarendon Press.

Daniel E. Berlyne. 1960. *Conflict, Arousal, and Curiosity*. McGraw-Hill.

Bernard La Scola, Christelle Desnues, ... Didier Raoult. 2008. “The Virophage as a Unique Parasite of the Giant Mimivirus.” *Nature* 455(7209):100–104.

Kent C. Berridge; Terry E. Robinson. 1998. “What Is the Role of Dopamine in Reward: Hedonic Impact, Reward Learning, or Incentive Salience?” *Brain Research Reviews* 28(3): 309–369.

Kent C. Berridge. 2007. “The Debate over Dopamine's Role in Reward: The Case for Incentive Salience.” *Psychopharmacology* 191(3): 391–431.

Berto, Francesco; Jago, Mark. 2019. *Impossible Worlds*. Oxford University Press.

Bird, Alexander. 2007. *Nature's Metaphysics: Laws and Properties*. Oxford University Press.

Christopher D. Bird; Nathan J. Emery. 2009. “Insightful Problem Solving and Creative Tool Modification by Captive Nontool-Using Rooks.” *PNAS* 106(25): 10370–10375.

Alexander Bird. 2010. “Social Knowing: The Social Sense of 'Scientific Knowledge'.” *Philosophical Perspectives* 24(1): 23–56.

Black, Max. 1952. “The Identity of Indiscernibles.” *Mind*.

Block, Ned. 1998. “Conceptual Role Semantics.” Routledge Encyclopedia of Philosophy (online edn 1998).

Hans Boersma. 2004. *Violence, Hospitality, and the Cross: Reappropriating the Atonement Tradition*. Baker Academic.

Boethius. (524) 1969. *The Consolation of Philosophy*. Translated by V. E. Watts. London: Penguin.

Boghossian, Paul. 1998. “What the Externalist Can Know A Priori.” *Philosophical Issues* 9 (Concepts): 197-211.

Martin Bojowald. 2010. *Once Before Time: A Whole Story of the Universe*. New York: Alfred A. Knopf.

Ludwig Boltzmann. 1877. “Über die Beziehung zwischen dem zweiten Hauptsatze der mechanischen Wärmetheorie und der Wahrscheinlichkeitsrechnung.” *Sitzungsberichte der Kaiserlichen Akademie der Wissenschaften (Wien)* 76:373–435.

George A. Bonanno. 2009. *The Other Side of Sadness: What the New Science of Bereavement Tells Us About Life After Loss*. Basic Books.

Bonner, J. T. 1998. “The Origins of Multicellularity.” *Integrative Biology* 1 (1): 27–36.

Boraas, M. E., D. B. Seale, and J. E. Boxhorn. 1998. “Phagotrophy by a Flagellate Selects for Colonial Prey: A Possible Origin of Multicellularity.” *Evolutionary Ecology* 12 (2): 153–164.

Borghini, Andrea; Williams, Neil E. 2008. “A Dispositional Theory of Possibility.” *Dialectica* 62 (1): 21-41.

Nick Bostrom. 2002. *Anthropic Bias: Observation Selection Effects in Science and Philosophy*. Routledge (New York).

Nick Bostrom. 2003. “Are You Living in a Computer Simulation?” *The Philosophical Quarterly* 53(211): 243–255.

Boyd, Richard. 1991. “Realism, Anti-Foundationalism and the Enthusiasm for Natural Kinds.” *Philosophical Studies* 61 (1/2): 127–148.

Gregory A. Boyd. 2001. *Satan and the Problem of Evil: Constructing a Trinitarian Warfare Theodicy*. InterVarsity Press (IVP Academic).

Boyer, P. 2001. *Religion Explained: The Evolutionary Origins of Religious Thought*. New York: Basic Books.

Joseph A. Bracken. 1985. *The Triune Symbol: Persons, Process and Community*. University Press of America (Lanham, MD).

Joseph A. Bracken. 1991. *Society and Spirit: A Trinitarian Cosmology*. Susquehanna University Press / Associated University Presses (Cranbury, NJ).

David Bradshaw. 2004. *Aristotle East and West: Metaphysics and the Division of Christendom*. Cambridge University Press.

Brandenberger, R., and P. Peter. 2017. “Bouncing Cosmologies: Progress and Problems.” *Foundations of Physics* 47 (6): 797–850.

Michael E. Bratman. 2007. *Structures of Agency: Essays*. Oxford University Press (New York).

Brentano, Franz. 1874. *Psychology from an Empirical Standpoint*. Duncker & Humblot.

Percy Williams Bridgman. 1922. *Dimensional Analysis*. New Haven: Yale University Press.

Broad, C. D. 1938. *An Examination of McTaggart's Philosophy*. Cambridge University Press.

Brouwer, L. E. J. 1907. “Over de grondslagen der wiskunde (On the Foundations of Mathematics).” Doctoral dissertation, University of Amsterdam.

Brower, Jeffrey E., and Michael C. Rea. 2005. “Material Constitution and the Trinity.” *Faith and Philosophy* 22 (1): 57–76.

Brower, Jeffrey E. 2009. “Simplicity and Aseity.” In The Oxford Handbook of Philosophical Theology, edited by Thomas P. Flint and Michael C. Rea, 105–128. Oxford: Oxford University Press.

Culum Brown. 2015. “Fish Intelligence, Sentience and Ethics.” *Animal Cognition* 18 (1): 1–17.

Buckareff, Andrei A., and Yujin Nagasawa, eds. 2016. *Alternative Concepts of God: Essays on the Metaphysics of the Divine*. Oxford University Press.

Edgar Buckingham. 1914. “On Physically Similar Systems; Illustrations of the Use of Dimensional Equations.” *Physical Review* 4(4):345–376.

Burgess, John P. 1997. “Quinus ab Omni Naevo Vindicatus.” *Canadian Journal of Philosophy, Supplementary Volume* 23.

Gordon M. Burghardt. 2005. *The Genesis of Animal Play: Testing the Limits*. MIT Press.

Burrell, David B. 1979. *Aquinas: God and Action*. Routledge & Kegan Paul (London).

David B. Burrell. 1986. *Knowing the Unknowable God: Ibn-Sina, Maimonides, Aquinas*. Notre Dame: University of Notre Dame Press.

Byrne, R. W., and A. Whiten, eds. 1988. *Machiavellian Intelligence: Social Expertise and the Evolution of Intellect in Monkeys, Apes, and Humans*. Oxford: Clarendon Press.

Craig Callender (ed.). 2011. *The Oxford Handbook of Philosophy of Time*. Oxford University Press.

John Calvin. (1559) 1960. *Institutes of the Christian Religion*. Ed. John T. McNeill, trans. Ford Lewis Battles. Louisville: Westminster John Knox Press, 1960.

Paco Calvo. 2016. “The Philosophy of Plant Neurobiology: A Manifesto.” *Synthese* 193(5): 1323–1343.

Cameron, Ross P. 2010. “On the Source of Necessity.” in Bob Hale & Aviv Hoffmann (eds.), Modality: Metaphysics, Logic, and Epistemology (Oxford University Press), pp. 137–152.

Keith Campbell. 1990. *Abstract Particulars*. Basil Blackwell (Oxford).

Anselm of Canterbury. (1078) 1998. “Proslogion.” In The Major Works, edited by B. Davies and G. Evans. Oxford: Oxford University Press.

Anselm of Canterbury. (1098) 1998. *Cur Deus Homo (Why God Became Man)*. in Anselm of Canterbury: The Major Works, eds. Brian Davies & G. R. Evans, trans. Janet Fairweather; Oxford: Oxford University Press, 1998.

Tian Yu Cao. 1997. *Conceptual Developments of 20th Century Field Theories*. Cambridge University Press.

Carnap, Rudolf. 1928. *Der logische Aufbau der Welt (The Logical Structure of the World)*. Berlin: Weltkreis-Verlag.

Carnap, Rudolf. 1932. “Überwindung der Metaphysik durch logische Analyse der Sprache (The Elimination of Metaphysics Through Logical Analysis of Language).” *Erkenntnis* 2.

Carnap, Rudolf. 1934. *The Unity of Science*. London: Kegan Paul (trans. M. Black).

Carnap, Rudolf. 1937. *The Logical Syntax of Language*. London: Kegan Paul (trans. A. Smeaton).

Carnap, Rudolf. 1950. “Empiricism, Semantics, and Ontology.” *Revue Internationale de Philosophie* 4 (11): 20–40.

Sean M. Carroll and Jennifer Chen. 2004. “Spontaneous Inflation and the Origin of the Arrow of Time.” arXiv preprint hep-th/0410270.

Sean M. Carroll. 2004. *Spacetime and Geometry: An Introduction to General Relativity*. San Francisco: Addison-Wesley.

Sean Carroll. 2010. *From Eternity to Here: The Quest for the Ultimate Theory of Time*. Dutton (New York).

Sean M. Carroll. 2012. “Does the Universe Need God?” In The Blackwell Companion to Science and Christianity, ed. J. B. Stump and Alan G. Padgett (Wiley-Blackwell), pp. 185–197.

Sean Carroll. 2016. *The Big Picture: On the Origins of Life, Meaning, and the Universe Itself*. Dutton (New York).

Sean M. Carroll. 2017. “Why Boltzmann Brains Are Bad.” In S. Dasgupta, B. Weslake, and R. Dotan (eds.), Current Controversies in Philosophy of Science (Routledge); arXiv:1702.00850.

Brandon Carter. 1974. “Large Number Coincidences and the Anthropic Principle in Cosmology.” in M. S. Longair (ed.), Confrontation of Cosmological Theories with Observational Data (IAU Symposium No. 63), D. Reidel (Dordrecht/Boston), pp. 291–298.

Carter, B. 1983. “The Anthropic Principle and Its Implications for Biological Evolution.” *Philosophical Transactions of the Royal Society of London A* 310 (1512): 347–363.

Cartwright, Nancy. 1983. *How the Laws of Physics Lie*. Oxford University Press.

Cartwright, Nancy. 1999. *The Dappled World: A Study of the Boundaries of Science*. Cambridge University Press.

Cavell, Stanley. 1979. *The Claim of Reason: Wittgenstein, Skepticism, Morality, and Tragedy*. Clarendon Press (Oxford) / Oxford University Press (New York).

Cech, T. R., A. J. Zaug, and P. J. Grabowski. 1981. “In Vitro Splicing of the Ribosomal RNA Precursor of Tetrahymena: Involvement of a Guanosine Nucleotide in the Excision of the Intervening Sequence.” *Cell* 27 (3): 487–496.

Chaisson, E. J. 2001. *Cosmic Evolution: The Rise of Complexity in Nature*. Cambridge, MA: Harvard University Press.

Chalmers, David J. 1996. *The Conscious Mind: In Search of a Fundamental Theory*. Oxford University Press.

Chalmers, David J., and Frank Jackson. 2001. “Conceptual Analysis and Reductive Explanation.” *The Philosophical Review* 110 (3): 315–360.

Chalmers, David J. 2002. “Does Conceivability Entail Possibility?” in Conceivability and Possibility (eds. Gendler & Hawthorne), Oxford University Press.

Chalmers, David J. 2009. “Ontological Anti-Realism.” in Chalmers, Manley & Wasserman (eds.), Metametaphysics: New Essays on the Foundations of Ontology (Oxford University Press), pp. 77–129.

Chalmers, David J. 2010. *The Character of Consciousness*. Oxford University Press.

Chalmers, David J. 2012. *Constructing the World*. Oxford University Press.

David J. Chalmers. 2018. “The Meta-Problem of Consciousness.” *Journal of Consciousness Studies* 25(9–10): 6–61.

David J. Chalmers. 2022. *Reality+: Virtual Worlds and the Problems of Philosophy*. W. W. Norton & Company.

Pierre Chantraine. 1968. *Dictionnaire étymologique de la langue grecque: Histoire des mots*. Klincksieck.

Eric L. Charnov. 1976. “Optimal Foraging, the Marginal Value Theorem.” *Theoretical Population Biology* 9(2): 129–136.

Lars Chittka. 2022. *The Mind of a Bee*. Princeton University Press.

David Christian. 2004. *Maps of Time: An Introduction to Big History*. Berkeley: University of California Press.

Christopher Krupenye, Fumihiro Kano, Satoshi Hirata, Josep Call, and Michael Tomasello. 2016. “Great apes anticipate that other individuals will act according to false beliefs.” *Science* 354(6308): 110–114.

Paul M. Churchland. 1986. “Some Reductive Strategies in Cognitive Neurobiology.” *Mind* 95(379): 279–309.

Clark, A. 2013. “Whatever Next? Predictive Brains, Situated Agents, and the Future of Cognitive Science.” *Behavioral and Brain Sciences* 36 (3): 181–204.

Andy Clark. 2016. *Surfing Uncertainty: Prediction, Action, and the Embodied Mind*. Oxford University Press (New York).

Clark H. Pinnock, Richard Rice, John Sanders, William Hasker and David Basinger. 1994. *The Openness of God: A Biblical Challenge to the Traditional Understanding of God*. Downers Grove, IL: InterVarsity Press.

Rudolf Clausius. 1865. “Ueber verschiedene für die Anwendung bequeme Formen der Hauptgleichungen der mechanischen Wärmetheorie.” *Annalen der Physik* 125:353–400.

Philip Clayton. 1997. *God and Contemporary Science*. Edinburgh University Press / Eerdmans (Grand Rapids).

Nicola S. Clayton and Anthony Dickinson. 1998. “Episodic-like memory during cache recovery by scrub jays.” *Nature* 395(6699): 272–274.

Clayton, Philip, and Arthur Peacocke, eds. 2004. *In Whom We Live and Move and Have Our Being: Panentheistic Reflections on God's Presence in a Scientific World*. Eerdmans.

Carol E. Cleland. 2012. “Life Without Definitions.” *Synthese* 185(1):125–144.

Carol E. Cleland. 2019. *The Quest for a Universal Theory of Life: Searching for Life as We Don't Know It*. Cambridge: Cambridge University Press.

James Van Cleve. 1985. “Three Versions of the Bundle Theory.” *Philosophical Studies* 47(1):95–107.

Eric H. Cline. 2014. *1177 B.C.: The Year Civilization Collapsed*. Princeton University Press (Turning Points in Ancient History).

Sam Coleman. 2014. “The Real Combination Problem: Panpsychism, Micro-Subjects, and Emergence.” *Erkenntnis* 79, no. 1: 19–44.

Collins, C. John. 2006. *Genesis 1–4: A Linguistic, Literary, and Theological Commentary*. Phillipsburg, NJ: P&R Publishing.

Robin Collins. 2009. “The Teleological Argument: An Exploration of the Fine-Tuning of the Universe.” in W. L. Craig & J. P. Moreland (eds.), The Blackwell Companion to Natural Theology (Wiley-Blackwell), pp. 202–281.

Conant, James. 2002. “The Method of the Tractatus.” in E. H. Reck (ed.), From Frege to Wittgenstein: Perspectives on Early Analytic Philosophy (Oxford University Press), pp. 374–462.

Cooper, John W. 2006. *Panentheism—The Other God of the Philosophers: From Plato to the Present*. Baker Academic.

Paul M. M. Cooper. 2019–. “Fall of Civilizations.” Fall of Civilizations Podcast (audio/video series).

Paul Copan. 2011. *Is God a Moral Monster? Making Sense of the Old Testament God*. Baker Books.

Paul Copan and Matthew Flannagan. 2014. *Did God Really Command Genocide? Coming to Terms with the Justice of God*. Baker Books.

Correia, Fabrice; Skiles, Alexander. 2019. “Grounding, Essence, and Identity.” *Philosophy and Phenomenological Research*.

Jesse Couenhoven. 2013. *Stricken by Sin, Cured by Christ: Agency, Necessity, and Culpability in Augustinian Theology*. Oxford University Press.

William Lane Craig. 1979. *The Kalām Cosmological Argument*. Macmillan (London) / Library of Philosophy and Religion.

Craig, William Lane. 1987. *The Only Wise God: The Compatibility of Divine Foreknowledge and Human Freedom*. Baker Book House.

William Lane Craig. 1991. *Divine Foreknowledge and Human Freedom: The Coherence of Theism: Omniscience*. E. J. Brill (Brill's Studies in Intellectual History 19).

William Lane Craig and J. P. Moreland (eds.). 2000. *Naturalism: A Critical Analysis*. Routledge (London & New York), Routledge Studies in Twentieth Century Philosophy.

Craig, William Lane. 2000. *The Tensed Theory of Time: A Critical Examination*. Kluwer Academic (Synthese Library, vol. 293), Dordrecht.

Craig, William Lane. 2001. *Time and the Metaphysics of Relativity*. Kluwer Academic Publishers.

Craig, William Lane. 2001. *Time and Eternity: Exploring God's Relationship to Time*. Crossway.

William Lane Craig. 2001. *God, Time, and Eternity: The Coherence of Theism II: Eternity*. Kluwer Academic Publishers.

Craig, William Lane. 2008. *Reasonable Faith: Christian Truth and Apologetics*. Wheaton: Crossway.

William Lane Craig and James D. Sinclair. 2009. “The Kalam Cosmological Argument.” in W. L. Craig & J. P. Moreland (eds.), The Blackwell Companion to Natural Theology (Wiley-Blackwell), pp. 101–201.

William Lane Craig. 2016. *God Over All: Divine Aseity and the Challenge of Platonism*. Oxford University Press.

Richard E. Creel. 1986. *Divine Impassibility: An Essay in Philosophical Theology*. Cambridge University Press.

Francis H. C. Crick. 1968. “The Origin of the Genetic Code.” *Journal of Molecular Biology* 38(3):367–379.

Roger Crisp. 2006. *Reasons and the Good*. Oxford University Press.

Oliver D. Crisp. 2007. *Divinity and Humanity: The Incarnation Reconsidered*. Cambridge: Cambridge University Press.

Oliver D. Crisp. 2020. *Approaching the Atonement: The Reconciling Work of Christ*. Downers Grove, IL: IVP Academic, 2020.

Carlos Crivelli; Sergio Jarillo; James A. Russell; José-Miguel Fernández-Dols. 2016. “Reading Emotions from Faces in Two Indigenous Societies.” *Journal of Experimental Psychology: General* 145 (7): 830–843.

Crooks, G. E. 1999. “Entropy Production Fluctuation Theorem and the Nonequilibrium Work Relation for Free Energy Differences.” *Physical Review E* 60 (3): 2721–2726.

Richard Cross. 2002. “Two Models of the Trinity?” *The Heythrop Journal* 43, no. 3: 275–294.

Richard Cross. 2005. *Duns Scotus on God*. Aldershot: Ashgate (Ashgate Studies in the History of Philosophical Theology).

Edwin M. Curley. 1984. “Descartes on the Creation of the Eternal Truths.” *The Philosophical Review* 93 (4): 569–597.

Dainton, Barry. 2010. *Time and Space*. Acumen (Durham) / McGill-Queen's University Press, 2nd ed.

Damasio, Antonio R. 1994. *Descartes' Error: Emotion, Reason, and the Human Brain*. New York: G. P. Putnam's Sons.

Antonio R. Damasio. 1996. “The Somatic Marker Hypothesis and the Possible Functions of the Prefrontal Cortex.” *Philosophical Transactions of the Royal Society B* 351 (1346): 1413–1420.

Antonio R. Damasio. 1999. *The Feeling of What Happens: Body and Emotion in the Making of Consciousness*. Harcourt Brace (New York).

Antonio R. Damasio. 2010. *Self Comes to Mind: Constructing the Conscious Brain*. Pantheon (New York).

Damer, B., and D. Deamer. 2020. “The Hot Spring Hypothesis for an Origin of Life.” *Astrobiology* 20 (4): 429–452.

James Danckert; John D. Eastwood. 2020. *Out of My Skull: The Psychology of Boredom*. Harvard University Press.

Daniel An, Krzysztof A. Meissner, Paweł Nurowski, Roger Penrose. 2018. “Apparent Evidence for Hawking Points in the CMB Sky.” arXiv:1808.01740 \[later published in Monthly Notices of the Royal Astronomical Society 495(3):3403–3430, 2020].

Daniel An, Krzysztof A. Meissner, Paweł Nurowski, Roger Penrose. 2020. “Apparent Evidence for Hawking Points in the CMB Sky.” *Monthly Notices of the Royal Astronomical Society* 495(3):3403–3430.

Dasgupta, Shamik. 2009. “Individuals: An Essay in Revisionary Metaphysics.” *Philosophical Studies*.

Shamik Dasgupta. 2014. “On the Plurality of Grounds.” *Philosophers' Imprint* 14 (20): 1–28.

Shamik Dasgupta. 2015. “Substantivalism vs Relationalism About Space in Classical Physics.” *Philosophy Compass* 10(9):601–624.

David Dunning, Kerri Johnson, Joyce Ehrlinger, and Justin Kruger. 2003. “Why people fail to recognize their own incompetence.” *Current Directions in Psychological Science* 12(3): 83–87.

Herbert A. Davidson. 1987. *Proofs for Eternity, Creation and the Existence of God in Medieval Islamic and Jewish Philosophy*. Oxford University Press (New York).

Davidson, Donald. 1987. “Knowing One's Own Mind.” *Proceedings and Addresses of the American Philosophical Association* 60 (3): 441–458.

Davies, Oliver, and Denys Turner (eds.). 2008. *Silence and the Word: Negative Theology and Incarnation*. Cambridge: Cambridge University Press.

Paul C. W. Davies. 2011. “Searching for a Shadow Biosphere on Earth as a Test of the 'Cosmic Imperative'.” *Philosophical Transactions of the Royal Society A* 369(1936):624–632.

Davis, Stephen T. 1993. *Risen Indeed: Making Sense of the Resurrection*. Grand Rapids, MI: Eerdmans.

Scott A. Davison. 2017. *Petitionary Prayer: A Philosophical Investigation*. Oxford: Oxford University Press.

Richard Dawkins. 2006. *The God Delusion*. Bantam Press (London).

Terrence W. Deacon. 2012. *Incomplete Nature: How Mind Emerged from Matter*. New York: W. W. Norton.

Della Rocca, Michael. 2010. “PSR.” *Philosophers' Imprint* 10 (7).

Della Rocca, Michael. 2020. *The Parmenidean Ascent*. Oxford University Press.

William A. Dembski. 1998. *The Design Inference: Eliminating Chance Through Small Probabilities*. Cambridge University Press (Cambridge Studies in Probability, Induction and Decision Theory).

William A. Dembski. 2002. *No Free Lunch: Why Specified Complexity Cannot Be Purchased Without Intelligence*. Rowman & Littlefield (Lanham, MD).

Dennett, Daniel C. 1984. *Elbow Room: The Varieties of Free Will Worth Wanting*. Cambridge, MA: MIT Press.

Daniel C. Dennett. 1991. *Consciousness Explained*. Little, Brown and Company (Boston).

Daniel C. Dennett. 2016. “Illusionism as the Obvious Default Theory of Consciousness.” *Journal of Consciousness Studies* 23 (11–12): 65–72.

Daniel C. Dennett. 2018. “Facing Up to the Hard Question of Consciousness.” *Philosophical Transactions of the Royal Society B* 373 (1755): 20170342.

DeRose, Keith. 1995. “Solving the Skeptical Problem.” *The Philosophical Review*.

Descartes, R. (1641) 1996. *Meditations on First Philosophy*. Translated by J. Cottingham. Cambridge: Cambridge University Press.

René Descartes. 1630. “Letters to Mersenne (April–May 1630).” Letters to Mersenne, 15 April / 6 May / 27 May 1630 (AT I; trans. CSMK III).

Descartes, René. 1644. “Letters to Mesland (on the creation of the eternal truths).” In The Philosophical Writings of Descartes, vol. 3 (Correspondence).

Eliot Deutsch. 1969. *Advaita Vedānta: A Philosophical Reconstruction*. University of Hawaii Press.

Deutsch, D. 1997. *The Fabric of Reality*. New York: Viking.

Diamond, Cora. 1991. *The Realistic Spirit: Wittgenstein, Philosophy, and the Mind*. MIT Press (Cambridge, MA), Bradford Books / Representation and Mind series.

Jared Diamond. 2005. *Collapse: How Societies Choose to Fail or Succeed*. Viking (Penguin Group), New York.

Diósi, L. 1989. “Models for Universal Reduction of Macroscopic Quantum Fluctuations.” *Physical Review A* 40 (3): 1165–1174.

Dolezal, James E. 2011. *God Without Parts: Divine Simplicity and the Metaphysics of God's Absoluteness*. Eugene, OR: Pickwick Publications.

Dolezal, James E. 2017. *All That Is in God: Evangelical Theology and the Challenge of Classical Christian Theism*. Reformation Heritage Books (Grand Rapids).

Donaldson-Matasci, M. C., C. T. Bergstrom, and M. Lachmann. 2010. “The Fitness Value of Information.” *Oikos* 119 (2): 219–230.

W. Ford Doolittle. 1999. “Phylogenetic Classification and the Universal Tree.” *Science* 284(5423):2124–2129.

Dowe, Phil. 2000. *Physical Causation*. Cambridge: Cambridge University Press.

Draper, Paul. 1989. “Pain and Pleasure: An Evidential Problem for Theists.” *Noûs* 23(3).

Dretske, F. I. 1970. “Epistemic Operators.” *Journal of Philosophy*.

Dretske, F. I. 1977. “Laws of Nature.” *Philosophy of Science* 44 (2): 248–268.

Dretske, Fred. 1995. *Naturalizing the Mind*. MIT Press.

Hans Driesch. 1908. *The Science and Philosophy of the Organism*. London: Adam and Charles Black.

Dummett, Michael. 1960. “A Defence of McTaggart's Proof of the Unreality of Time.” *The Philosophical Review* 69 (4): 497–504.

Barnaby D. Dunn; Tim Dalgleish; Andrew D. Lawrence. 2006. “The Somatic Marker Hypothesis: A Critical Evaluation.” *Neuroscience and Biobehavioral Reviews* 30 (2): 239–271.

Duns Scotus, John. (c. 1300) 1987. *Philosophical Writings*. Edited and translated by Allan Wolter. Indianapolis: Hackett.

Dupré, John. 1993. *The Disorder of Things: Metaphysical Foundations of the Disunity of Science*. Harvard University Press (Cambridge, MA).

Douglas S. Earl. 2010. *The Joshua Delusion? Rethinking Genocide in the Bible*. Cascade Books.

John Earman and John Norton. 1987. “What Price Spacetime Substantivalism? The Hole Story.” *The British Journal for the Philosophy of Science* 38(4):515–525.

John Earman. 1989. *World Enough and Space-Time: Absolute versus Relational Theories of Space and Time*. MIT Press.

John Earman. 2003. “Rough Guide to Spontaneous Symmetry Breaking.” In K. Brading and E. Castellani (eds.), Symmetries in Physics: Philosophical Reflections (Cambridge University Press), pp. 335–346.

John Earman. 2006. “The 'Past Hypothesis': Not Even False.” *Studies in History and Philosophy of Modern Physics* 37(3):399–430.

John D. Eastwood; Alexandra Frischen; Mark J. Fenske; Daniel Smilek. 2012. “The Unengaged Mind: Defining Boredom in Terms of Attention.” *Perspectives on Psychological Science* 7 (5): 482–495.

Jonathan Edwards. (1765) 1989. “A Dissertation Concerning the End for Which God Created the World.” In Ethical Writings (The Works of Jonathan Edwards, vol. 8), ed. Paul Ramsey. New Haven: Yale University Press.

Jonathan Edwards. 1758. *The Great Christian Doctrine of Original Sin Defended*. Boston: S. Kneeland (1st ed., 1758); critical ed. The Works of Jonathan Edwards, Vol. 3, ed. Clyde A. Holbrook, Yale University Press, 1970.

Paul Edwards. 1959. “The Cosmological Argument.” *The Rationalist Annual for the Year* 1959 (London: Pemberton), pp. 63–77.

Efird, David; Stoneham, Tom. 2005. “The Subtraction Argument for Metaphysical Nihilism.” *The Journal of Philosophy*.

Ehrman, Bart D. 2005. *Misquoting Jesus: The Story Behind Who Changed the Bible and Why*. San Francisco: HarperSanFrancisco.

Ehrman, Bart D. 2009. *Jesus, Interrupted: Revealing the Hidden Contradictions in the Bible (and Why We Don't Know About Them)*. New York: HarperOne.

Eigen, M. 1971. “Selforganization of Matter and the Evolution of Biological Macromolecules.” *Naturwissenschaften* 58 (10): 465–523.

Einstein, A. 1905. “Zur Elektrodynamik bewegter Körper.” *Annalen der Physik* 17 (10): 891–921.

Einstein, A. 1915. “Die Feldgleichungen der Gravitation.” *Sitzungsberichte der Preussischen Akademie der Wissenschaften,* 844–847.

Eklund, Matti. 2008. “The Picture of Reality as an Amorphous Lump.” In Theodore Sider, John Hawthorne and Dean W. Zimmerman (eds.), Contemporary Debates in Metaphysics, Malden, MA: Blackwell, 2008: 382–396.

Paul Ekman. 1972. “Universals and Cultural Differences in Facial Expressions of Emotion.” In Nebraska Symposium on Motivation 1971, ed. J. Cole, 19: 207–283. University of Nebraska Press.

Paul Ekman. 1992. “An Argument for Basic Emotions.” *Cognition and Emotion* 6 (3–4): 169–200.

England, J. L. 2013. “Statistical Physics of Self-Replication.” *The Journal of Chemical Physics* 139 (12): 121923.

Erich Joos, H. Dieter Zeh, Claus Kiefer, Domenico Giulini, Joachim Kupsch, and Ion-Olimpiu Stamatescu. 2003. *Decoherence and the Appearance of a Classical World in Quantum Theory*. Springer (2nd ed.).

Eva Jablonka, Marion J. Lamb. 2005. *Evolution in Four Dimensions: Genetic, Epigenetic, Behavioral, and Symbolic Variation in the History of Life*. Cambridge, MA: MIT Press.

C. Stephen Evans. 2013. *God and Moral Obligation*. Oxford University Press.

Everitt, Nicholas. 2004. *The Non-Existence of God*. Routledge (London & New York).

Roland Faber. 2008. *God as Poet of the World: Exploring Process Theologies*. Westminster John Knox Press (Louisville).

Michael Faraday. 1839–1855. *Experimental Researches in Electricity*. London: Richard and John Edward Taylor (3 vols.).

John S. Feinberg. 2001. *No One Like Him: The Doctrine of God*. Wheaton, IL: Crossway (Foundations of Evangelical Theology).

Feser, Edward. 2009. *Aquinas: A Beginner's Guide*. Oxford: Oneworld.

Feser, Edward. 2017. *Five Proofs of the Existence of God*. Ignatius Press.

Fiddes, Paul S. 1988. *The Creative Suffering of God*. Clarendon Press.

Fine, Kit. 1994. “Essence and Modality.” *Philosophical Perspectives*.

Fine, Kit. 1995. “Senses of Essence.” in Modality, Morality, and Belief (Cambridge University Press).

Fine, Kit. 2012. “Guide to Ground.” In Metaphysical Grounding: Understanding the Structure of Reality, edited by Fabrice Correia and Benjamin Schnieder, 37–80. Cambridge: Cambridge University Press.

Fischer, John Martin, and Mark Ravizza. 1998. *Responsibility and Control: A Theory of Moral Responsibility*. Cambridge: Cambridge University Press.

Thomas P. Flint and Alfred J. Freddoso. 1983. “Maximal Power.” In The Existence and Nature of God, ed. Alfred J. Freddoso, 81–113. Notre Dame: University of Notre Dame Press.

Flint, Thomas P. 1998. *Divine Providence: The Molinist Account*. Cornell University Press.

Fodor, Jerry A. 1974. “Special Sciences (or: The Disunity of Science as a Working Hypothesis).” *Synthese* 28 (2).

Føllesdal, Dagfinn. 1986. “Essentialism and Reference.” in The Philosophy of W. V. Quine (Library of Living Philosophers, Open Court).

Forbes, Graeme. 1993. “Time, Events, and Modality.” In Robin Le Poidevin and Murray MacBeath (eds.), The Philosophy of Time (Oxford Readings in Philosophy). Oxford: Oxford University Press.

Robert K. C. Forman (ed.). 1990. *The Problem of Pure Consciousness: Mysticism and Philosophy*. Oxford University Press.

Forrest, Peter, and D. M. Armstrong. 1984. “An Argument Against David Lewis' Theory of Possible Worlds.” *Australasian Journal of Philosophy* 62 (2): 164–168.

Patrick Forterre. 2010. “Defining Life: The Virus Viewpoint.” *Origins of Life and Evolution of Biospheres* 40(2):151–160.

Richard M. Frank. 1992. *Creation and the Cosmic System: Al-Ghazâlî and Avicenna*. Carl Winter Universitätsverlag (Heidelberg), Abhandlungen der Heidelberger Akademie der Wissenschaften, Phil.-hist. Kl. 1992, Abh. 1.

Harry G. Frankfurt. 1964. “The Logic of Omnipotence.” *The Philosophical Review* 73, no. 2: 262–263.

Harry G. Frankfurt. 1969. “Alternate Possibilities and Moral Responsibility.” *The Journal of Philosophy* 66, no. 23: 829–839.

Frankfurt, Harry G. 1971. “Freedom of the Will and the Concept of a Person.” *Journal of Philosophy* 68 (1): 5–20.

Harry G. Frankfurt. 1977. “Descartes on the Creation of the Eternal Truths.” *The Philosophical Review* 86 (1): 36–57.

Harry G. Frankfurt. 1982. “The Importance of What We Care About.” *Synthese* 53 (2): 257–272.

Harry G. Frankfurt. 1988. *The Importance of What We Care About: Philosophical Essays*. Cambridge University Press (Cambridge).

Keith Frankish. 2016. “Illusionism as a Theory of Consciousness.” *Journal of Consciousness Studies* 23 (11–12): 11–39.

Keith Frankish (ed.). 2017. *Illusionism as a Theory of Consciousness*. Imprint Academic (Exeter).

Alfred J. Freddoso. 1991. “God's General Concurrence with Secondary Causes: Why Conservation Is Not Enough.” *Philosophical Perspectives* 5: 553–585.

Freddoso, Alfred J. 1994. “God's General Concurrence with Secondary Causes: Pitfalls and Prospects.” *American Catholic Philosophical Quarterly* 68 (2): 131–156.

Frege, Gottlob. 1879. *Begriffsschrift, eine der arithmetischen nachgebildete Formelsprache des reinen Denkens*. Halle: Louis Nebert.

Frege, Gottlob. 1884. *Die Grundlagen der Arithmetik*. Verlag von Wilhelm Koebner (Breslau).

Frege, Gottlob. 1893–1903. *Grundgesetze der Arithmetik*. Jena: Hermann Pohle (2 vols.).

Steven French and Décio Krause. 2006. *Identity in Physics: A Historical, Philosophical, and Formal Analysis*. Oxford University Press.

French, Steven. 2014. *The Structure of the World: Metaphysics and Representation*. Oxford University Press.

Sigmund Freud. 1905. *Three Essays on the Theory of Sexuality (Drei Abhandlungen zur Sexualtheorie)*. Leipzig & Vienna: Franz Deuticke.

Sigmund Freud. 1920. *Beyond the Pleasure Principle (Jenseits des Lustprinzips)*. Leipzig: Internationaler Psychoanalytischer Verlag.

Sigmund Freud. 1923. *The Ego and the Id (Das Ich und das Es)*. Leipzig: Internationaler Psychoanalytischer Verlag.

Michael Friedman. 1983. *Foundations of Space-Time Theories: Relativistic Physics and Philosophy of Science*. Princeton University Press.

Friston, Karl J. 2010. “The Free-Energy Principle: A Unified Brain Theory?” *Nature Reviews Neuroscience* 11 (2): 127–138.

Fritz, Peter; Lo, Tien-Chun; Schmid, Joseph C. 2026. “Symmetry Lost: A Modal Ontological Argument for Atheism?” *Noûs* 60 (2026): 313–327.

Tadashi Fukami. 2015. “Historical Contingency in Community Assembly: Integrating Niches, Species Pools, and Priority Effects.” *Annual Review of Ecology, Evolution, and Systematics* 46:1–23.

Peter Furlong. 2019. *The Challenges of Divine Determinism: A Philosophical Analysis*. Cambridge: Cambridge University Press.

Monica Gagliano. 2018. *Thus Spoke the Plant: A Remarkable Journey of Groundbreaking Scientific Discoveries and Personal Encounters with Plants*. North Atlantic Books.

Tibor Gánti. 2003. *The Principles of Life*. Oxford: Oxford University Press.

Jay L. Garfield. 1995. *The Fundamental Wisdom of the Middle Way: Nāgārjuna's Mūlamadhyamakakārikā*. Oxford University Press (New York).

Jay L. Garfield. 2002. *Empty Words: Buddhist Philosophy and Cross-Cultural Interpretation*. Oxford University Press (New York).

Réginald Garrigou-Lagrange. 1936. *La prédestination des saints et la grâce: Doctrine de saint Thomas comparée aux autres systèmes théologiques*. Paris: Desclée de Brouwer.

Gasperini, M., and G. Veneziano. 1993. “Pre-Big-Bang in String Cosmology.” *Astroparticle Physics* 1 (3): 317–339.

Gavrilyuk, Paul L. 2004. *The Suffering of the Impassible God: The Dialectics of Patristic Thought*. Oxford University Press.

P. T. Geach. 1973. “Omnipotence.” *Philosophy* 48, no. 183: 7–20.

Maria Gendron; Debi Roberson; Jacoba M. van der Vyver; Lisa Feldman Barrett. 2014. “Perceptions of Emotion from Facial Expressions Are Not Culturally Universal: Evidence from a Remote Culture.” *Emotion* 14 (2): 251–262.

Gerson, Lloyd P. 1994. *Plotinus*. London: Routledge.

Gibbard, Allan. 1975. “Contingent Identity.” *Journal of Philosophical Logic* 4 (2): 187–221.

Walter Gilbert. 1986. “Origin of Life: The RNA World.” *Nature* 319:618.

Margaret Gilbert. 1989. *On Social Facts*. Routledge (London and New York); reprinted Princeton University Press, 1992.

Gilbert, Daniel T., and Timothy D. Wilson. 2007. “Prospection: Experiencing the Future.” *Science* 317 (5843): 1351–1354.

Ginsburg, S., and E. Jablonka. 2019. *The Evolution of the Sensitive Soul: Learning and the Origins of Consciousness*. Cambridge, MA: MIT Press.

Giustina, M., M. A. M. Versteegh, S. Wengerowsky, J. Handsteiner, A. Hochrainer, K. Phelan, F. Steinlechner, J. Kofler, J.-Å. Larsson, C. Abellán, W. Amaya, V. Pruneri, M. W. Mitchell, J. Beyer, T. Gerrits, A. E. Lita, L. K. Shalm, S. W. Nam, T. Scheidl, R. Ursin, B. Wittmann, and A. Zeilinger. 2015. “Significant-Loophole-Free Test of Bell's Theorem with Entangled Photons.” *Physical Review Letters* 115 (25): 250401.

Glenberg, Arthur M. 1997. “What memory is for.” *Behavioral and Brain Sciences* 20 (1): 1–19.

Nelson Glueck. 1967. *Hesed in the Bible*. Hebrew Union College Press (trans. A. Gottschalk of 1927 German diss.).

Gödel, Kurt. 1944. “Russell's Mathematical Logic.” in P. A. Schilpp (ed.), The Philosophy of Bertrand Russell (Library of Living Philosophers, vol. 5), Northwestern University, pp. 123–153.

Gödel, Kurt. 1947. “What Is Cantor's Continuum Problem?” *The American Mathematical Monthly*.

Gödel, Kurt. 1964. “What Is Cantor's Continuum Problem? (revised).” in P. Benacerraf & H. Putnam (eds.), Philosophy of Mathematics: Selected Readings (Prentice-Hall), pp. 258–273.

Godfrey-Smith, P. 1996. *Complexity and the Function of Mind in Nature*. Cambridge: Cambridge University Press.

Godfrey-Smith, P. 2016. *Other Minds: The Octopus, the Sea, and the Deep Origins of Consciousness*. New York: Farrar, Straus and Giroux.

Philip Goff. 2017. *Consciousness and Fundamental Reality*. Oxford University Press (New York), Philosophy of Mind series.

Philip Goff. 2019. *Galileo's Error: Foundations for a New Science of Consciousness*. Pantheon Books (New York).

Goldblatt, Robert. 1992. *Logics of Time and Computation (2nd ed.)*. Stanford: CSLI Publications.

Alvin I. Goldman. 1967. “A Causal Theory of Knowing.” *The Journal of Philosophy* 64(12): 357–372.

Jane Goodall. 1971. *In the Shadow of Man*. Houghton Mifflin (Boston).

Frank Griffel. 2009. *Al-Ghazālī's Philosophical Theology*. Oxford University Press (New York).

Griffiths, R. B. 2002. *Consistent Quantum Theory*. Cambridge: Cambridge University Press.

Patrick Grim. 1991. *The Incomplete Universe: Totality, Knowledge, and Truth*. MIT Press / Bradford Books (Cambridge, MA).

Grosberg, R. K., and R. R. Strathmann. 2007. “The Evolution of Multicellularity: A Minor Major Transition?” *Annual Review of Ecology, Evolution, and Systematics* 38: 621–654.

Gross, D. J. 1996. “The Role of Symmetry in Fundamental Physics.” *Proceedings of the National Academy of Sciences* 93 (25): 14256–14259.

Adolf Grünbaum. 1989. “The Pseudo-Problem of Creation in Physical Cosmology.” *Philosophy of Science* 56(3):373–394.

Adolf Grünbaum. 1998. “Theological Misinterpretations of Current Physical Cosmology.” *Philo* 1 (1): 15–34.

Guerrier-Takada, C., K. Gardiner, T. Marsh, N. Pace, and S. Altman. 1983. “The RNA Moiety of Ribonuclease P Is the Catalytic Subunit of the Enzyme.” *Cell* 35 (3): 849–857.

Guthrie, S. E. 1993. *Faces in the Clouds: A New Theory of Religion*. New York: Oxford University Press.

Habermas, Jürgen. (1983) 1990. *Moral Consciousness and Communicative Action*. MIT Press.

Habermas, Jürgen. (1992) 1996. *Between Facts and Norms: Contributions to a Discourse Theory of Law and Democracy*. MIT Press.

Habermas, Gary R. 1996. *The Historical Jesus: Ancient Evidence for the Life of Christ*. Joplin, MO: College Press.

Habermas, Gary R. 2003. *The Risen Jesus and Future Hope*. Lanham, MD: Rowman & Littlefield.

Habermas, Gary R.; Licona, Michael R. 2004. *The Case for the Resurrection of Jesus*. Grand Rapids: Kregel.

Hacker, P. M. S. 2001. *Wittgenstein: Connections and Controversies*. Clarendon Press / Oxford University Press (Oxford).

Alan Hájek. 2003. “Waging War on Pascal's Wager.” *The Philosophical Review* 112 (1): 27–56.

Hale, B. 2013. *Necessary Beings: An Essay on Ontology, Modality, and the Relations Between Them*. Oxford: Oxford University Press.

John E. Hare. 1996. *The Moral Gap: Kantian Ethics, Human Limits, and God's Assistance*. Clarendon Press / Oxford University Press (Oxford), Oxford Studies in Theological Ethics.

Harman, Gilbert. 1987. “(Nonsolipsistic) Conceptual Role Semantics.” in E. LePore (ed.), New Directions in Semantics (Academic Press), pp. 55–81.

Harrop, Stephen. 2024. “On the Necessity of Priority Monism.” *Erkenntnis* 89 (2): 685–703.

David Bentley Hart. 2019. *That All Shall Be Saved: Heaven, Hell, and Universal Salvation*. Yale University Press.

James B. Hartle and Stephen W. Hawking. 1983. “Wave Function of the Universe.” *Physical Review D* 28, no. 12, pp. 2960–2975.

Charles Hartshorne. 1941. *Man's Vision of God and the Logic of Theism*. Willett, Clark & Company (Chicago & New York).

Charles Hartshorne. 1948. *The Divine Relativity: A Social Conception of God*. Yale University Press (New Haven).

Charles Hartshorne. 1962. *The Logic of Perfection and Other Essays in Neoclassical Metaphysics*. Open Court (La Salle, IL).

Charles Hartshorne. 1965. *Anselm's Discovery: A Re-Examination of the Ontological Proof for God's Existence*. Open Court (La Salle, IL).

Charles Hartshorne. 1967. *A Natural Theology for Our Time*. Open Court (La Salle, IL).

Charles Hartshorne. 1970. *Creative Synthesis and Philosophic Method*. SCM Press (London) / Open Court (La Salle, IL).

Hartshorne, Charles. 1984. *Omnipotence and Other Theological Mistakes*. State University of New York Press (Albany).

Hasker, William. 1986. “A Refutation of Middle Knowledge.” *Noûs* 20, no. 4: 545–557.

William Hasker. 1989. *God, Time, and Knowledge*. Ithaca, NY: Cornell University Press.

Hasker, William. 2013. *Metaphysics and the Tri-Personal God*. Oxford University Press, Oxford Studies in Analytic Theology.

Hawke, Peter. 2011. “Van Inwagen's Modal Skepticism.” *Philosophical Studies* 153 (3): 351-364.

Hawking, S. W., and G. F. R. Ellis. 1973. *The Large Scale Structure of Space-Time*. Cambridge: Cambridge University Press.

Hawking, S. W. 1976. “Breakdown of Predictability in Gravitational Collapse.” *Physical Review D* 14 (10): 2460–2473.

Hawley, Katherine. 2001. *How Things Persist*. Clarendon Press / Oxford University Press (Oxford).

Hayek, Friedrich A. 1960. *The Constitution of Liberty*. University of Chicago Press.

Hayek, Friedrich A. 1976. *Law, Legislation and Liberty, Volume 2: The Mirage of Social Justice*. London: Routledge & Kegan Paul.

Richard Healey. 2017. *The Quantum Revolution in Philosophy*. Oxford: Oxford University Press.

Anders Nygren (trans. A. G. Hebert). 1932. *Agape and Eros: A Study of the Christian Idea of Love (Part I)*. London: SPCK (orig. Swedish 1930–36).

Hegel, G. W. F. (1807) 1977. *Phenomenology of Spirit*. Translated by A. V. Miller. Oxford: Oxford University Press.

Heidegger, M. (1927) 1962. *Being and Time*. Translated by J. Macquarrie and E. Robinson. New York: Harper & Row.

Heidegger, Martin. 1957. *Identity and Difference (Identität und Differenz)*. Verlag Günther Neske (Pfullingen); Eng. trans. J. Stambaugh, Harper & Row (New York), 1969.

John Heil. 2003. *From an Ontological Point of View*. Clarendon Press / Oxford University Press (Oxford).

S. Mark Heim. 1995. *Salvations: Truth and Difference in Religion*. Orbis Books (Maryknoll, NY).

Bernd Heinrich. 1995. “Neophilia and Exploration in Juvenile Common Ravens, Corvus corax.” *Animal Behaviour* 50(3): 695–704.

Heller, Mark. 1990. *The Ontology of Physical Objects: Four-Dimensional Hunks of Matter*. Cambridge University Press.

Paul Helm. 1988. *Eternal God: A Study of God Without Time*. Clarendon Press / Oxford University Press (Oxford & New York).

Paul Helm. 1993. *The Providence of God*. Leicester: Inter-Varsity Press (Contours of Christian Theology).

Helm, Paul. 2010. *Eternal God: A Study of God Without Time*. Oxford University Press (2nd ed.).

Hermann von Helmholtz. 1847. *Über die Erhaltung der Kraft: eine physikalische Abhandlung*. Berlin: G. Reimer.

Hempel, Carl G. 1969. “Reduction: Ontological and Linguistic Facets.” In S. Morgenbesser, P. Suppes, and M. White (eds.), Philosophy, Science, and Method: Essays in Honor of Ernest Nagel, New York: St. Martin's Press.

Hensen, B., H. Bernien, A. E. Dréau, A. Reiserer, N. Kalb, M. S. Blok, J. Ruitenberg, R. F. L. Vermeulen, R. N. Schouten, C. Abellán, W. Amaya, V. Pruneri, M. W. Mitchell, M. Markham, D. J. Twitchen, D. Elkouss, S. Wehner, T. H. Taminiau, and R. Hanson. 2015. “Loophole-Free Bell Inequality Violation Using Electron Spins Separated by 1.3 Kilometres.” *Nature* 526 (7575): 682–686.

Herron, M. D., J. M. Borin, J. C. Boswell, J. Walker, I.-C. K. Chen, C. A. Knox, M. Boyd, F. Rosenzweig, and W. C. Ratcliff. 2019. “De Novo Origins of Multicellularity in Response to Predation.” *Scientific Reports* 9 (1): 2328.

Herschy, B., A. Whicher, E. Camprubí, C. Watson, L. Dartnell, J. Ward, J. R. G. Evans, and N. Lane. 2014. “An Origin-of-Life Reactor to Simulate Alkaline Hydrothermal Vents.” *Journal of Molecular Evolution* 79 (5–6): 213–227.

Heyting, Arend. 1956. *Intuitionism: An Introduction*. Amsterdam: North-Holland.

John Hick. 1966. *Evil and the God of Love*. London: Macmillan, 1966 (pp. 403; 2nd ed. 1977; reissued Palgrave Macmillan, 2010).

John Hick (ed.). 1977. *The Myth of God Incarnate*. London: SCM Press.

John Hick. 1989. *An Interpretation of Religion: Human Responses to the Transcendent*. Yale University Press (Gifford Lectures).

Hilbert, David. 1899. *Grundlagen der Geometrie (Foundations of Geometry)*. Leipzig: Teubner.

Hintikka, Jaakko. 1962. “Cogito, Ergo Sum: Inference or Performance?” *The Philosophical Review*.

Augustine of Hippo. (397–400) 1991. *Confessions*. Translated by H. Chadwick. Oxford: Oxford University Press.

Augustine of Hippo. (400–428) 1991. *The Trinity*. Translated by Edmund Hill. Brooklyn, NY: New City Press.

Augustine of Hippo. (413–426) 1998. *The City of God against the Pagans*. Edited and translated by R. W. Dyson. Cambridge: Cambridge University Press.

Hirsch, Eli. 2011. *Quantifier Variance and Realism: Essays in Metaontology*. Oxford University Press (New York).

Hirschman, Albert O. 1970. *Exit, Voice, and Loyalty: Responses to Decline in Firms, Organizations, and States*. Harvard University Press.

Hjortland, Ole Thomassen. 2017. “Anti-exceptionalism About Logic.” *Philosophical Studies* 174 (3): 631–658.

Hoffman, Joshua, and Gary S. Rosenkrantz. 2002. *The Divine Attributes*. Blackwell.

Honneth, Axel. 1995. *The Struggle for Recognition: The Moral Grammar of Social Conflicts*. Polity Press / MIT Press.

Gerard 't Hooft. 1993. “Dimensional Reduction in Quantum Gravity.” In A. Ali, J. Ellis, and S. Randjbar-Daemi (eds.), Salamfestschrift, World Scientific Series in 20th Century Physics, vol. 4; arXiv:gr-qc/9310026.

Horning, D. P., and G. F. Joyce. 2016. “Amplification of RNA by an RNA Polymerase Ribozyme.” *Proceedings of the National Academy of Sciences* 113 (35): 9786–9791.

Horwich, Paul. 1987. *Asymmetries in Time: Problems in the Philosophy of Science*. MIT Press / Bradford Books (Cambridge, MA).

George F. Hourani. 1985. *Reason and Tradition in Islamic Ethics*. Cambridge University Press.

Howard-Snyder, Daniel; Moser, Paul K. (eds.). 2002. *Divine Hiddenness: New Essays*. Cambridge: Cambridge University Press.

Daniel Howard-Snyder. 2009. “Epistemic Humility, Arguments from Evil, and Moral Skepticism.” Oxford Studies in Philosophy of Religion 2: 17–57.

Edwin Hubble. 1929. “A Relation between Distance and Radial Velocity among Extra-Galactic Nebulae.” *Proceedings of the National Academy of Sciences* 15(3):168–173.

Hudson, Hud. 2001. *A Materialist Metaphysics of the Human Person*. Cornell University Press (Ithaca, NY).

Hudson, Hud. 2005. *The Metaphysics of Hyperspace*. Oxford University Press.

Hudson, Hud. 2009. “Omnipresence.” In The Oxford Handbook of Philosophical Theology, ed. Thomas P. Flint and Michael C. Rea, 199–216. Oxford University Press.

Hudson, R., R. de Graaf, M. Strandoo Rodin, A. Ohno, N. Lane, S. E. McGlynn, Y. M. A. Yamada, R. Nakamura, L. M. Barge, D. Braun, and V. Sojo. 2020. “CO₂ Reduction Driven by a pH Gradient.” *Proceedings of the National Academy of Sciences* 117 (37): 22873–22879.

Michael Huemer. 2009. “When is Parsimony a Virtue?” *The Philosophical Quarterly* 59 (235): 216–236.

Hughes, Christopher. 1989. *On a Complex Theory of a Simple God: An Investigation in Aquinas' Philosophical Theology*. Ithaca, NY: Cornell University Press.

Humberto R. Maturana, Francisco J. Varela. 1980. *Autopoiesis and Cognition: The Realization of the Living*. Dordrecht: D. Reidel.

Hume, David. (1739–1740) 2000. *A Treatise of Human Nature*. Edited by D. F. Norton and M. J. Norton. Oxford: Oxford University Press.

Hume, David. (1748) 1999. *An Enquiry concerning Human Understanding*. Edited by Tom L. Beauchamp. Oxford: Oxford University Press.

David Hume. 1779. *Dialogues concerning Natural Religion*. London (publisher not named), 1779 (posthumous).

Humphrey, N. K. 1976. “The Social Function of Intellect.” In Growing Points in Ethology, edited by P. P. G. Bateson and R. A. Hinde, 303–317. Cambridge: Cambridge University Press.

Hunsinger, George. 1991. *How to Read Karl Barth: The Shape of His Theology*. New York: Oxford University Press.

Husserl, Edmund. 1900–01. *Logical Investigations*. Halle: M. Niemeyer (2 vols.; Eng. trans. J. N. Findlay, Routledge & Kegan Paul, 1970).

Husserl, Edmund. 1913. *Ideas Pertaining to a Pure Phenomenology (Ideas I)*. Halle: M. Niemeyer (Ideen I; Eng. trans. Boyce Gibson 1931 / Kersten 1983).

Henry L. Roediger III and Kathleen B. McDermott. 1995. “Creating false memories: Remembering words not presented in lists.” *Journal of Experimental Psychology: Learning, Memory, and Cognition* 21(4): 803–814.

Ijjas, A., and P. J. Steinhardt. 2019. “A New Kind of Cyclic Universe.” *Physics Letters B* 795: 666–672.

Michael Ikeda and Bill Jefferys. 2006. “The Anthropic Principle Does Not Support Supernaturalism.” in M. Martin & R. Monnier (eds.), The Improbability of God (Prometheus Books, Amherst, NY), pp. 150–166.

Imachi, H., M. K. Nobu, N. Nakahara, Y. Morono, M. Ogawara, Y. Takaki, Y. Takano, K. Uematsu, T. Ikuta, M. Ito, et al. 2020. “Isolation of an Archaeon at the Prokaryote–Eukaryote Interface.” *Nature* 577 (7791): 519–525.

Inman, Ross D. 2017. “Omnipresence and the Location of the Immaterial.” Oxford Studies in Philosophy of Religion 8: 167–206.

Peter van Inwagen. 1983. *An Essay on Free Will*. Oxford: Clarendon Press.

Frank Jackson. 1982. “Epiphenomenal Qualia.” *The Philosophical Quarterly* 32 (127): 127–136.

Jackson, Frank. 1998. *From Metaphysics to Ethics: A Defence of Conceptual Analysis*. Clarendon Press / Oxford University Press (Oxford).

Jacobs, Jonathan D. 2010. “A Powers Theory of Modality: Or, How I Learned to Stop Worrying and Reject Possible Worlds.” *Philosophical Studies* 151 (2): 227-248.

William James. 1884. “What Is an Emotion?” *Mind os-IX (34):* 188–205.

William James. 1896. “The Will to Believe.” *The New World* 5: 327–347.

James E. Lovelock, Lynn Margulis. 1974. “Atmospheric Homeostasis by and for the Biosphere: The Gaia Hypothesis.” *Tellus* 26(1–2):2–10.

Jarzynski, C. 1997. “Nonequilibrium Equality for Free Energy Differences.” *Physical Review Letters* 78 (14): 2690–2693.

Jenkins, C. S. 2011. “Is Metaphysical Dependence Irreflexive?” *The Monist* 94 (2): 267–276.

Jeff Jordan. 2006. *Pascal's Wager: Pragmatic Arguments and Belief in God*. Clarendon Press / Oxford University Press (Oxford).

James Prescott Joule. 1843–1845. “On the Calorific Effects of Magneto-Electricity, and on the Mechanical Value of Heat.” *The London, Edinburgh, and Dublin Philosophical Magazine (3rd series)* 23:263–276.

Jow, D. L., and D. Scott. 2020. “Re-Evaluating Evidence for Hawking Points in the CMB.” *Journal of Cosmology and Astroparticle Physics* 2020 (3): 021.

Joyce, G. F. 1994. “Foreword.” In Origins of Life: The Central Concepts, edited by D. W. Deamer and G. R. Fleischaker, xi–xii. Boston: Jones and Bartlett.

Joyce, G. F. 2002. “The Antiquity of RNA-Based Evolution.” *Nature* 418 (6894): 214–221.

John B. Cobb Jr. and David Ray Griffin. 1976. *Process Theology: An Introductory Exposition*. Westminster Press (Philadelphia).

Cornelius Plantinga Jr. 1986. “Gregory of Nyssa and the Social Analogy of the Trinity.” *The Thomist* 50, no. 3, pp. 325–352.

Cornelius Plantinga Jr. 1989. “Social Trinity and Tritheism.” In R. J. Feenstra and C. Plantinga Jr. (eds.), Trinity, Incarnation, and Atonement: 21–47. Univ. of Notre Dame Press.

Kahn, Charles H. 1979. *The Art and Thought of Heraclitus*. Cambridge University Press.

Daniel Kahneman. 2011. *Thinking, Fast and Slow*. Farrar, Straus and Giroux (New York).

Robert Kane. 1996. *The Significance of Free Will*. New York: Oxford University Press.

Kant, I. (1781) 1998. *Critique of Pure Reason*. Translated by P. Guyer and A. W. Wood. Cambridge: Cambridge University Press.

Richard Karban. 2015. *Plant Sensing and Communication*. University of Chicago Press.

Karofsky, Amy. 2021. *A Case for Necessitarianism*. Routledge (Routledge Studies in Metaphysics).

Bernardo Kastrup. 2014. *Why Materialism Is Baloney*. Iff Books (Winchester, UK).

Bernardo Kastrup. 2019. *The Idea of the World: A Multi-Disciplinary Argument for the Mental Nature of Reality*. Iff Books (Winchester, UK).

Bernardo Kastrup. 2024. *Analytic Idealism in a Nutshell*. Iff Books (Winchester, UK).

Steven T. Katz. 1978. “Language, Epistemology, and Mysticism.” In Mysticism and Philosophical Analysis, ed. Steven T. Katz (Oxford University Press), pp. 22–74.

Stuart A. Kauffman. 1986. “Autocatalytic Sets of Proteins.” *Journal of Theoretical Biology* 119(1):1–24.

Stuart A. Kauffman. 1993. *The Origins of Order: Self-Organization and Selection in Evolution*. New York: Oxford University Press.

Stuart A. Kauffman. 1995. *At Home in the Universe: The Search for the Laws of Self-Organization and Complexity*. New York: Oxford University Press.

Stuart A. Kauffman. 2008. *Reinventing the Sacred: A New View of Science, Reason, and Religion*. New York: Basic Books.

Kerr, Gaven. 2015. *Aquinas's Way to God: The Proof in De Ente et Essentia*. New York: Oxford University Press.

Brian Key. 2016. “Why Fish Do Not Feel Pain.” *Animal Sentience* 3 (1): 1–34.

Kim, Jaegwon. 1998. *Mind in a Physical World: An Essay on the Mind-Body Problem and Mental Causation*. Cambridge, MA: MIT Press.

Kipping, D. 2020. “An Objective Bayesian Analysis of Life's Early Start and Our Late Arrival.” *Proceedings of the National Academy of Sciences* 117 (22): 11995–12003.

Paul F. Knitter. 2002. *Introducing Theologies of Religions*. Orbis Books (Maryknoll, NY).

Klaus Koch. 1955. “Gibt es ein Vergeltungsdogma im Alten Testament?” *Zeitschrift für Theologie und Kirche* 52: 1–42.

Koons, Robert C. 1997. “A New Look at the Cosmological Argument.” *American Philosophical Quarterly* 34 (2): 171–192.

Robert C. Koons. 2014. “A New Kalam Argument: Revenge of the Grim Reaper.” *Noûs* 48 (2): 256–267.

Klaas J. Kraay. 2010. “Theism, Possible Worlds, and the Multiverse.” *Philosophical Studies* 147, no. 3: 355–368.

Kratzer, Angelika. 2012. *Modals and Conditionals: New and Revised Perspectives*. Oxford University Press.

Richard Kraut. 2007. *What Is Good and Why: The Ethics of Well-Being*. Harvard University Press.

Kretzmann, Norman. 1966. “Omniscience and Immutability.” *Journal of Philosophy* 63, no. 14: 409–421.

Kriegel, Uriah. 2009. *Subjective Consciousness: A Self-Representational Theory*. Oxford University Press.

Kripke, Saul A. 1963. “Semantical Analysis of Modal Logic I: Normal Modal Propositional Calculi.” *Zeitschrift für mathematische Logik und Grundlagen der Mathematik* 9 (5–6): 67–96.

Kripke, Saul A. 1980. *Naming and Necessity*. Cambridge, MA: Harvard University Press.

Kussell, E., and S. Leibler. 2005. “Phenotypic Diversity, Population Growth, and Information in Fluctuating Environments.” *Science* 309 (5743): 2075–2078.

Kvanvig, Jonathan L.; McCann, Hugh J. 1988. “Divine Conservation and the Persistence of the World.” In Thomas V. Morris (ed.), Divine and Human Action: Essays in the Metaphysics of Theism, Ithaca, NY: Cornell University Press, pp. 13–49.

Jennifer Lackey (ed.). 2014. *Essays in Collective Epistemology*. Oxford University Press.

Ladyman, J., and D. Ross, with D. Spurrett and J. Collier. 2007. *Every Thing Must Go: Metaphysics Naturalized*. Oxford: Oxford University Press.

David T. Lamb. 2022. *God Behaving Badly: Is the God of the Old Testament Angry, Sexist, and Racist?* IVP Academic (expanded edition; orig. 2011).

Landauer, R. 1961. “Irreversibility and Heat Generation in the Computing Process.” *IBM Journal of Research and Development* 5 (3): 183–191.

Lane, N., and W. F. Martin. 2012. “The Origin of Membrane Bioenergetics.” *Cell* 151 (7): 1406–1416.

Lane, N. 2015. *The Vital Question: Energy, Evolution, and the Origins of Complex Life*. New York: W. W. Norton.

Langton, Rae. 1998. *Kantian Humility: Our Ignorance of Things in Themselves*. Oxford University Press.

Pierre-Simon Laplace. 1814. *A Philosophical Essay on Probabilities*. Paris: Courcier (Essai philosophique sur les probabilités).

Robert A. Larmer. 2014. *The Legitimacy of Miracle*. Lanham, MD: Lexington Books.

Richard S. Lazarus. 1991. *Emotion and Adaptation*. Oxford University Press (New York).

Le Poidevin, Robin. 1991. *Change, Cause, and Contradiction*. Macmillan (London) / St. Martin's Press (New York).

Joseph E. LeDoux. 1996. *The Emotional Brain: The Mysterious Underpinnings of Emotional Life*. Simon & Schuster (New York).

Joseph E. LeDoux. 2012. “Rethinking the Emotional Brain.” *Neuron* 73(4): 653–676.

Leftow, Brian. 1991. *Time and Eternity*. Cornell University Press (Ithaca, NY & London).

Leftow, Brian. 2004. “A Latin Trinity.” *Faith and Philosophy* 21 (3): 304–333.

Leftow, Brian. 2012. *God and Necessity*. Oxford: Oxford University Press.

Leibniz, G. W. (1714) 1989. “Monadology.” Philosophical Essays, translated by R. Ariew and D. Garber. Indianapolis: Hackett.

G. W. Leibniz. 1710. *Theodicy: Essays on the Goodness of God, the Freedom of Man and the Origin of Evil*. Original: Essais de Théodicée (Amsterdam, 1710); standard Eng. ed. trans. E. M. Huggard, ed. A. Farrer (Routledge & Kegan Paul, 1951; repr. Open Court, 1985).

G. W. Leibniz and Samuel Clarke. 1715–1716. *The Leibniz–Clarke Correspondence*. Ed. H. G. Alexander, Manchester University Press (1956).

Lenton, Timothy M. 1998. “Gaia and Natural Selection.” *Nature* 394: 439–447.

Leslie, John. 1979. *Value and Existence*. Oxford: Basil Blackwell.

Leśniewski, Stanisław. 1916. “Podstawy ogólnej teorii mnogości I (Foundations of the General Theory of Sets I).” Moscow: Prace Polskiego Koła Naukowego w Moskwie.

Levin, M. 2019. “The Computational Boundary of a 'Self': Developmental Bioelectricity Drives Multicellularity and Scale-Free Cognition.” *Frontiers in Psychology* 10: 2688.

Emmanuel Levinas. 1961. *Totality and Infinity: An Essay on Exteriority (Totalité et Infini: essai sur l'extériorité)*. M. Nijhoff (French orig. 1961); Duquesne University Press (English trans. A. Lingis, 1969).

Levine, Michael P. 1994. *Pantheism: A Non-Theistic Concept of Deity*. Routledge.

C. S. Lewis. 1940. *The Problem of Pain*. London: The Centenary Press (Geoffrey Bles), 1940 (US: New York: Macmillan).

Lewis, David. 1973. *Counterfactuals*. Cambridge, MA: Harvard University Press.

David Lewis. 1973. “Causation.” *The Journal of Philosophy* 70, no. 17: 556–567.

Lewis, David. 1986. *On the Plurality of Worlds*. Oxford: Blackwell.

Lewis, David. 1986. *Philosophical Papers, Volume II*. Oxford University Press (New York & Oxford).

Lewis, David. 1994. “Humean Supervenience Debugged.” *Mind*.

Licona, Michael R. 2010. *The Resurrection of Jesus: A New Historiographical Approach*. Downers Grove, IL: InterVarsity Press.

Lincoln, T. A., and G. F. Joyce. 2009. “Self-Sustained Replication of an RNA Enzyme.” *Science* 323 (5918): 1229–1232.

Harold Lindsell. 1949. *A Christian Philosophy of Missions*. Van Kampen Press.

Lloyd, S. 2006. *Programming the Universe: A Quantum Computer Scientist Takes on the Cosmos*. New York: Knopf.

Locke, John. (1689) 1988. *Two Treatises of Government*. Edited by Peter Laslett. Cambridge: Cambridge University Press.

George Loewenstein. 1994. “The Psychology of Curiosity: A Review and Reinterpretation.” *Psychological Bulletin* 116(1): 75–98.

Loewer, B. 1996. “Humean Supervenience.” *Philosophical Topics* 24 (1): 101–127.

Barry Loewer. 2007. “Counterfactuals and the Second Law.” In Huw Price & Richard Corry (eds.), Causation, Physics, and the Constitution of Reality: Russell's Republic Revisited (Oxford University Press).

Elizabeth F. Loftus. 1979. *Eyewitness Testimony*. Harvard University Press (Cambridge, MA).

Andrew Ter Ern Loke. 2017. *God and Ultimate Origins: A Novel Cosmological Argument*. Palgrave Macmillan / Springer (Cham).

Lombard, Lawrence Brian. 1986. *Events: A Metaphysical Study*. Routledge & Kegan Paul (London & Boston).

Long, A. A., and D. N. Sedley. 1987. *The Hellenistic Philosophers*. Vol. 1. Cambridge: Cambridge University Press.

Steven A. Long. 2011. *Analogia Entis: On the Analogy of Being, Metaphysics, and the Act of Faith*. University of Notre Dame Press.

Vladimir Lossky. 1957. *The Mystical Theology of the Eastern Church*. James Clarke & Co.

Olli J. Loukola; Clint J. Perry; Louie Coscos; Lars Chittka. 2017. “Bumblebees Show Cognitive Flexibility by Improving on an Observed Complex Behavior.” *Science* 355(6327): 833–836.

Lowe, E. J. 1998. *The Possibility of Metaphysics: Substance, Identity, and Time*. Oxford: Oxford University Press.

Lowe, E. J. 2006. *The Four-Category Ontology: A Metaphysical Foundation for Natural Science*. Oxford: Oxford University Press.

Lucretius. (c. 50 BCE) 1992. *De Rerum Natura*. Translated by W. H. D. Rouse, revised by M. F. Smith. Cambridge, MA: Harvard University Press (Loeb Classical Library).

William G. Lycan and George N. Schlesinger. 1989. “You Bet Your Life: Pascal's Wager Defended.” in J. Feinberg (ed.), Reason and Responsibility (Wadsworth).

Lyon, P. 2015. “The Cognitive Cell: Bacterial Behavior Reconsidered.” *Frontiers in Microbiology* 6: 264.

J. L. Mackie. 1955. “Evil and Omnipotence.” *Mind* 64, no. 254, pp. 200–212.

J. L. Mackie. 1982. *The Miracle of Theism: Arguments For and Against the Existence of God*. Clarendon Press / Oxford University Press (Oxford).

Maddy, Penelope. 1990. *Realism in Mathematics*. Oxford University Press (Clarendon).

Maddy, Penelope. 1997. *Naturalism in Mathematics*. Clarendon Press / Oxford University Press (Oxford).

Maddy, Penelope. 2011. *Defending the Axioms: On the Philosophical Foundations of Set Theory*. Oxford University Press.

Tiago V. Maia; James L. McClelland. 2004. “A Reexamination of the Evidence for the Somatic Marker Hypothesis: What Participants Really Know in the Iowa Gambling Task.” *Proceedings of the National Academy of Sciences* 101 (45): 16075–16080.

Maimonides, Moses. (c. 1190) 1963. *The Guide of the Perplexed*. Translated by Shlomo Pines. Chicago: University of Chicago Press.

Stephen Maitzen. 2006. “Divine Hiddenness and the Demographics of Theism.” *Religious Studies* 42, no. 2: 177–191.

Stephen Maitzen. 2009. “Ordinary Morality Implies Atheism.” *European Journal for Philosophy of Religion* 1, no. 2: 107–126.

Maitzen, Stephen. 2012. “Stop Asking Why There's Anything.” *Erkenntnis*.

Mann, William E. 1982. “Divine Simplicity.” *Religious Studies* 18 (4): 451–471.

Jean-Luc Marion. 1991. *God Without Being: Hors-Texte*. University of Chicago Press (trans. T. A. Carlson).

Marion, Jean-Luc. 2002. *Being Given: Toward a Phenomenology of Givenness*. Stanford University Press (trans. J. L. Kosky).

Jason Marsh. 2008. “Do the Demographics of Theistic Belief Disconfirm Theism? A Reply to Maitzen.” *Religious Studies* 44, no. 4: 465–471.

Marshall, T. H. 1950. *Citizenship and Social Class and Other Essays*. Cambridge: Cambridge University Press.

Martin, Michael. 1990. *Atheism: A Philosophical Justification*. Temple University Press (Philadelphia).

Martin, C. B. 1994. “Dispositions and Conditionals.” *The Philosophical Quarterly*.

Martin, W., and M. J. Russell. 2003. “On the Origins of Cells: A Hypothesis for the Evolutionary Transitions from Abiotic Geochemistry to Chemoautotrophic Prokaryotes, and from Prokaryotes to Nucleated Cells.” *Philosophical Transactions of the Royal Society B* 358 (1429): 59–85.

Martin, W., and M. J. Russell. 2007. “On the Origin of Biochemistry at an Alkaline Hydrothermal Vent.” *Philosophical Transactions of the Royal Society B* 362 (1486): 1887–1925.

Massimo Pigliucci, Gerd B. Müller (eds.). 2010. *Evolution: The Extended Synthesis*. Cambridge, MA: MIT Press.

Jennifer A. Mather; Roland C. Anderson. 1993. “Personalities of Octopuses (Octopus rubescens).” *Journal of Comparative Psychology* 107(3): 336–340.

Mathews, Freya. 2003. *For Love of Matter: A Contemporary Panpsychism*. State University of New York Press.

Matthew W. Powner, Béatrice Gerland, John D. Sutherland. 2009. “Synthesis of Activated Pyrimidine Ribonucleotides in Prebiotically Plausible Conditions.” *Nature* 459(7244):239–242.

Maudlin, Tim. 2002. *Quantum Non-Locality and Relativity*. Blackwell (Malden, MA), 2nd ed.

Maudlin, Tim. 2007. *The Metaphysics within Physics*. Oxford: Oxford University Press.

Tim Maudlin. 2012. *Philosophy of Physics: Space and Time*. Princeton University Press.

Maudlin, Tim. 2019. *Philosophy of Physics: Quantum Theory*. Princeton, NJ: Princeton University Press.

Anna-Sofia Maurin. 2002. *If Tropes*. Kluwer Academic Publishers (Dordrecht), Synthese Library vol. 308.

George I. Mavrodes. 1963. “Some Puzzles Concerning Omnipotence.” *The Philosophical Review* 72, no. 2: 221–223.

George I. Mavrodes. 1986. “Religion and the Queerness of Morality.” in R. Audi & W. J. Wainwright (eds.), Rationality, Religious Belief, and Moral Commitment, Cornell University Press: 213–226.

Maxwell, J. C. 1865. “A Dynamical Theory of the Electromagnetic Field.” *Philosophical Transactions of the Royal Society of London* 155: 459–512.

James Clerk Maxwell. 1873. *A Treatise on Electricity and Magnetism*. Oxford: Clarendon Press (2 vols.).

Julius Robert Mayer. 1842. “Bemerkungen über die Kräfte der unbelebten Natur.” *Annalen der Chemie und Pharmacie* 42:233–240.

Maynard Smith, J., and E. Szathmáry. 1995. *The Major Transitions in Evolution*. Oxford: W. H. Freeman.

Hugh J. McCann. 2012. *Creation and the Sovereignty of God*. Bloomington: Indiana University Press.

McCormack, Bruce L. 1995. *Karl Barth's Critically Realistic Dialectical Theology: Its Genesis and Development, 1909-1936*. Oxford: Clarendon Press.

McDowell, John. 1994. *Mind and World*. Harvard University Press.

Jon McGinnis. 2010. *Avicenna*. Oxford University Press (Oxford & New York).

Ralph M. McInerny. 1996. *Aquinas and Analogy*. Washington, DC: Catholic University of America Press.

McTaggart, J. M. E. 1908. “The Unreality of Time.” *Mind* 17 (68): 457–474.

Meissner, K. A. 2025. “Conformal Cyclic Cosmology: Latest Developments.” *General Relativity and Gravitation* 57 (2): 25.

Melamed, Yitzhak Y. 2013. *Spinoza's Metaphysics: Substance and Thought*. Oxford: Oxford University Press.

Mellor, D. H. 1981. *Real Time*. Cambridge University Press.

Mellor, D. H. 1998. *Real Time II*. London: Routledge.

Merleau-Ponty, Maurice. 1945. *Phenomenology of Perception*. Paris: Gallimard (Phénoménologie de la perception; Eng. trans. Colin Smith, Routledge & Kegan Paul, 1962).

Julien Offray de La Mettrie. 1747. *Man a Machine (L'Homme Machine)*. Leiden: Elie Luzac.

Stephen C. Meyer. 2009. *Signature in the Cell: DNA and the Evidence for Intelligent Design*. HarperOne (New York).

Stephen C. Meyer. 2013. *Darwin's Doubt: The Explosive Origin of Animal Life and the Case for Intelligent Design*. HarperOne (HarperCollins).

Mill, John Stuart. 1859. *On Liberty*. London: John W. Parker and Son.

Ruth Garrett Millikan. 1984. *Language, Thought, and Other Biological Categories: New Foundations for Realism*. MIT Press.

Ruth Garrett Millikan. 1995. “Pushmi-Pullyu Representations.” *Philosophical Perspectives* 9: 185–200.

Mills, Charles W. 1997. *The Racial Contract*. Cornell University Press.

Minkowski, H. 1908. “Raum und Zeit.” *Physikalische Zeitschrift* 10: 75–88.

Misner, C. W., K. S. Thorne, and J. A. Wheeler. 1973. *Gravitation*. San Francisco: W. H. Freeman.

Mitchell, P. 1961. “Coupling of Phosphorylation to Electron and Hydrogen Transfer by a Chemi-Osmotic Type of Mechanism.” *Nature* 191 (4784): 144–148.

Mojzsis, S. J., G. Arrhenius, K. D. McKeegan, T. M. Harrison, A. P. Nutman, and C. R. L. Friend. 1996. “Evidence for Life on Earth before 3,800 Million Years Ago.” *Nature* 384 (6604): 55–59.

Luis de Molina. 1588. *Concordia liberi arbitrii cum gratiae donis (On the Compatibility of Free Choice with the Gifts of Grace)*. Lisbon (1st ed., 1588).

Moltmann, Jürgen. 1974. *The Crucified God: The Cross of Christ as the Foundation and Criticism of Christian Theology*. Harper & Row.

Bradley Monton. 2006. “God, Fine-Tuning, and the Problem of Old Evidence.” *The British Journal for the Philosophy of Science* 57(2): 405–424.

Thomas V. Morris. 1986. *The Logic of God Incarnate*. Ithaca: Cornell University Press.

Thomas V. Morris and Christopher Menzel. 1986. “Absolute Creation.” *American Philosophical Quarterly* 23(4): 353–362.

Thomas V. Morris. 1987. *Anselmian Explorations: Essays in Philosophical Theology*. Notre Dame: University of Notre Dame Press.

Thomas V. Morris. 1991. *Our Idea of God: An Introduction to Philosophical Theology*. Downers Grove, IL: InterVarsity Press (Contours of Christian Philosophy).

Wes Morriston. 2000. “Must the Beginning of the Universe Have a Personal Cause?: A Critical Examination of the Kalam Cosmological Argument.” *Faith and Philosophy* 17, no. 2: 149–169.

Wes Morriston. 2002. “Creation Ex Nihilo and the Big Bang.” *Philo* 5(1): 23–33.

Wes Morriston. 2010. “Beginningless Past, Endless Future, and the Actual Infinite.” *Faith and Philosophy* 27(4): 439–450.

Wes Morriston. 2013. “Doubts about the Kalām Cosmological Argument.” In Debating Christian Theism, ed. J. P. Moreland, Chad Meister, and Khaldoun A. Sweis, 20–32. Oxford: Oxford University Press.

Muchowska, K. B., S. J. Varma, E. Chevallot-Beroux, L. Lethuillier-Karl, G. Li, and J. Moran. 2017. “Metals Promote Sequences of the Reverse Krebs Cycle.” *Nature Ecology & Evolution* 1 (11): 1716–1721.

Muchowska, K. B., S. J. Varma, and J. Moran. 2019. “Synthesis and Breakdown of Universal Metabolic Precursors Promoted by Iron.” *Nature* 569 (7754): 104–107.

Mullins, R. T. 2013. “Simply Impossible: A Case Against Divine Simplicity.” *Journal of Reformed Theology* 7(2): 181–203.

Mullins, R. T. 2016. *The End of the Timeless God*. Oxford: Oxford University Press.

R. T. Mullins and Shannon Byrd. 2022. “Divine Simplicity and Modal Collapse: A Persistent Problem.” *European Journal for Philosophy of Religion* 14, no. 1: 21–52.

Mumford, Stephen. 2004. *Laws in Nature*. Routledge.

Mumford, Stephen; Anjum, Rani Lill. 2011. *Getting Causes from Powers*. Oxford University Press.

Sachiko Murata and William C. Chittick. 1994. *The Vision of Islam*. Paragon House.

Mark C. Murphy. 2002. *An Essay on Divine Authority*. Cornell University Press (Cornell Studies in the Philosophy of Religion).

Mark C. Murphy. 2017. *God's Own Ethics: Norms of Divine Agency and the Argument from Evil*. New York: Oxford University Press.

John Murray. 1955. *Redemption Accomplished and Applied*. Eerdmans.

John Murray. 1959. *The Imputation of Adam's Sin*. Grand Rapids: Eerdmans, 1959 (orig. WTJ article series, 1955-57; repr. P&R, 1977).

Michael J. Murray and Kurt Meyers. 1994. “Ask and It Will Be Given to You.” *Religious Studies* 30, no. 3: 311–330.

Nāgārjuna. (c. 2nd c. CE) 1995. *Mūlamadhyamakakārikā: The Fundamental Wisdom of the Middle Way*. Translated by J. L. Garfield. New York: Oxford University Press.

Nagasawa, Yujin. 2008. *God and Phenomenal Consciousness: A Novel Approach to Knowledge Arguments*. Cambridge University Press.

Thomas Nagel. 1974. “What Is It Like to Be a Bat?” *The Philosophical Review* 83(4): 435–450.

Neurath, Otto. 1944. “Foundations of the Social Sciences.” International Encyclopedia of Unified Science, vol. 2, no. 1, Chicago: University of Chicago Press.

Newton, Isaac. 1687. *Philosophiæ Naturalis Principia Mathematica*. London: Jussu Societatis Regiae (Royal Society).

Newton-Smith, W. H. 1980. *The Structure of Time*. London: Routledge & Kegan Paul.

Alyssa Ney and David Z. Albert (eds.). 2013. *The Wave Function: Essays on the Metaphysics of Quantum Mechanics*. Oxford University Press.

Alyssa Ney. 2021. *The World in the Wave Function: A Metaphysics for Quantum Physics*. Oxford University Press.

Nietzsche, Friedrich. (1881) 1997. *Daybreak: Thoughts on the Prejudices of Morality*. Translated by R. J. Hollingdale; edited by M. Clark and B. Leiter. Cambridge: Cambridge University Press.

Nietzsche, Friedrich. (1886) 2002. *Beyond Good and Evil: Prelude to a Philosophy of the Future*. Translated by J. Norman; edited by R.-P. Horstmann and J. Norman. Cambridge: Cambridge University Press.

Nissen, P., J. Hansen, N. Ban, P. B. Moore, and T. A. Steitz. 2000. “The Structural Basis of Ribosome Activity in Peptide Bond Synthesis.” *Science* 289 (5481): 920–930.

Noether, Emmy. 1918. “Invariante Variationsprobleme.” *Nachrichten von der Gesellschaft der Wissenschaften zu Göttingen* 1918: 235–257.

Nolan, Daniel. 1997. “Impossible Worlds: A Modest Approach.” *Notre Dame Journal of Formal Logic* 38 (4): 535-572.

Norton, J. D. 2003. “Causation as Folk Science.” *Philosophers' Imprint* 3 (4): 1–22.

Robert Nozick. 1974. *Anarchy, State, and Utopia*. Basic Books.

Nozick, Robert. 1981. *Philosophical Explanations*. Harvard University Press.

Nussbaum, Martha C. 2000. *Women and Human Development: The Capabilities Approach*. Cambridge: Cambridge University Press.

Nussbaum, Martha C. 2001. *Upheavals of Thought: The Intelligence of Emotions*. Cambridge: Cambridge University Press.

Nussbaum, Martha C. 2006. *Frontiers of Justice: Disability, Nationality, Species Membership*. Cambridge, MA: Belknap Press of Harvard University Press.

Timothy O'Connor. 2000. *Persons and Causes: The Metaphysics of Free Will*. New York: Oxford University Press.

L. Nathan Oaklander. 2004. *The Ontology of Time*. Prometheus Books.

Odling-Smee, F. J., K. N. Laland, and M. W. Feldman. 2003. *Niche Construction: The Neglected Process in Evolution*. Princeton, NJ: Princeton University Press.

Omnès, R. 1994. *The Interpretation of Quantum Mechanics*. Princeton, NJ: Princeton University Press.

Thomas Jay Oord. 2015. *The Uncontrolling Love of God: An Open and Relational Account of Providence*. Downers Grove, IL: IVP Academic (InterVarsity Press).

Oppenheim, Paul, and Hilary Putnam. 1958. “Unity of Science as a Working Hypothesis.” In H. Feigl, M. Scriven, and G. Maxwell (eds.), Minnesota Studies in the Philosophy of Science, vol. 2, Minneapolis: University of Minnesota Press.

Oppy, Graham. 1995. *Ontological Arguments and Belief in God*. Cambridge: Cambridge University Press.

Oppy, Graham. 2006. *Arguing about Gods*. Cambridge: Cambridge University Press.

Oppy, Graham. 2013. *The Best Argument Against God*. Basingstoke: Palgrave Macmillan.

Graham Oppy. 2018. *Atheism and Agnosticism*. Cambridge: Cambridge University Press.

Graham Oppy. 2018. *Naturalism and Religion: A Contemporary Philosophical Investigation*. Routledge (Investigating Philosophy of Religion).

Rudolf Otto. 1917. *The Idea of the Holy: An Inquiry into the Non-Rational Factor in the Idea of the Divine and its Relation to the Rational (Das Heilige)*. Breslau (German orig. 1917); Oxford University Press (English trans. 1923).

Alan G. Padgett. 1992. *God, Eternity and the Nature of Time*. New York: St. Martin's Press.

Page, Don N., and William K. Wootters. 1983. “Evolution Without Evolution: Dynamics Described by Stationary Observables.” *Physical Review D* 27(12): 2885–2892.

Page, D. N. 1993. “Information in Black Hole Radiation.” *Physical Review Letters* 71 (23): 3743–3746.

Paine, Thomas. 1794. *The Age of Reason*. Paris: Barrois, 1794 (Part I; Part II 1795).

Petra Pakkanen. 1996. *Interpreting Early Hellenistic Religion: A Study Based on the Mystery Cult of Demeter and the Cult of Isis*. Finnish Institute at Athens / University of Helsinki.

Paley, William. 1802. *Natural Theology; or, Evidences of the Existence and Attributes of the Deity*. London: R. Faulder.

Panksepp, J. 1998. *Affective Neuroscience: The Foundations of Human and Animal Emotions*. Oxford: Oxford University Press.

David Papineau. 1987. *Reality and Representation*. Basil Blackwell.

Blaise Pascal. 1670. *Pensées*. Paris: Guillaume Desprez.

Patel, B. H., C. Percivalle, D. J. Ritson, C. D. Duffy, and J. D. Sutherland. 2015. “Common Origins of RNA, Protein and Lipid Precursors in a Cyanosulfidic Protometabolism.” *Nature Chemistry* 7 (4): 301–307.

Paul J. Steinhardt, Neil Turok. 2007. *Endless Universe: Beyond the Big Bang*. New York: Doubleday.

Linus Pauling. 1939. *The Nature of the Chemical Bond and the Structure of Molecules and Crystals*. Ithaca, NY: Cornell University Press.

Timothy Pawl. 2016. *In Defense of Conciliar Christology: A Philosophical Essay*. Oxford: Oxford University Press.

Timothy Pawl. 2019. *In Defense of Extended Conciliar Christology: A Philosophical Essay*. Oxford: Oxford University Press.

Pawl, Timothy. 2020. “Divine Immutability.” Internet Encyclopedia of Philosophy.

Arthur Peacocke. 2007. *All That Is: A Naturalistic Faith for the Twenty-First Century*. Minneapolis: Fortress Press.

Joel Pearson. 2019. “The human imagination: the cognitive neuroscience of visual mental imagery.” *Nature Reviews Neuroscience* 20(10): 624–634.

Sergio Pellis; Vivien Pellis. 2009. *The Playful Brain: Venturing to the Limits of Neuroscience*. Oneworld Publications.

Penington, G. 2020. “Entanglement Wedge Reconstruction and the Information Paradox.” *Journal of High Energy Physics* 2020 (9): 002.

Roger Penrose. 1979. “Singularities and Time-Asymmetry.” In S. W. Hawking and W. Israel (eds.), General Relativity: An Einstein Centenary Survey (Cambridge University Press), pp. 581–638.

Penrose, R. 1989. *The Emperor's New Mind*. Oxford: Oxford University Press.

Penrose, R. 2010. *Cycles of Time: An Extraordinary New View of the Universe*. London: Bodley Head.

Perl, Eric D. 2014. *Thinking Being: Introduction to Metaphysics in the Classical Tradition*. Leiden: Brill.

Pettit, Philip. 1997. *Republicanism: A Theory of Freedom and Government*. Oxford: Oxford University Press.

Pettit, Philip. 2012. *On the People's Terms: A Republican Theory and Model of Democracy*. Cambridge: Cambridge University Press.

Pfeifer, Karl. 2016. “Pantheism as Panpsychism.” In Alternative Concepts of God, ed. Andrei A. Buckareff and Yujin Nagasawa. Oxford University Press.

Herman Philipse. 2012. *God in the Age of Science? A Critique of Religious Reason*. Oxford: Oxford University Press.

Pizzi, David. 2025. “The Impossibility of Nothingness: A Foundational Argument for Necessary Existence.” PhilArchive (preprint).

Alvin Plantinga. 1967. *God and Other Minds: A Study of the Rational Justification of Belief in God*. Ithaca, NY: Cornell University Press.

Plantinga, A. 1974. *The Nature of Necessity*. Oxford: Oxford University Press.

Plantinga, A. 1980. *Does God Have a Nature?* Milwaukee: Marquette University Press.

Alvin Plantinga. 1993. *Warrant and Proper Function*. New York: Oxford University Press.

Plantinga, A. 2000. *Warranted Christian Belief*. Oxford University Press.

Alvin Plantinga. 2004. “Supralapsarianism, or 'O Felix Culpa'.” in Peter van Inwagen (ed.), Christian Faith and the Problem of Evil (Grand Rapids, MI: Eerdmans), 1–25.

Alvin Plantinga. 2007. “Two Dozen (or So) Theistic Arguments.” Appendix in Deane-Peter Baker (ed.), Alvin Plantinga (Cambridge: Cambridge University Press), 203–227.

Plantinga, A. 2011. *Where the Conflict Really Lies: Science, Religion, and Naturalism*. Oxford University Press.

Plotinus. c. 270 CE. *The Enneads*. Cambridge, MA: Harvard University Press (Loeb Classical Library).

Pnueli, Amir. 1977. “The Temporal Logic of Programs.” *Proceedings of the* 18th Annual Symposium on Foundations of Computer Science (FOCS), IEEE.

Henri Poincaré. 1890. “Sur le problème des trois corps et les équations de la dynamique.” *Acta Mathematica* 13:1–270.

Oliver Pooley. 2013. “Substantivalist and Relationalist Approaches to Spacetime.” In Robert Batterman (ed.), The Oxford Handbook of Philosophy of Physics (Oxford University Press).

Poplawski, N. J. 2010. “Cosmology with Torsion: An Alternative to Cosmic Inflation.” *Physics Letters B* 694 (3): 181–185.

Poplawski, N. J. 2012. “Nonsingular, Big-Bounce Cosmology from Spinor-Torsion Coupling.” *Physical Review D* 85 (10): 107502.

David Premack and Guy Woodruff. 1978. “Does the chimpanzee have a theory of mind?” *Behavioral and Brain Sciences* 1(4): 515–526.

Stephanie D. Preston; Frans B. M. de Waal. 2002. “Empathy: Its Ultimate and Proximate Bases.” *Behavioral and Brain Sciences* 25(1): 1–20.

Price, Huw. 1996. *Time's Arrow and Archimedes' Point: New Directions for the Physics of Time*. New York: Oxford University Press.

Priest, Graham. 2005. *Towards Non-Being: The Logic and Metaphysics of Intentionality*. Oxford University Press.

Prigogine, I., and G. Nicolis. 1977. *Self-Organization in Nonequilibrium Systems*. New York: Wiley.

Prigogine, I., and I. Stengers. 1984. *Order Out of Chaos: Man's New Dialogue with Nature*. New York: Bantam.

Jesse J. Prinz. 2004. *Gut Reactions: A Perceptual Theory of Emotion*. Oxford University Press (New York).

Prior, A. N. 1957. *Time and Modality*. Oxford: Clarendon Press.

Prior, A. N. 1959. “Thank Goodness That's Over.” *Philosophy* 34, no. 128: 12–17.

Prior, A. N. 1962. “The Formalities of Omniscience.” *Philosophy* 37, no. 140: 114–129.

Prior, A. N. 1967. *Past, Present and Future*. Oxford University Press (Clarendon).

Prior, A. N. 1968. “Changes in Events and Changes in Things.” in Papers on Time and Tense (Oxford: Clarendon Press), 1–14.

Pruss, Alexander R. 2006. *The Principle of Sufficient Reason: A Reassessment*. Cambridge: Cambridge University Press.

Alexander R. Pruss. 2008. “On Two Problems of Divine Simplicity.” In J. Kvanvig (ed.), Oxford Studies in Philosophy of Religion, vol. 1: 150–167. Oxford University Press.

Pruss, A. R. 2011. *Actuality, Possibility, and Worlds*. New York: Continuum.

Pruss, Alexander R. 2013. “Omnipresence, Multilocation, the Real Presence and Time Travel.” *Journal of Analytic Theology* 1, no. 1: 60–73.

Pruss, Alexander R., and Joshua L. Rasmussen. 2018. *Necessary Existence*. Oxford University Press.

Alexander R. Pruss. 2018. *Infinity, Causation, and Paradox*. Oxford: Oxford University Press.

Putnam, Hilary. 1967. “Time and Physical Geometry.” *The Journal of Philosophy* 64(8): 240–247.

Putnam, Hilary. 1967. “Psychological Predicates.” In W. H. Capitan and D. D. Merrill (eds.), Art, Mind, and Religion, Pittsburgh: University of Pittsburgh Press.

Putnam, Hilary. 1971. *Philosophy of Logic*. New York: Harper & Row.

Putnam, Hilary. 1975. “The Meaning of 'Meaning'.” Minnesota Studies in the Philosophy of Science 7: 131–193 (University of Minnesota Press).

Putnam, Hilary. 1979. *Mathematics, Matter and Method: Philosophical Papers, Volume 1*. Cambridge: Cambridge University Press (2nd ed.).

Quine, W. V. O. 1948. “On What There Is.” *Review of Metaphysics* 2 (5): 21–38.

Quine, W. V. O. 1951. “Two Dogmas of Empiricism.” *The Philosophical Review* 60 (1).

Quine, W. V. 1951. “On Carnap's Views on Ontology.” *Philosophical Studies* 2(5): 65–72.

Quine, W. V. 1953. “Reference and Modality.” in From a Logical Point of View (Cambridge, MA: Harvard University Press), 139–159.

Quine, W. V. O. 1960. *Word and Object*. Cambridge, MA: MIT Press.

Quine, W. V. O. 1969. “Epistemology Naturalized.” In Ontological Relativity and Other Essays, New York: Columbia University Press.

Quine, W. V. 1969. “Natural Kinds.” in Ontological Relativity and Other Essays (New York: Columbia University Press), 114–138.

Karl Rahner. 1976. *Foundations of Christian Faith: An Introduction to the Idea of Christianity*. Herder (orig. Grundkurs des Glaubens, 1976; Eng. trans. Seabury Press, 1978).

Randell, D. A., Z. Cui, and A. G. Cohn. 1992. “A Spatial Logic Based on Regions and Connection.” In Proceedings of the 3rd International Conference on Principles of Knowledge Representation and Reasoning (KR'92), Morgan Kaufmann.

Rasmussen, Joshua. 2009. “From a Necessary Being to God.” *International Journal for Philosophy of Religion* 66(1): 1–13.

Rasmussen, Joshua. 2019. *How Reason Can Lead to God: A Philosopher's Bridge to Faith*. Downers Grove, IL: IVP Academic.

Ratcliff, W. C., R. F. Denison, M. Borrello, and M. Travisano. 2012. “Experimental Evolution of Multicellularity.” *Proceedings of the National Academy of Sciences* 109 (5): 1595–1600.

Rawls, John. 1971. *A Theory of Justice*. Belknap Press of Harvard University Press.

Raworth, Kate. 2017. *Doughnut Economics: Seven Ways to Think Like a 21st-Century Economist*. White River Junction, VT: Chelsea Green Publishing.

Michael C. Rea. 2007. “The Metaphysics of Original Sin.” in Persons: Human and Divine, eds. van Inwagen and Zimmerman (Oxford University Press): 319–356.

Michael C. Rea. 2009. “The Trinity.” In The Oxford Handbook of Philosophical Theology, eds. Thomas P. Flint & Michael C. Rea (Oxford University Press), pp. 403–29.

Michael Redhead. 1982. “Quantum Field Theory for Philosophers.” *PSA: Proceedings of the Biennial Meeting of the Philosophy of Science Association* 1982, vol. 2, pp. 57–99.

Reichenbach, Hans. 1956. *The Direction of Time*. Berkeley: University of California Press.

Bruce R. Reichenbach. 1982. *Evil and a Good God*. New York: Fordham University Press, 1982 (pp. ix+198).

Nicholas Rescher. 1996. *Process Metaphysics: An Introduction to Process Philosophy*. Albany: State University of New York Press.

Rietdijk, C. W. 1966. “A Rigorous Proof of Determinism Derived from the Special Theory of Relativity.” *Philosophy of Science* 33(4): 341–344.

Robert C. Roberts. 2003. *Emotions: An Essay in Aid of Moral Psychology*. Cambridge University Press.

Roca-Royes, Sonia. 2011. “Conceivability and De Re Modal Knowledge.” *Nous* 45 (1): 22-49.

Rocca, Gregory P. 2004. *Speaking the Incomprehensible God: Thomas Aquinas on the Interplay of Positive and Negative Theology*. Catholic University of America Press.

Rogers, Katherin A. 2000. *Perfect Being Theology*. Edinburgh: Edinburgh University Press.

Roosevelt, Franklin D. 1944. “Message to the Congress on the State of the Union (Second Bill of Rights).” January 11, 1944.

J. D. Rose; R. Arlinghaus; S. J. Cooke; B. K. Diggles; W. Sawynok; E. D. Stevens; C. D. L. Wynne. 2014. “Can Fish Really Feel Pain?” *Fish and Fisheries* 15 (1): 97–133.

Rosen, Gideon. 2010. “Metaphysical Dependence: Grounding and Reduction.” In Modality: Metaphysics, Logic, and Epistemology, edited by Bob Hale and Aviv Hoffmann, 109–135. Oxford: Oxford University Press.

Rosen, Gideon. 2015. “Real Definition.” *Analytic Philosophy* 56 (3): 189–209.

David M. Rosenthal. 2005. *Consciousness and Mind*. Oxford: Clarendon Press (Oxford University Press).

Rovelli, Carlo. 2018. *The Order of Time*. New York: Riverhead Books.

William L. Rowe. 1975. *The Cosmological Argument*. Princeton University Press.

William L. Rowe. 2004. *Can God Be Free?* Oxford: Clarendon Press (Oxford University Press).

Bede Rundle. 2004. *Why there is Something rather than Nothing*. Oxford: Clarendon Press (Oxford University Press).

Russell, B. 1913. “On the Notion of Cause.” *Proceedings of the Aristotelian Society* 13: 1–26.

Bertrand Russell. 1940. *An Inquiry into Meaning and Truth*. London: George Allen & Unwin / New York: W. W. Norton.

James A. Russell. 2003. “Core Affect and the Psychological Construction of Emotion.” *Psychological Review* 110 (1): 145–172.

Katharine Doob Sakenfeld. 1978. *The Meaning of Hesed in the Hebrew Bible: A New Inquiry*. Scholars Press (Harvard Semitic Monographs 17).

Sakharov, A. D. 1967. “Violation of CP Invariance, C Asymmetry, and Baryon Asymmetry of the Universe.” *JETP Letters* 5: 24–27 (Pisma Zh. Eksp. Teor. Fiz. 5: 32–35).

Salmon, Wesley C. 1984. *Scientific Explanation and the Causal Structure of the World*. Princeton, NJ: Princeton University Press.

John Sanders. 1992. *No Other Name: An Investigation into the Destiny of the Unevangelized*. Eerdmans.

John Sanders. 1998. *The God Who Risks: A Theology of Providence*. Downers Grove, IL: InterVarsity Press.

Śaṅkara. (c. 800). *Brahma-Sūtra Bhāṣya (Commentary on the Brahma Sūtras)*. trans. Swami Gambhirananda (Calcutta: Advaita Ashrama).

Robert L. Saucy. 1993. *The Case for Progressive Dispensationalism: The Interface Between Dispensational and Non-Dispensational Theology*. Zondervan.

Simon Saunders. 2002. “Is the Zero-Point Energy Real?” In M. Kuhlmann, H. Lyre, and A. Wayne (eds.), Ontological Aspects of Quantum Field Theory (World Scientific).

Scanlon, T. M. 1998. *What We Owe to Each Other*. Belknap Press of Harvard University Press.

Stanley Schachter; Jerome E. Singer. 1962. “Cognitive, Social, and Physiological Determinants of Emotional State.” *Psychological Review* 69 (5): 379–399.

Schaffer, Jonathan. 2009. “On What Grounds What.” In Metametaphysics: New Essays on the Foundations of Ontology, edited by David J. Chalmers, David Manley, and Ryan Wasserman, 347–383. Oxford: Oxford University Press.

Schaffer, Jonathan. 2010. “Monism: The Priority of the Whole.” *Philosophical Review* 119 (1): 31–76.

Schaffer, Jonathan. 2017. “Laws for Metaphysical Explanation.” *Philosophical Issues* 27(1): 302–321.

J. L. Schellenberg. 1993. *Divine Hiddenness and Human Reason*. Cornell University Press.

J. L. Schellenberg. 2007. *The Wisdom to Doubt: A Justification of Religious Skepticism*. Cornell University Press.

J. L. Schellenberg. 2015. *The Hiddenness Argument: Philosophy's New Challenge to Belief in God*. Oxford University Press.

Hans Joachim Schellnhuber. 2009. “Tipping Elements in the Earth System.” *PNAS* 106(49):20561–20563.

Klaus R. Scherer. 1984. “On the Nature and Function of Emotion: A Component Process Approach.” In Approaches to Emotion, ed. K. R. Scherer and P. Ekman, 293–317. Erlbaum (Hillsdale, NJ).

Schmid, Joseph C. 2021. “Existential Inertia and the Aristotelian Proof.” *International Journal for Philosophy of Religion* 89 (3): 201–220.

Schmid, Joseph C. 2022. “From Modal Collapse to Providential Collapse.” *Philosophia* 50 (3): 1413–1435.

Schmid, Joseph C.; Linford, Daniel J. 2022. *Existential Inertia and Classical Theistic Proofs*. Springer (Cham).

Joseph C. Schmid. 2024. “The End is Near: Grim Reapers and Endless Futures.” Mind 133(532): 1057–1077.

Joseph C. Schmid and Alex Malpass. 2025. “Benardete Paradoxes, Causal Finitism, and the Unsatisfiable Pair Diagnosis.” Mind 134(534): 397–421.

Schopenhauer, A. (1819) 1969. *The World as Will and Representation*. Translated by E. F. J. Payne. New York: Dover.

Arthur Schopenhauer. 1813. *On the Fourfold Root of the Principle of Sufficient Reason*. Doctoral dissertation (rev. 1847); trans. E. F. J. Payne (La Salle, IL: Open Court, 1974).

Arthur Schopenhauer. 1818. *The World as Will and Representation (Die Welt als Wille und Vorstellung), Vol. 1*. Leipzig: F. A. Brockhaus.

Schrödinger, E. 1944. *What Is Life?* Cambridge: Cambridge University Press.

Kenneth Seeskin. 2000. *Searching for a Distant God: The Legacy of Maimonides*. New York: Oxford University Press.

Johanna Seibt. 2017. “Process Philosophy.” The Stanford Encyclopedia of Philosophy, ed. Edward N. Zalta (Summer 2017 ed.).

Sellars, Wilfrid. 1956. “Empiricism and the Philosophy of Mind.” Minnesota Studies in the Philosophy of Science, vol. 1.

Michael A. Sells. 1994. *Mystical Languages of Unsaying*. Chicago: University of Chicago Press.

Sen, Amartya. 1992. *Inequality Reexamined*. Cambridge, MA: Harvard University Press.

Sen, Amartya. 1999. *Development as Freedom*. New York: Knopf.

Anil K. Seth. 2013. “Interoceptive Inference, Emotion, and the Embodied Self.” *Trends in Cognitive Sciences* 17 (11): 565–573.

Nicholas Shackel. 2005. “The Form of the Benardete Dichotomy.” The British Journal for the Philosophy of Science 56(2): 397–417.

Shannon, C. E. 1948. “A Mathematical Theory of Communication.” *Bell System Technical Journal* 27 (3): 379–423; (4): 623–656.

Shapiro, Stewart. 1997. *Philosophy of Mathematics: Structure and Ontology*. Oxford: Oxford University Press.

Gila Sher. 2016. *Epistemic Friction: An Essay on Knowledge, Truth, and Logic*. Oxford: Oxford University Press.

Shoemaker, Sydney. 1969. “Time Without Change.” *The Journal of Philosophy* 66(12): 363–381.

Shue, Henry. 1980. *Basic Rights: Subsistence, Affluence, and U.S. Foreign Policy*. Princeton, NJ: Princeton University Press.

Sidelle, Alan. 1989. *Necessity, Essence, and Individuation: A Defense of Conventionalism*. Ithaca, NY: Cornell University Press.

Sidelle, Alan. 2010. “Modality and Objects.” *The Philosophical Quarterly* 60 (238): 109–125.

Sider, Theodore. 2001. *Four-Dimensionalism: An Ontology of Persistence and Time*. Oxford: Clarendon Press (Oxford University Press).

Sider, Theodore. 2011. *Writing the Book of the World*. Oxford University Press.

Mark Siderits. 2003. *Personal Identity and Buddhist Philosophy: Empty Persons*. Aldershot / Burlington, VT: Ashgate.

Mark Siderits. 2007. *Buddhism as Philosophy: An Introduction*. Indianapolis: Hackett / Aldershot: Ashgate.

Simons, Peter. 1987. *Parts: A Study in Ontology*. Oxford: Clarendon Press.

Daniel J. Simons and Christopher F. Chabris. 1999. “Gorillas in our midst: sustained inattentional blindness for dynamic events.” *Perception* 28(9): 1059–1074.

Lawrence Sklar. 1974. *Space, Time, and Spacetime*. University of California Press.

Smart, J. J. C. 1949. “The River of Time.” *Mind* 58(232): 483–494.

Smart, J. J. C. 1963. *Philosophy and Scientific Realism*. London: Routledge & Kegan Paul.

Quentin Smith. 1991. “Atheism, Theism and Big Bang Cosmology.” *Australasian Journal of Philosophy* 69(1):48–66.

Smith, Barry. 2003. “Ontology.” In L. Floridi (ed.), The Blackwell Guide to the Philosophy of Computing and Information, Oxford: Blackwell, pp. 153–166.

Smith, E., and H. J. Morowitz. 2016. *The Origin and Nature of Life on Earth: The Emergence of the Fourth Geosphere*. Cambridge: Cambridge University Press.

Smolin, L. 1992. “Did the Universe Evolve?” *Classical and Quantum Gravity* 9 (1): 173–191.

Lee Smolin. 1997. *The Life of the Cosmos*. New York: Oxford University Press.

Smolin, Lee. 2013. *Time Reborn: From the Crisis in Physics to the Future of the Universe*. Houghton Mifflin Harcourt.

Lynne U. Sneddon; Victoria A. Braithwaite; Michael J. Gentle. 2003. “Do Fishes Have Nociceptors? Evidence for the Evolution of a Vertebrate Sensory System.” *Proceedings of the Royal Society of London B* 270 (1520): 1115–1121.

Lynne U. Sneddon; Robert W. Elwood; Shelley A. Adamo; Matthew C. Leach. 2014. “Defining and Assessing Animal Pain.” *Animal Behaviour* 97: 201–212.

Lynne U. Sneddon. 2015. “Pain in Aquatic Animals.” *Journal of Experimental Biology* 218 (7): 967–976.

Jordan Howard Sobel. 2004. *Logic and Theism: Arguments For and Against Beliefs in God*. Cambridge University Press.

Elliott Sober. 1993. *Philosophy of Biology*. Boulder, CO: Westview Press.

Elliott Sober. 2008. *Evidence and Evolution: The Logic Behind the Science*. Cambridge: Cambridge University Press.

Elliott Sober. 2015. *Ockham's Razors: A User's Manual*. Cambridge: Cambridge University Press.

Sojo, V., B. Herschy, A. Whicher, E. Camprubí, and N. Lane. 2016. “The Origin of Life in Alkaline Hydrothermal Vents.” *Astrobiology* 16 (2): 181–197.

Mark Solms. 2021. *The Hidden Spring: A Journey to the Source of Consciousness*. W. W. Norton (New York).

Robert C. Solomon. 1976. *The Passions: Emotions and the Meaning of Life*. Doubleday (Garden City, NY).

Solomon, S., J. Greenberg, and T. Pyszczynski. 2015. *The Worm at the Core: On the Role of Death in Life*. New York: Random House.

Ernest Sosa. 2007. *A Virtue Epistemology: Apt Belief and Reflective Knowledge, Volume I*. Oxford University Press (Clarendon Press).

Spang, A., J. H. Saw, S. L. Jørgensen, K. Zaremba-Niedzwiedzka, J. Martijn, A. E. Lind, R. van Eijk, C. Schleper, L. Guy, and T. J. G. Ettema. 2015. “Complex Archaea That Bridge the Gap between Prokaryotes and Eukaryotes.” *Nature* 521 (7551): 173–179.

Jeff Speaks. 2018. *The Greatest Possible Being*. Oxford: Oxford University Press.

Spinoza, B. (1677) 1996. *Ethics*. Translated by E. Curley. London: Penguin.

Stein, Howard. 1968. “On Einstein–Minkowski Space–Time.” *The Journal of Philosophy* 65(1): 5–23.

Stein, Howard. 1991. “On Relativity Theory and Openness of the Future.” *Philosophy of Science* 58(2): 147–167.

Victor J. Stenger. 2011. *The Fallacy of Fine-Tuning: Why the Universe Is Not Designed for Us*. Amherst, NY: Prometheus Books.

Stephen M. Kosslyn, Giorgio Ganis, and William L. Thompson. 2001. “Neural foundations of imagery.” *Nature Reviews Neuroscience* 2(9): 635–642.

Stephen W. Hawking, Roger Penrose. 1970. “The Singularities of Gravitational Collapse and Cosmology.” *Proceedings of the Royal Society of London A* 314(1519):529–548.

David W. Stephens; John R. Krebs. 1986. *Foraging Theory*. Princeton University Press.

Sterelny, K. 2003. *Thought in a Hostile World: The Evolution of Human Cognition*. Oxford: Blackwell.

Josef Stern. 2013. *The Matter and Form of Maimonides' Guide*. Cambridge, MA: Harvard University Press.

Daniel Stoljar. 2001. “Two Conceptions of the Physical.” *Philosophy and Phenomenological Research* 62(2): 253–281.

Daniel Stoljar. 2006. *Ignorance and Imagination: The Epistemic Origin of the Problem of Consciousness*. New York: Oxford University Press.

P. F. Strawson. 1966. *The Bounds of Sense: An Essay on Kant's Critique of Pure Reason*. London: Methuen.

Galen Strawson. 2006. “Realistic Monism: Why Physicalism Entails Panpsychism.” *Journal of Consciousness Studies* 13(10–11): 3–31.

Stroud, Barry. 1968. “Transcendental Arguments.” *Journal of Philosophy*.

Stump, Eleonore. 1979. “Petitionary Prayer.” *American Philosophical Quarterly*.

Stump, Eleonore, and Norman Kretzmann. 1981. “Eternity.” *The Journal of Philosophy* 78(8): 429–458.

Eleonore Stump. 1985. “The Problem of Evil.” *Faith and Philosophy* 2, no. 4: 392–423.

Stump, Eleonore. 2003. *Aquinas*. London: Routledge.

Stump, Eleonore. 2010. *Wandering in Darkness: Narrative and the Problem of Suffering*. Oxford University Press.

Stump, Eleonore. 2013. “Omnipresence, Indwelling, and the Second-Personal.” *European Journal for Philosophy of Religion* 5, no. 4: 29–53.

Stump, Eleonore. 2016. *The God of the Bible and the God of the Philosophers*. Milwaukee: Marquette University Press.

Eleonore Stump. 2018. *Atonement*. Oxford: Oxford University Press (Oxford Studies in Analytic Theology).

Marjorie Hewitt Suchocki. 1982. *God-Christ-Church: A Practical Guide to Process Theology*. New York: Crossroad.

Marjorie Hewitt Suchocki. 1988. *The End of Evil: Process Eschatology in Historical Context*. Albany: State University of New York Press.

Leonard Susskind. 1995. “The World as a Hologram.” *Journal of Mathematical Physics* 36(11):6377–6396.

Leonard Susskind. 2005. *The Cosmic Landscape: String Theory and the Illusion of Intelligent Design*. New York: Little, Brown and Company.

Richard Swinburne. 1970. *The Concept of Miracle*. Macmillan (London).

Richard Swinburne. 1977. *The Coherence of Theism*. Oxford: Clarendon Press.

Richard Swinburne. 1979. *The Existence of God*. Oxford: Clarendon Press.

Richard Swinburne. 1989. *Responsibility and Atonement*. Clarendon Press.

Richard Swinburne. 1994. *The Christian God*. Oxford: Clarendon Press.

Richard Swinburne. 1997. *Simplicity as Evidence of Truth*. Milwaukee: Marquette University Press.

Richard Swinburne. 2004. *The Existence of God (2nd ed.)*. Oxford: Clarendon Press.

Richard Swinburne. 2013. *Mind, Brain and Free Will*. Oxford: Oxford University Press.

Tahko, Tuomas E. 2015. *An Introduction to Metametaphysics*. Cambridge University Press.

Tahko, Tuomas E. 2018. “The Epistemology of Essence.” in Ontology, Modality, and Mind (Oxford University Press).

Joseph A. Tainter. 1988. *The Collapse of Complex Societies*. Cambridge University Press (New Studies in Archaeology).

Tarski, Alfred. 1959. “What is Elementary Geometry?” In L. Henkin, P. Suppes, and A. Tarski (eds.), The Axiomatic Method, Amsterdam: North-Holland.

Taylor, Charles. 1978. “The Validity of Transcendental Arguments.” *Proceedings of the Aristotelian Society*.

Tegmark, M. 2014. *Our Mathematical Universe: My Quest for the Ultimate Nature of Reality*. New York: Knopf.

Thomas Bugnyar, Stephan A. Reber, and Cameron Buckner. 2016. “Ravens attribute visual access to unseen competitors.” *Nature Communications* 7: 10506.

Thomas Naselaris, Cheryl A. Olman, Dustin E. Stansbury, Kamil Ugurbil, and Jack L. Gallant. 2015. “A voxel-wise encoding model for early visual areas decodes mental images of remembered scenes.” *NeuroImage* 105: 215–228.

Thomasson, Amie L. 2015. *Ontology Made Easy*. New York: Oxford University Press.

Thomasson, Amie L. 2020. *Norms and Necessity*. New York: Oxford University Press.

Cornelius Van Til. 1955. *The Defense of the Faith*. Philadelphia: Presbyterian and Reformed Publishing Co.

Timothy McGrew, Lydia McGrew and Eric Vestrup. 2001. “Probabilities and the Fine-Tuning Argument: A Sceptical View.” *Mind* 110 (440): 1027–1037.

Richard C. Tolman. 1934. *Relativity, Thermodynamics and Cosmology*. Oxford: Clarendon Press.

Tomaszewski, Christopher. 2019. “Collapsing the Modal Collapse Argument: On an Invalid Argument Against Divine Simplicity.” *Analysis* 79(2): 275–284.

Silvan S. Tomkins. 1962. *Affect Imagery Consciousness: Volume I, The Positive Affects*. Springer (New York).

Tooley, M. 1977. “The Nature of Laws.” *Canadian Journal of Philosophy* 7 (4): 667–698.

Tooley, Michael. 1997. *Time, Tense, and Causation*. Oxford: Clarendon Press.

Anthony Trewavas. 2003. “Aspects of Plant Intelligence.” *Annals of Botany* 92(1): 1–20.

Phyllis Trible. 1978. *God and the Rhetoric of Sexuality*. Fortress Press.

Denys Turner. 1995. *The Darkness of God: Negativity in Christian Mysticism*. Cambridge: Cambridge University Press.

Amos Tversky and Daniel Kahneman. 1974. “Judgment under Uncertainty: Heuristics and Biases.” *Science* 185(4157): 1124–1131.

Tye, Michael. 1995. *Ten Problems of Consciousness: A Representational Theory of the Phenomenal Mind*. MIT Press.

Michael Tye. 2008. “The Experience of Emotion: An Intentionalist Theory.” *Revue Internationale de Philosophie* 62 (1): 25–50.

Unger, Roberto Mangabeira; Smolin, Lee. 2014. *The Singular Universe and the Reality of Time*. Cambridge University Press.

United Nations General Assembly. 1948. “Universal Declaration of Human Rights.” UN Resolution 217 A (III), December 10, 1948.

United Nations General Assembly. 1966. “International Covenant on Economic, Social and Cultural Rights.” UN Resolution 2200A (XXI), December 16, 1966.

Vahe G. Gurzadyan, Roger Penrose. 2010. “Concentric Circles in WMAP Data May Provide Evidence of Violent Pre-Big-Bang Activity.” arXiv:1011.3706.

van Hamme, Carlos. 2025. “Why Modal Logic Cannot Ground a Necessary Personal God: Structural Limits of Modal Necessity and the Failure of Necessary Existence.” PhilArchive (preprint).

van Hamme, Carlos. 2025. “The Necessity Dilemma: A Modal Defeater for Classical Theism.” PhilArchive (preprint).

van Inwagen, P. 1980. “Indexicality and Actuality.” *Philosophical Review* 89(3): 403–426.

Van Inwagen, Peter. 1990. *Material Beings*. Ithaca, NY: Cornell University Press.

van Inwagen, Peter. 1998. “Modal Epistemology.” *Philosophical Studies* 92 (1): 67-84.

Veening, J.-W., W. K. Smits, and O. P. Kuipers. 2008. “Bistability, Epigenetics, and Bet-Hedging in Bacteria.” *Annual Review of Microbiology* 62: 193–210.

Rudi A. te Velde. 1995. *Participation and Substantiality in Thomas Aquinas*. E. J. Brill (Studien und Texte zur Geistesgeschichte des Mittelalters 46).

Dennis R. Venema and Scot McKnight. 2017. *Adam and the Genome: Reading Scripture after Genetic Science*. Grand Rapids, MI: Brazos Press.

H. S. Versnel. 2011. *Coping with the Gods: Wayward Readings in Greek Theology*. Brill (Religions in the Graeco-Roman World, vol. 173).

Vetter, Barbara. 2015. *Potentiality: From Dispositions to Modality*. Oxford University Press.

Alexander Vilenkin. 1982. “Creation of Universes from Nothing.” *Physics Letters B* 117(1–2):25–28.

Alex Vilenkin. 2006. *Many Worlds in One: The Search for Other Universes*. New York: Hill and Wang.

Frans de Waal. 2016. *Are We Smart Enough to Know How Smart Animals Are?* W. W. Norton (New York).

Wächtershäuser, G. 1988. “Before Enzymes and Templates: Theory of Surface Metabolism.” *Microbiological Reviews* 52 (4): 452–484.

Robert M. Wald. 1984. *General Relativity*. University of Chicago Press.

Wallace, D. 2012. *The Emergent Multiverse: Quantum Theory according to the Everett Interpretation*. Oxford: Oxford University Press.

Jerry L. Walls. 1992. *Hell: The Logic of Damnation*. University of Notre Dame Press.

Walton, John H. 2009. *The Lost World of Genesis One: Ancient Cosmology and the Origins Debate*. Downers Grove, IL: InterVarsity Press.

Walzer, Michael. 1983. *Spheres of Justice: A Defense of Pluralism and Equality*. Basic Books.

Wang, Jennifer. 2015. “The Modal Limits of Dispositionalism.” *Nous* 49 (3): 454-469.

Gary Watson. 1975. “Free Agency.” *Journal of Philosophy* 72 (8): 205–220.

John Webster. 2003. *Holiness*. SCM Press (London) / Eerdmans (Grand Rapids).

Webster, John. 2004. *Karl Barth*. London: Continuum.

Weinandy, Thomas G. 2000. *Does God Suffer?* University of Notre Dame Press.

Weinberg, Steven. 1979. “Baryon- and Lepton-Nonconserving Processes.” *Physical Review Letters* 43: 1566–1570.

Steven Weinberg. 1987. “Anthropic Bound on the Cosmological Constant.” *Physical Review Letters* 59(22):2607–2610.

Steven Weinberg. 1989. “The Cosmological Constant Problem.” *Reviews of Modern Physics* 61(1):1–23.

Weinberg, S. 1995. *The Quantum Theory of Fields*. Vol. 1. Cambridge: Cambridge University Press.

Moshe Weinfeld. 1995. *Social Justice in Ancient Israel and in the Ancient Near East*. Fortress Press / Magnes Press.

Weiss, M. C., F. L. Sousa, N. Mrnjavac, S. Neukirchen, M. Roettger, S. Nelson-Sathi, and W. F. Martin. 2016. “The Physiology and Habitat of the Last Universal Common Ancestor.” *Nature Microbiology* 1 (9): 16116.

Greg Welty. 2014. “Theistic Conceptual Realism.” In Paul M. Gould (ed.), Beyond the Control of God? Six Views on the Problem of God and Abstract Objects (New York: Bloomsbury Academic, 2014), pp. 81–96.

Jan Westerhoff. 2009. *Nāgārjuna's Madhyamaka: A Philosophical Introduction*. New York: Oxford University Press.

Westphal, Merold. 2001. *Overcoming Onto-Theology: Toward a Postmodern Christian Faith*. New York: Fordham University Press.

Wheeler, J. A. 1990. “Information, Physics, Quantum: The Search for Links.” In Complexity, Entropy, and the Physics of Information, edited by W. H. Zurek, 3–28. Redwood City, CA: Addison-Wesley.

Thomas Joseph White. 2016. “Divine Simplicity and the Holy Trinity.” *International Journal of Systematic Theology* 18, no. 1: 66–93.

Whitehead, Alfred North, and Bertrand Russell. 1910–1913. *Principia Mathematica*. Cambridge: Cambridge University Press (3 vols.).

Whitehead, A. N. 1929. *Process and Reality*. New York: Macmillan.

Erik J. Wielenberg. 2014. *Robust Ethics: The Metaphysics and Epistemology of Godless Normative Realism*. Oxford University Press.

Wierenga, Edward R. 1989. *The Nature of God: An Inquiry into Divine Attributes*. Ithaca, NY: Cornell University Press.

Wiggins, David. 1980. *Sameness and Substance*. Oxford: Blackwell.

Wiggins, David. 2001. *Sameness and Substance Renewed*. Cambridge: Cambridge University Press.

Wigner, E. P. 1939. “On Unitary Representations of the Inhomogeneous Lorentz Group.” *Annals of Mathematics* 40 (1): 149–204.

Wigner, Eugene P. 1960. “The Unreasonable Effectiveness of Mathematics in the Natural Sciences.” *Communications on Pure and Applied Mathematics*.

William Lane Craig, Quentin Smith. 1993. *Theism, Atheism, and Big Bang Cosmology*. Oxford: Clarendon Press.

Williams, Donald C. 1951. “The Myth of Passage.” *The Journal of Philosophy* 48(15): 457–472.

Donald C. Williams. 1953. “On the Elements of Being: I and II.” *The Review of Metaphysics* 7(1): 3–18 and 7(2): 171–192.

Thomas Williams. 2005. “The Doctrine of Univocity is True and Salutary.” *Modern Theology* 21, no. 4: 575–585.

Timothy Williamson. 2000. *Knowledge and Its Limits*. Oxford University Press.

Williamson, Timothy. 2007. *The Philosophy of Philosophy*. Blackwell.

Williamson, Timothy. 2013. *Modal Logic as Metaphysics*. Oxford: Oxford University Press.

Williamson, Timothy. 2017. “Semantic Paradoxes and Abductive Methodology.” In B. Armour-Garb (ed.), Reflections on the Liar, Oxford: Oxford University Press, pp. 325–346.

Wimsatt, William C. 1976. “Reductionism, Levels of Organization, and the Mind-Body Problem.” In G. Globus, G. Maxwell, and I. Savodnik (eds.), Consciousness and the Brain, New York: Plenum Press.

John F. Wippel. 2000. *The Metaphysical Thought of Thomas Aquinas: From Finite Being to Uncreated Being*. Catholic University of America Press.

Wittgenstein, Ludwig. (1921) 1961. *Tractatus Logico-Philosophicus*. Translated by D. F. Pears and B. F. McGuinness. London: Routledge.

Wittgenstein, Ludwig. 1953. *Philosophical Investigations*. Oxford: Blackwell (trans. G. E. M. Anscombe).

Wochner, A., J. Attwater, A. Coulson, and P. Holliger. 2011. “Ribozyme-Catalyzed Transcription of an Active Ribozyme.” *Science* 332 (6026): 209–212.

Carl R. Woese. 1998. “The Universal Ancestor.” *PNAS* 95(12):6854–6859.

Wolfram, S. 2002. *A New Kind of Science*. Champaign, IL: Wolfram Media.

Nicholas Wolterstorff. 1975. “God Everlasting.” In Clifton Orlebeke and Lewis Smedes (eds.), God and the Good: Essays in Honor of Henry Stob (Grand Rapids, MI: Eerdmans, 1975), pp. 181–203.

Wolterstorff, Nicholas. 1991. “Divine Simplicity.” *Philosophical Perspectives* 5: 531–552.

Wolterstorff, Nicholas. 2001. “Unqualified Divine Temporality.” In Gregory E. Ganssle (ed.), God & Time: Four Views (Downers Grove, IL: InterVarsity Press, 2001), pp. 187–213.

Nicholas Wolterstorff. 2015. *The God We Worship: An Exploration of Liturgical Theology*. Grand Rapids: Eerdmans.

Woodward, James. 2003. *Making Things Happen: A Theory of Causal Explanation*. New York: Oxford University Press.

Wright, N. T. 2003. *The Resurrection of the Son of God*. Minneapolis: Fortress Press.

Stephen J. Wykstra. 1984. “The Humean Obstacle to Evidential Arguments from Suffering: On Avoiding the Evils of “Appearance”.” *International Journal for Philosophy of Religion* 16, no. 2 (1984): 73–93.

Yablo, Stephen. 1993. “Is Conceivability a Guide to Possibility?” *Philosophy and Phenomenological Research*.

Yinon M. Bar-On, Rob Phillips, Ron Milo. 2018. “The Biomass Distribution on Earth.” *PNAS* 115(25):6506–6511.

Young, Iris Marion. 2011. *Responsibility for Justice*. Oxford University Press.

Dean W. Zimmerman. 2005. “The A-Theory of Time, the B-Theory of Time, and 'Taking Tense Seriously'.” *Dialectica* 59(4):401–457.

Zurek, W. H. 2003. “Decoherence, Einselection, and the Quantum Origins of the Classical.” *Reviews of Modern Physics* 75 (3): 715–775.


---

← [Notes](Notes.md) | [Index](Index.md) →
