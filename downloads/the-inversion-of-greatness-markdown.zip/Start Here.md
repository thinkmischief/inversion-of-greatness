This is a plain-markdown export of *The Inversion of Greatness*, split into one file per chapter and per numbered section — built for use in Obsidian or a Notion import, not for reading in a browser. Links between sections are ordinary file-to-file links; boxes like `> [!definition]` follow Obsidian's own callout format, used for definitions, theorems, premises, and similar set-apart content throughout the book.

## The book in five movements

The argument begins with the nature of necessity and follows where it leads, in five movements:

1. *From the Nature of Necessity to the Necessity of Nature*. Chapter 1 lays the groundwork and fixes the vocabulary; Chapter 2 first shows why possibility itself has a fixed structure, then uses that structure to establish the necessity of Nature — three conditions that require one another, with no alternative left over to stand in their place. Chapter 3 confirms the result from independent angles, and Chapter 4 tests it against the field of metaphysical rivals.
1. *From the Necessity of Nature to Supernatural Preclusion*. Chapter 5 closes off the supernatural specifically, taking on every rival ultimate, classical and non-classical, proposed in its place; Chapter 6 works through the classical divine attributes one at a time, showing where the greatness credited to God belongs instead.
1. *From Supernatural Preclusion to Nature Alone*. Chapter 7 follows metaphysics and physics as they converge: spacetime, fields, conservation, and symmetry, then singularities, cosmic history, and life. The convergence earns a further identity, distinct from Reality and Nature's: whatever universe there turns out to be — one, or bubbling into many — is not something contained within Reality, or set against it, but one and the same whole with it. And that whole is not one among many: however the count of worlds comes out, it is a count of what the one whole contains, never of rival wholes.
1. *From Nature Alone to the Expanding Field*. If nature is all there is, mind is not something added on top of it: consciousness may be understood as what a living process is when met from the inside, at sufficient recursive depth. Chapter 8 develops that identification across the registers of one living process: drive, feeling, knowledge (never held alone, but built and checked across minds), reasoning, identity, sexuality, mortality, meaning, will, language, technology, morality, art, and spirituality, each an operation on the field of possibility a being has mapped, and each widening as that field deepens. The mental, the meaningful, the moral, and the sacred are not added to life from above; they are what life is, registered from inside.
1. *From the Expanding Field to Maximum Possibility*. Once beings like that live in shared conditions, they have to maintain the field in which any of those registers can remain available at all. Chapter 9 asks what that requires, from rights and belonging to representation and the institutions of a shared world, under one governing principle: maximum possibility under necessities met.

## Where to begin?

The argument is cumulative: later conclusions rest on earlier ones. But your first read doesn't have to be linear. Each chapter orients you to the work it's doing and points back to the foundations it rests on, so you can start with the curiosity that brought you, trace the reasoning back to its metaphysical ground whenever you like, or follow it forward to see what it opens.

- Chapters 1–3 cover **metaphysics and modality**. The front door and foundation for the rest of the book. Chapter 1 fixes the vocabulary — reality, modal status, change, existence, and the three conditions any change requires. Chapter 2 runs the argument itself, from Cartesian certainty through the necessary possibility of change to the triconditional necessity of Time, Space, and Substance. Chapter 3 comes at the same result from independent directions, positive and negative, and closes by showing that Reality and Nature are one — so that to be anything at all, then, just is to occupy that same structure. The modal logic is earned rather than stipulated: the S5 principles are derived from what real possibility is, so the argument never helps itself to the machinery it needs.
- Chapter 4 takes up **rival metaphysics**: dozens of competing accounts, taken one at a time: idealism, Russellian monism and cosmopsychism, eliminativism, Humean contingency, Lewis's modal realism, the block universe, Platonism, and the mathematical universe hypothesis. Every account faces the same pressure. Does it eliminate Time, Space, and Substance, or merely redescribe them?
- Chapters 5–6 and the Excursus take up **religion and theology**. Chapter 5 takes natural theology at its strongest — the theistic arguments for a divine ground, the doctrines of the divine nature, and the non-classical ultimates offered in their place. Chapter 6 relocates greatness attribute by attribute: constitution, aseity and modal standing, cognition, intrinsic value, life, agency, reach, and moral act, asking in each case which side actually satisfies the description. The Excursus takes up the doctrines one at a time: evil and the theodicies, original sin, providence, prayer, miracles, and divine hiddenness.
- Chapter 7 follows **Nature and the sciences**: Time, Space, and Substance taken one at a time in working physics, then the binding of the three, then what follows for singularities, cosmic history, and the emergence of life. It reads on its own, if you'd rather meet the physics before the metaphysics that motivates it.
- Chapter 8 explores **mind and lived experience**: what a self-modeling life is like from inside, and what changes when such lives open onto one another and the field becomes shared. It leans on Chapter 7's account of living things, but you can come in cold.
- Chapter 9 turns to **political philosophy**: what a shared world has to secure once beings like that are living in it: rights, belonging, representation, information, environment, agriculture, economy, housing, education, healthcare, defense, enforcement, and justice. Each is treated as a condition of possibility rather than a policy preference — what it takes for a life to have live options at all — and the chapter closes by asking how the whole set holds together and what installing it would actually require.

**Want to inspect the machinery?** No prior logic is required to start, but the [Modal Logic Primer](<Appendix A Modal Logic Primer.md>) gathers the symbols (◇, □, and S5) in one place; the [Formal Proof Summary](<Appendix B Summary of the Formal Proof.md>) compresses the book into its logical skeleton; and the [Derivation Map](<Appendix C Derivation Map.md>) traces each major claim back to what it rests on.


## Table of Contents

- [Copyright](Copyright.md)
- [Preface](Preface.md)
- [Introduction](Introduction.md)
- [1. Groundwork](<1. Groundwork.md>)
- [2. The Argument](<2. The Argument.md>)
- [3. Convergence](<3. Convergence.md>)
- [4. Metaphysical Rivals](<4. Metaphysical Rivals.md>)
- [5. Rival Ultimates](<5. Rival Ultimates.md>)
- [6. Relocating Greatness](<6. Relocating Greatness.md>)
- [7. Nature Alone](<7. Nature Alone.md>)
- [8. Expanding the Field](<8. Expanding the Field.md>)
- [9. Maximum Possibility](<9. Maximum Possibility.md>)
- [C. Conclusion](<C. Conclusion.md>)
- [E. Excursus](<E. Excursus.md>)
- [Appendix A: Modal Logic Primer](<Appendix A Modal Logic Primer.md>)
- [Appendix B: Summary of the Formal Proof](<Appendix B Summary of the Formal Proof.md>)
- [Appendix C: Derivation Map](<Appendix C Derivation Map.md>)
- [Appendix D: Empirical Predictions](<Appendix D Empirical Predictions.md>)
- [Author's Notes](<Author's Notes.md>)
- [Symbols](Symbols.md)
- [Glossary](Glossary.md)
- [Notes](Notes.md)
- [Index](Index.md)


---

[Copyright](Copyright.md) →
